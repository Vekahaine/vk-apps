/* =====================================================================
   VkTV — Multi-live : plusieurs chaînes en direct sur un seul écran
   ===================================================================== */
const MV = { tiles: [], active: null, open: false, banner: '', addedAt: 0, account: null };
const mvEl = $('#multi'), mvGrid = $('#mvGrid');
const MV_MAX = 16;

/* Le navigateur limite à 6 connexions par adresse : sur ce PC on répartit les flux
   sur plusieurs adresses locales (127.0.0.2, .3…) pour pouvoir en ouvrir beaucoup. */
const mvLocal = /^(localhost|127\.)/.test(location.hostname);
function mvSrc(u, i) {
  if (window.VK_DIRECT) return u;
  if (!mvLocal) return absUrl(proxied(u));
  return `http://127.0.0.${2 + (i % 12)}:${location.port || 80}/p?u=${encodeURIComponent(u)}`;
}

/* ---------- liste mémorisée */
function mvSaved() { const pid = S.activePid || 'x'; S.multi = S.multi || {}; return S.multi[pid] = S.multi[pid] || []; }
function mvSave() { const a = mvSaved(); a.length = 0; for (const t of MV.tiles) a.push(snap(t.c)); save(); }

/* ---------- ouverture / fermeture */
function mvOpen() {
  if (!CH.length) return toast('Ajoute d\'abord ta playlist');
  closeMenu(); closeModals();
  if (app.classList.contains('watch')) exitWatch(true);
  // le lecteur principal s'arrête : sinon il compterait comme un flux de plus chez ton fournisseur
  const cur = PL.ch && (PL.hls || PL.mts || video.getAttribute('src')) ? PL.ch : null;
  stopEngines(); PL.gen++;
  if (!MV.tiles.length) {
    const saved = mvSaved().map(resolve).filter(c => !c.missing);
    if (cur && cur.k === 'live' && !saved.some(c => c.key === cur.key)) saved.unshift(cur);
    MV.tiles = saved.slice(0, MV_MAX).map(c => mvTile(c));
  } else if (cur && cur.k === 'live' && !MV.tiles.some(t => t.c.key === cur.key)) MV.tiles.unshift(mvTile(cur));
  MV.open = true; mvEl.hidden = false; document.body.classList.add('mv-on');
  MV.active = MV.tiles.find(t => cur && t.c.key === cur.key) || MV.tiles[0] || null;
  mvRender(true);
  MV.tiles.forEach((t, i) => setTimeout(() => MV.open && mvStart(t), i * 350)); // démarrage échelonné
  if (!MV.tiles.length) mvPanel(true);
  mvEl.focus({ preventScroll: true });
  mvAccount();
  mvSave();
}
function mvClose(keepPlaying = true) {
  if (!MV.open) return;
  const act = MV.active && MV.active.state !== 'error' ? MV.active.c : null;
  for (const t of MV.tiles) mvStop(t);
  MV.open = false; mvEl.hidden = true; document.body.classList.remove('mv-on'); mvPanel(false);
  if (document.fullscreenElement === mvEl) document.exitFullscreen().catch(() => { });
  mvSave();
  if (keepPlaying && act) { play(act, GROUPS[act.k]?.get(act.g) || [act]); if (UI.layout === 'home') enterWatch(); }
}
window.mvAdd = function (c, open) {
  if (!c || c.k !== 'live') return;
  if (!MV.open) {
    const a = mvSaved();
    if (!a.some(x => x.key === c.key)) { a.push(snap(c)); save(); }
    if (open) mvOpen(); else toast(`Ajoutée au multi-live : ${c.dn || c.n}`);
    return;
  }
  mvToggle(c);
};
$('#btnMulti').onclick = () => mvOpen();
$('#pbMulti').onclick = e => { e.stopPropagation(); mvOpen(); };
$('#mvBack').onclick = () => mvClose();
$('#mvAddBtn').onclick = () => mvPanel(!MV.panel);
$('#mvFull').onclick = () => document.fullscreenElement ? document.exitFullscreen() : mvEl.requestFullscreen().catch(() => { });

/* ---------- tuiles */
function mvTile(c) {
  const el = document.createElement('div'); el.className = 'mvt'; el.tabIndex = 0;
  el.innerHTML = `<video playsinline disablepictureinpicture></video>
    <div class="mvt-spin"><div class="spin"></div></div>
    <div class="mvt-err" hidden><b>Chaîne refusée</b><span></span><button class="btn sm">Réessayer</button></div>
    <div class="mvt-top"><span class="mvt-snd"></span><span class="mvt-nm"></span><span class="grow"></span>
      <button class="mvt-b" data-a="main" title="Mettre en grand"></button><button class="mvt-b" data-a="solo" title="Regarder seule en plein écran"></button><button class="mvt-b" data-a="rm" title="Retirer (Suppr)"></button></div>
    <div class="mvt-bot"></div>`;
  const t = { c, el, video: el.querySelector('video'), state: 'idle', vi: 0, retries: 0, lastT: -1, lastMove: 0 };
  el.querySelector('[data-a=main]').innerHTML = ic('expand');
  el.querySelector('[data-a=solo]').innerHTML = ic('full');
  el.querySelector('[data-a=rm]').innerHTML = ic('x');
  el.querySelector('.mvt-err button').onclick = e => { e.stopPropagation(); t.retries = 0; t.vi = 0; mvStart(t); };
  t.video.addEventListener('playing', () => { t.state = 'playing'; t.since = Date.now(); el.classList.remove('loading'); el.querySelector('.mvt-err').hidden = true; mvInfo(); });
  t.video.addEventListener('waiting', () => el.classList.add('loading'));
  t.video.addEventListener('canplay', () => el.classList.remove('loading'));
  mvLabel(t);
  return t;
}
function mvLabel(t) {
  const c = t.c, p = nowProg(c);
  t.el.querySelector('.mvt-nm').innerHTML = `${esc(c.dn || c.n)}`;
  t.el.querySelector('.mvt-bot').innerHTML = p ? `<span class="tm">${hm(p[0])}</span> ${esc(p[2])}` : esc(catLabel(c.k, c.g));
}
function mvStop(t) {
  if (t.hls) { try { t.hls.destroy(); } catch { } t.hls = null; }
  if (t.mts) { try { t.mts.pause(); t.mts.unload(); t.mts.detachMediaElement(); t.mts.destroy(); } catch { } t.mts = null; }
  try { t.video.pause(); t.video.removeAttribute('src'); t.video.load(); } catch { }
  t.state = 'idle'; clearTimeout(t.retryT);
}
function mvStart(t) {
  mvStop(t);
  if (!MV.open || !MV.tiles.includes(t)) return;
  const idx = MV.tiles.indexOf(t), vars = variants(t.c.u), u = vars[Math.min(t.vi, vars.length - 1)];
  const src = mvSrc(u, idx), ext = extOf(u), v = t.video, gen = t.gen = (t.gen || 0) + 1;
  t.state = 'loading'; t.lastMove = Date.now(); t.lastT = -1;
  t.el.classList.add('loading'); t.el.querySelector('.mvt-err').hidden = true;
  v.muted = t !== MV.active; v.volume = UI.vol;
  const fail = why => { if (gen === t.gen) mvFail(t, why); };
  if (ext === 'm3u8' && window.Hls && Hls.isSupported()) {
    const h = new Hls({ enableWorker: true, backBufferLength: 10, maxBufferLength: 12, maxMaxBufferLength: 20, liveSyncDurationCount: 3, manifestLoadingMaxRetry: 1, levelLoadingMaxRetry: 2, fragLoadingMaxRetry: 3, capLevelToPlayerSize: true });
    t.hls = h;
    h.on(Hls.Events.ERROR, (_, d) => { if (d.fatal) fail(`${d.details} ${d.response && d.response.code || ''}`); });
    h.on(Hls.Events.MANIFEST_PARSED, () => v.play().catch(() => { }));
    h.loadSource(src); h.attachMedia(v);
  } else if (window.mpegts && mpegts.getFeatureList().mseLivePlayback) {
    const p = mpegts.createPlayer({ type: 'mpegts', isLive: true, url: src }, {
      enableWorker: true, enableStashBuffer: true, stashInitialSize: 256 * 1024, lazyLoad: false,
      liveSync: true, liveSyncMaxLatency: 6, liveSyncTargetLatency: 3, liveSyncPlaybackRate: 1.1,
      autoCleanupSourceBuffer: true, autoCleanupMaxBackwardDuration: 20, autoCleanupMinBackwardDuration: 10,
    });
    t.mts = p;
    p.on(mpegts.Events.ERROR, (a, b, info) => fail(`${a} ${b} ${info && info.code || ''}`));
    p.attachMediaElement(v); p.load(); v.play().catch(() => { });
  } else { v.src = src; v.play().catch(() => { }); }
}
function mvFail(t, why) {
  const vars = variants(t.c.u);
  if (t.vi < vars.length - 1) { t.vi++; return mvStart(t); }
  if (t.retries < 1) { t.retries++; t.vi = 0; t.retryT = setTimeout(() => mvStart(t), 1500); return; }
  mvStop(t); t.state = 'error'; t.el.classList.remove('loading');
  const refused = /40[0-9]|NetworkError|HttpStatus|manifestLoad|Exception|Early/i.test(why);
  const others = MV.tiles.filter(x => x !== t && x.state === 'playing').length;
  const err = t.el.querySelector('.mvt-err'); err.hidden = false;
  err.querySelector('span').textContent = refused && others
    ? `Ton fournisseur refuse une chaîne de plus : ${others} chaîne${others > 1 ? 's' : ''} déjà ouverte${others > 1 ? 's' : ''}.`
    : 'Flux indisponible ou format non lisible.';
  if (refused && others) mvLimit(others);
}
// une chaîne déjà lancée s'est arrêtée juste après l'ajout d'une autre → le fournisseur a coupé l'ancienne
function mvLimit(n) {
  MV.banner = `⚠ Ton fournisseur ne semble accepter que ${n} chaîne${n > 1 ? 's' : ''} en même temps sur ton abonnement. Les chaînes en plus sont refusées par son serveur (VkTV ne peut pas les regrouper en un seul flux : chaque chaîne est envoyée séparément par le fournisseur).`;
  const b = $('#mvBanner'); b.hidden = false; b.innerHTML = `${esc(MV.banner)} <button class="btn sm ghost" id="mvBannerX">OK</button>`;
  $('#mvBannerX').onclick = () => { b.hidden = true; };
}
// surveillance : image figée → relance ; coupée juste après un ajout → limite atteinte
setInterval(() => {
  if (!MV.open) return;
  for (const t of MV.tiles) {
    if (t.state !== 'playing' || t.video.paused) continue;
    if (t.video.currentTime !== t.lastT) { t.lastT = t.video.currentTime; t.lastMove = Date.now(); continue; }
    if (Date.now() - t.lastMove > 10000) {
      const recent = Date.now() - MV.addedAt < 20000;
      if (recent) { const n = MV.tiles.filter(x => x !== t && x.state === 'playing').length; if (n) mvLimit(n); }
      t.lastMove = Date.now(); t.retries = 0; mvStart(t);
    }
  }
}, 2000);
setInterval(() => { if (MV.open) MV.tiles.forEach(mvLabel); }, 60000);

/* ---------- disposition « intelligente » */
function mvLayout() {
  const n = MV.tiles.length, W = mvGrid.clientWidth || innerWidth, H = mvGrid.clientHeight || innerHeight - 60;
  if (!n) { mvGrid.style.gridTemplateColumns = '1fr'; mvGrid.style.gridTemplateRows = '1fr'; return { cols: 1, rows: 1, span: 0 }; }
  // on cherche la grille qui affiche les images 16:9 les plus grandes possible
  let best = null;
  for (let cols = 1; cols <= n; cols++) {
    const rows = Math.ceil(n / cols), w = W / cols, h = H / rows;
    const vw = Math.min(w, h * 16 / 9), area = vw * vw * 9 / 16 * n;
    if (!best || area > best.area * 1.02) best = { cols, rows, area };
  }
  let { cols, rows } = best, empty = cols * rows - n, span = 0;
  // les cases vides servent à agrandir la chaîne principale
  if (n >= 3 && empty >= 3 && cols >= 2 && rows >= 2) { span = 4; empty -= 3; }
  else if (n >= 3 && empty >= 1 && rows >= 2) { span = 2; empty -= 1; }
  else if (n >= 2 && empty >= 1 && cols >= 2 && rows === 1) { span = 0; }
  mvGrid.style.gridTemplateColumns = `repeat(${cols}, 1fr)`;
  mvGrid.style.gridTemplateRows = `repeat(${rows}, 1fr)`;
  return { cols, rows, span, empty };
}
function mvRender(first) {
  const L = mvLayout();
  // la chaîne avec le son passe en premier (= la plus grande)
  const kids = [];
  MV.tiles.forEach((t, i) => {
    t.el.classList.toggle('active', t === MV.active);
    t.el.classList.toggle('big', i === 0 && L.span > 0);
    t.el.style.gridRow = i === 0 && L.span ? 'span 2' : '';
    t.el.style.gridColumn = i === 0 && L.span === 4 ? 'span 2' : '';
    t.el.querySelector('.mvt-snd').innerHTML = ic(t === MV.active && !t.video.muted ? 'vol' : 'mute');
    t.video.muted = t !== MV.active;
    kids.push(t.el);
  });
  // cases libres → « + Ajouter »
  const free = Math.max(L.empty || 0, MV.tiles.length ? 0 : 1);
  for (let i = 0; i < free; i++) {
    const a = document.createElement('button'); a.className = 'mvt-add';
    a.innerHTML = `${ic('plus')}<span>${MV.tiles.length ? 'Ajouter une chaîne' : 'Ajoute tes chaînes'}</span>`;
    a.onclick = () => mvPanel(true);
    kids.push(a);
  }
  // on garde les éléments vidéo en place (pas de coupure du flux)
  const cur = [...mvGrid.children];
  cur.forEach(el => { if (!kids.includes(el)) el.remove(); });
  kids.forEach((el, i) => { if (mvGrid.children[i] !== el) mvGrid.insertBefore(el, mvGrid.children[i] || null); });
  $('#mvCount').textContent = MV.tiles.length ? `${MV.tiles.length} chaîne${MV.tiles.length > 1 ? 's' : ''}` : '';
  $('#mvAddBtn').innerHTML = `${ic('plus')}<span>Ajouter</span>`;
  mvInfo();
}
new ResizeObserver(() => { if (MV.open) mvRender(); }).observe(mvGrid);

function mvInfo() {
  const playing = MV.tiles.filter(t => t.state === 'playing').length;
  const a = MV.account;
  $('#mvInfo').textContent = (a && a.max_connections ? `Ton abonnement annonce ${a.max_connections} flux simultané${+a.max_connections > 1 ? 's' : ''} · ` : '') + (MV.tiles.length ? `${playing} en lecture` : '');
}
async function mvAccount() {
  const p = activePl(); MV.account = null;
  if (!p || p.type !== 'xtream') return mvInfo();
  try { const r = await fetch(`api/account/${p.id}`); if (r.ok) MV.account = await r.json(); } catch { }
  mvInfo();
}

/* ---------- actions sur les tuiles */
function mvSetActive(t) {
  if (!t) return;
  MV.active = t;
  for (const x of MV.tiles) x.video.muted = x !== t;
  if (t.video.muted === false && t.video.paused) t.video.play().catch(() => { });
  mvRender(); t.el.focus({ preventScroll: true });
}
function mvMain(t) { const i = MV.tiles.indexOf(t); if (i > 0) { MV.tiles.splice(i, 1); MV.tiles.unshift(t); } mvSetActive(t); mvSave(); }
function mvRemove(t) {
  const i = MV.tiles.indexOf(t); if (i < 0) return;
  mvStop(t); MV.tiles.splice(i, 1); t.el.remove();
  if (MV.active === t) MV.active = MV.tiles[Math.min(i, MV.tiles.length - 1)] || null;
  mvRender(); mvSave(); mvPanelRender();
  // une place s'est libérée : on relance les chaînes refusées
  MV.tiles.filter(x => x.state === 'error').slice(0, 1).forEach(x => { x.retries = 0; x.vi = 0; mvStart(x); });
}
function mvToggle(c) {
  const t = MV.tiles.find(x => x.c.key === c.key);
  if (t) return mvRemove(t);
  if (MV.tiles.length >= MV_MAX) return toast(`Maximum ${MV_MAX} chaînes`);
  const nt = mvTile(c); MV.tiles.push(nt); MV.addedAt = Date.now();
  if (!MV.active) MV.active = nt;
  mvRender(); mvStart(nt); mvSave(); mvPanelRender();
  if (MV.tiles.length === 7) toast('Au-delà de 6 chaînes, ton PC et ta connexion sont très sollicités');
}
mvGrid.addEventListener('click', e => {
  const el = e.target.closest('.mvt'); if (!el) return;
  const t = MV.tiles.find(x => x.el === el); if (!t) return;
  const b = e.target.closest('.mvt-b');
  if (b) { const a = b.dataset.a; if (a === 'rm') return mvRemove(t); if (a === 'main') return mvMain(t); if (a === 'solo') { MV.active = t; return mvClose(true); } }
  if (e.target.closest('.mvt-err')) return;
  mvSetActive(t);
});
mvGrid.addEventListener('dblclick', e => { const el = e.target.closest('.mvt'); const t = el && MV.tiles.find(x => x.el === el); if (t) { MV.active = t; mvClose(true); } });
mvGrid.addEventListener('contextmenu', e => {
  const el = e.target.closest('.mvt'); const t = el && MV.tiles.find(x => x.el === el); if (!t) return; e.preventDefault();
  menu(e.clientX, e.clientY, [{ head: t.c.dn || t.c.n },
    { label: 'Mettre le son sur cette chaîne', icon: 'vol', act: () => mvSetActive(t) },
    { label: 'Mettre en grand', icon: 'expand', act: () => mvMain(t) },
    { label: 'Regarder seule', icon: 'full', act: () => { MV.active = t; mvClose(true); } },
    { label: isFav(t.c) ? 'Retirer des chaînes favorites' : 'Ajouter aux chaînes favorites', icon: 'star', act: () => toggleFav(t.c) },
    '-', { label: 'Retirer du multi-live', icon: 'x', act: () => mvRemove(t) }]);
});

/* ---------- panneau d'ajout */
function mvPanel(on) {
  MV.panel = on; $('#mvPanel').hidden = !on; mvEl.classList.toggle('panel', on);
  if (on) { $('#mvSearch').value = ''; mvPanelRender(); setTimeout(() => $('#mvSearch').focus(), 30); }
  else mvEl.focus({ preventScroll: true });
}
$('#mvPanelClose').onclick = () => mvPanel(false);
$('#mvPanel .f-ic').innerHTML = ic('search');
let mvOpenCat = null;
function mvPanelRender() {
  if (!MV.panel) return;
  const q = norm($('#mvSearch').value), toks = q ? q.split(' ') : [], qc = q.replace(/ /g, '');
  const inMv = new Set(MV.tiles.map(t => t.c.key));
  const row = c => `<button class="mvp-it${inMv.has(c.key) ? ' on' : ''}" data-key="${esc(c.key)}">${logoHTML(c)}<span class="mt"><span class="nm">${esc(c.dn || c.n)}</span><span class="sub"><span class="t">${(() => { const p = nowProg(c); return p ? hm(p[0]) + ' · ' + esc(p[2]) : esc(catLabel(c.k, c.g)); })()}</span></span></span><span class="mvp-tg">${ic(inMv.has(c.key) ? 'check' : 'plus')}</span></button>`;
  let h = '';
  const pool = new Map();
  const add = (title, list) => { const L = list.filter(c => c && !c.missing && c.k === 'live'); if (!L.length) return; h += `<div class="pr-h">${esc(title)}</div>`; for (const c of L) { pool.set(c.key, c); h += row(c); } };
  if (q) {
    const hits = [];
    for (const c of CH) { if (c.k !== 'live') continue; let s = scoreName(c.nn, c.nc, toks, q, qc); if (s > 0) { if (favSet.has(c.key)) s += 150; if (isHidden(c)) s -= 70; hits.push([s, c]); } }
    hits.sort((a, b) => b[0] - a[0]);
    add(`Résultats · ${hits.length}`, hits.slice(0, 60).map(x => x[1]));
    if (!hits.length) h += `<div class="pal-empty">Aucune chaîne pour « ${esc($('#mvSearch').value)} »</div>`;
  } else {
    add('Chaînes favorites', favList().items.map(resolve));
    add('Récentes', S.recents.map(resolve).slice(0, 12));
    const fcs = validFavCats().filter(f => f.k === 'live');
    const cats = [...fcs.map(f => f.g), ...orderedGroups('live', false).filter(g => !fcs.some(f => f.g === g))];
    h += `<div class="pr-h">Par catégorie</div>`;
    for (const g of cats) {
      const open = mvOpenCat === g;
      h += `<button class="mvp-cat${open ? ' open' : ''}" data-g="${esc(g)}">${ic(isFavCat('live', g) ? 'star' : 'folder')}<span>${esc(catLabel('live', g))}</span><small>${GROUPS.live.get(g).length}</small>${ic(open ? 'down' : 'next')}</button>`;
      if (open) for (const c of GROUPS.live.get(g)) { pool.set(c.key, c); h += row(c); }
    }
  }
  MV.pool = pool;
  const L = $('#mvList'), y = L.scrollTop; L.innerHTML = h; L.scrollTop = y;
}
$('#mvSearch').addEventListener('input', () => { $('#mvList').scrollTop = 0; mvPanelRender(); });
$('#mvSearch').addEventListener('keydown', e => {
  e.stopPropagation();
  if (e.key === 'Escape') { if (e.target.value) { e.target.value = ''; mvPanelRender(); } else mvPanel(false); }
  if (e.key === 'Enter') { const f = $('#mvList .mvp-it'); if (f) f.click(); e.target.select(); }
  if (e.key === 'ArrowDown') { e.preventDefault(); $('#mvList .mvp-it, #mvList .mvp-cat')?.focus(); }
});
$('#mvList').addEventListener('click', e => {
  const cat = e.target.closest('.mvp-cat'); if (cat) { mvOpenCat = mvOpenCat === cat.dataset.g ? null : cat.dataset.g; return mvPanelRender(); }
  const it = e.target.closest('.mvp-it'); if (!it) return;
  const key = it.dataset.key, c = MV.pool && MV.pool.get(key);
  if (c) { mvToggle(c); $(`#mvList .mvp-it[data-key="${CSS.escape(key)}"]`)?.focus({ preventScroll: true }); }
});
$('#mvList').addEventListener('keydown', e => {
  const items = $$('#mvList .mvp-it, #mvList .mvp-cat'), i = items.indexOf(document.activeElement);
  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); e.stopPropagation(); items[clamp(i + (e.key === 'ArrowDown' ? 1 : -1), 0, items.length - 1)]?.focus(); }
  else if (e.key === 'Escape') { e.stopPropagation(); mvPanel(false); }
  else if (e.key === 'Enter') { e.stopPropagation(); }
});

/* ---------- clavier / télécommande dans le multi-live */
mvEl.addEventListener('keydown', e => {
  if (e.target.closest && e.target.closest('#mvPanel')) { if (e.key !== 'Tab') e.stopPropagation(); return; }
  const k = e.key, n = MV.tiles.length, i = MV.tiles.indexOf(MV.active);
  const back = k === 'Escape' || k === 'BrowserBack' || e.keyCode === 10009 || e.keyCode === 461 || k === 'Backspace';
  e.stopPropagation();
  if (back) { e.preventDefault(); if (MV.panel) mvPanel(false); else if (document.fullscreenElement) document.exitFullscreen(); else mvClose(); return; }
  if (!n && (k === 'Enter' || k === '+')) { e.preventDefault(); return mvPanel(true); }
  if (['ArrowRight', 'ArrowDown'].includes(k)) { e.preventDefault(); return mvSetActive(MV.tiles[(i + 1) % n]); }
  if (['ArrowLeft', 'ArrowUp'].includes(k)) { e.preventDefault(); return mvSetActive(MV.tiles[(i - 1 + n) % n]); }
  if (k === 'Enter') { e.preventDefault(); if (MV.active) mvClose(true); return; }
  if (k === 'Delete') { e.preventDefault(); if (MV.active) mvRemove(MV.active); return; }
  if (k === '+' || k.toLowerCase() === 'a') { e.preventDefault(); return mvPanel(true); }
  if (k.toLowerCase() === 'g' && MV.active) { e.preventDefault(); return mvMain(MV.active); }
  if (k.toLowerCase() === 'f') { e.preventDefault(); return $('#mvFull').click(); }
  if (k.toLowerCase() === 'm' && MV.active) { MV.active.video.muted = !MV.active.video.muted; return mvRender(); }
  if (/^[1-9]$/.test(k) && MV.tiles[+k - 1]) { e.preventDefault(); return mvSetActive(MV.tiles[+k - 1]); }
});
// les raccourcis globaux ne doivent pas agir pendant le multi-live
document.addEventListener('keydown', e => { if (MV.open && !mvEl.contains(e.target) && ctx.hidden && !anyModal()) { e.stopImmediatePropagation(); mvEl.focus(); mvEl.dispatchEvent(new KeyboardEvent('keydown', { key: e.key, keyCode: e.keyCode, bubbles: false })); e.preventDefault(); } }, true);

$('#mvBack').innerHTML = ic('prev');
$('#mvFull').innerHTML = ic('full');
$('#mvPanelClose').innerHTML = ic('x');
$('#btnMulti').innerHTML = ic('multi');
$('#pbMulti').innerHTML = ic('multi');

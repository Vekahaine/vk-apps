'use strict';
/* =====================================================================
   VkTV — enregistrements (appli PC uniquement : les fichiers vont dans Vidéos\VkTV)
   ===================================================================== */
ICONS.rec = '<circle cx="12" cy="12" r="6.5" fill="currentColor" stroke="none"/>';
ICONS.stop = '<rect x="6.5" y="6.5" width="11" height="11" rx="2" fill="currentColor" stroke="none"/>';
ICONS.cal = '<rect x="3.5" y="5" width="17" height="15" rx="2"/><path d="M3.5 10h17M8 3v4M16 3v4"/>';
const REC = { on: IS_APP && !window.VK_DIRECT, list: [], dir: '', canOpen: false, t: 0 };

async function recLoad() {
  clearTimeout(REC.t);
  if (!REC.on) return;
  try { const r = await (await fetch('api/rec', { cache: 'no-store' })).json(); REC.list = r.list || []; REC.dir = r.dir || ''; REC.canOpen = !!r.canOpen; } catch { }
  recPaint();
  REC.t = setTimeout(recLoad, REC.list.some(r => r.state === 'rec') ? 2000 : 15000);
}
const recActive = key => REC.list.find(r => r.tag === key && r.state === 'rec');
const recPlanned = (key, s) => REC.list.find(r => r.tag === key && (r.state === 'scheduled' || r.state === 'rec') && r.end && Math.abs(r.end / 1000 - (s[1] + 120)) < 300 && r.start / 1000 <= s[0] + 300);
const fmtSize = b => b > 1e9 ? (b / 1e9).toFixed(2).replace('.', ',') + ' Go' : Math.max(0, Math.round(b / 1e6)) + ' Mo';
const fmtDur = ms => fmtT(Math.max(0, ms) / 1000);
const dayHm = t => { const d = new Date(t), today = new Date(); const same = d.toDateString() === today.toDateString(); const tom = new Date(Date.now() + 864e5).toDateString() === d.toDateString(); return (same ? "aujourd'hui" : tom ? 'demain' : d.toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short' })) + ' à ' + hm(t / 1000); };

function recPaint() {
  if (!REC.on) return;
  const any = REC.list.some(r => r.state === 'rec');
  const b = $('#btnRec'); b.hidden = false; b.innerHTML = ic('rec'); b.classList.toggle('on', any);
  b.title = any ? 'Enregistrement en cours — voir mes enregistrements' : 'Mes enregistrements';
  const c = PL.ch, isLive = !!c && c.k === 'live';
  const a = isLive && recActive(c.key);
  const pb = $('#pbRec'); pb.hidden = !isLive; pb.innerHTML = ic(a ? 'stop' : 'rec'); pb.classList.toggle('on', !!a);
  pb.title = a ? "Arrêter l'enregistrement (R)" : 'Enregistrer cette chaîne (R)';
  const ro = $('#recOn'); ro.hidden = !a;
  if (a) ro.textContent = 'REC ' + fmtDur(Date.now() - (a.startedAt || a.start)) + (a.end ? ' / fin ' + hm(a.end / 1000) : '');
  const hr = $('#heroRec'); if (hr) { hr.classList.toggle('on', !!a); hr.innerHTML = a ? `${ic('stop')}Arrêter l'enregistrement` : `${ic('rec')}Enregistrer`; }
  if (!$('#recm').hidden) renderRecs();
  $$('#np .eprec').forEach(x => { const p = JSON.parse(x.dataset.p); const r = recPlanned(x.dataset.k, p); x.classList.toggle('on', !!r); x.textContent = r ? (r.state === 'rec' ? '● Enregistre' : '● Programmé') : 'Enregistrer'; });
}

async function recStart(c, { start, end, title } = {}) {
  try {
    const r = await (await fetch('api/rec', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ tag: c.key, name: c.dn || c.n, title: title || '', urls: variants(c.u), start, end }) })).json();
    if (r.error) throw new Error(r.error);
    const st = r.rec;
    toast(st.state === 'rec' ? `Enregistrement de « ${c.dn || c.n} » lancé${st.end ? ' jusqu\'à ' + hm(st.end / 1000) : ''}` : `Enregistrement programmé ${dayHm(st.start)} · garde VkTV ouvert`);
  } catch (e) { toast(e.message, true); }
  recLoad();
}
async function recStop(id, silent) { await fetch(`api/rec/${id}/stop`, { method: 'POST' }).catch(() => { }); if (!silent) toast('Enregistrement arrêté · fichier dans Vidéos\\VkTV'); recLoad(); }

function recMenu(x, y) {
  const c = PL.ch; if (!c || c.k !== 'live') return;
  const a = recActive(c.key);
  if (a) return recStop(a.id);
  const p = nowProg(c), now = Date.now();
  const items = [{ head: `Enregistrer ${c.dn || c.n}` }];
  if (p && p[1] * 1000 > now + 60e3) items.push({ label: `Jusqu'à la fin de « ${String(p[2]).slice(0, 40)} » (${hm(p[1])})`, icon: 'rec', act: () => recStart(c, { end: p[1] * 1000 + 120e3, title: p[2] }) });
  for (const [l, m] of [['30 minutes', 30], ['1 heure', 60], ['2 heures', 120], ['3 heures', 180]]) items.push({ label: l, icon: 'clock', act: () => recStart(c, { end: now + m * 60e3 }) });
  items.push({ label: "Sans limite (jusqu'à ce que j'arrête)", icon: 'rec', act: () => recStart(c, {}) });
  menu(x, y, items);
}
$('#pbRec').onclick = e => { e.stopPropagation(); const r = e.currentTarget.getBoundingClientRect(); recMenu(r.left, r.top - 8 - 260); };
$('#btnRec').onclick = () => openRecs();

/* boutons « Enregistrer » dans le programme TV */
function recEpBtn(c, p) {
  if (!REC.on || c.k !== 'live' || p[1] * 1000 < Date.now() + 60e3) return '';
  return `<button class="eprec" data-k="${esc(c.key)}" data-p="${esc(JSON.stringify([p[0], p[1], p[2]]))}">Enregistrer</button>`;
}
$('#np').addEventListener('click', e => {
  const b = e.target.closest('.eprec'); if (!b) return;
  e.stopPropagation();
  const c = PL.ch; if (!c) return;
  const p = JSON.parse(b.dataset.p), r = recPlanned(b.dataset.k, p);
  if (r) { recStop(r.id, true); toast(r.state === 'rec' ? 'Enregistrement arrêté' : 'Programmation annulée'); return; }
  recStart(c, { start: Math.max(Date.now(), p[0] * 1000 - 60e3), end: p[1] * 1000 + 120e3, title: p[2] });
});

/* fenêtre « Mes enregistrements » */
function openRecs() { closeMenu(); $('#recm').hidden = false; renderRecs(); recLoad(); }
function renderRecs() {
  const L = REC.list;
  $('#recDir').innerHTML = REC.dir ? `Les fichiers vont dans <b>${esc(REC.dir)}</b> · lisibles avec Films et TV ou VLC${REC.canOpen ? ' · <a href="#" id="recFolder" style="color:var(--acc)">ouvrir le dossier</a>' : ''}` : '';
  const grp = (t, a) => a.length ? `<div class="rec-h">${t}</div>` + a.map(row).join('') : '';
  const row = r => {
    let sub, acts = '';
    if (r.state === 'rec') { sub = `<span class="rec-dot"></span>En cours depuis ${fmtDur(Date.now() - (r.startedAt || r.start))}${r.end ? ' · s\'arrête à ' + hm(r.end / 1000) : ''} · ${fmtSize(r.size)}`; acts = `<button class="btn sm" data-a="stop">${ic('stop')}Arrêter</button>`; }
    else if (r.state === 'scheduled') { sub = `${ic('cal')} ${dayHm(r.start)} → ${hm(r.end / 1000)}`; acts = `<button class="btn sm ghost" data-a="stop">Annuler</button>`; }
    else {
      const bad = r.state === 'missed' ? 'Manqué (VkTV était fermé)' : r.state === 'error' ? 'Erreur : ' + esc(r.error || '') : !r.exists ? 'Fichier supprimé ou déplacé' : '';
      sub = bad || `${dayHm(r.startedAt || r.start)} · ${fmtDur((r.endedAt || Date.now()) - (r.startedAt || r.start))} · ${fmtSize(r.size)}`;
      acts = (r.exists && r.size && REC.canOpen ? `<button class="btn sm" data-a="open">${ic('play')}Regarder</button><button class="btn sm ghost" data-a="show">${ic('folder')}Dossier</button>` : '') + `<button class="ibtn" data-a="del" title="Supprimer">${ic('trash')}</button>`;
    }
    return `<div class="rec-row" data-id="${r.id}"><div><div class="rt">${esc(r.name)}${r.title ? ' — ' + esc(r.title) : ''}</div><div class="rs">${sub}</div></div><div class="ra">${acts}</div></div>`;
  };
  const html = grp('En cours', L.filter(r => r.state === 'rec')) + grp('Programmés', L.filter(r => r.state === 'scheduled')) + grp('Terminés', L.filter(r => !['rec', 'scheduled'].includes(r.state)));
  $('#recBody').innerHTML = html || `<p class="mut" style="padding:8px 4px 16px;line-height:1.6">Aucun enregistrement pour l'instant.<br>Pendant que tu regardes une chaîne, clique sur le <b style="color:#ff4d5e">●</b> rouge en bas du lecteur (ou appuie sur <kbd>R</kbd> en plein écran).<br>Pour une émission à venir, clique sur « Enregistrer » à côté de son horaire dans le programme TV.<br><br>VkTV doit rester ouvert pendant l'enregistrement (tu peux réduire la fenêtre). Ça n'utilise pas de 2e connexion si tu regardes la chaîne enregistrée.</p>`;
}
$('#recm').addEventListener('click', async e => {
  if (e.target.closest('#recFolder')) { e.preventDefault(); fetch('api/rec/folder', { method: 'POST' }); return; }
  const b = e.target.closest('[data-a]'); if (!b) return;
  const id = b.closest('.rec-row').dataset.id, a = b.dataset.a, r = REC.list.find(x => x.id === id);
  if (a === 'stop') return recStop(id, true);
  if (a === 'open' || a === 'show') return fetch(`api/rec/${id}/${a}`, { method: 'POST' });
  if (a === 'del') {
    const withFile = r && r.exists && r.size;
    if (!confirm(withFile ? `Supprimer « ${r.name}${r.title ? ' — ' + r.title : ''} » ?\n\nLe fichier vidéo sera effacé de ton PC (${fmtSize(r.size)}).` : 'Retirer de la liste ?')) return;
    await fetch(`api/rec/${id}${withFile ? '?file=1' : ''}`, { method: 'DELETE' }); recLoad();
  }
});

/* le lecteur prévient le serveur quand il quitte une chaîne (l'enregistreur prend le relais tout de suite) */
function recLeave(tag) { if (REC.on && tag) try { navigator.sendBeacon('api/rec/leave?t=' + encodeURIComponent(tag)); } catch { } }

recLoad();

/* =====================================================================
   VkTV — mode autonome (appli Android) : remplace le petit serveur du PC.
   Les flux et playlists sont lus directement depuis le fournisseur ;
   réglages dans le stockage de l'appli, playlists et guide en cache local.
   ===================================================================== */
(function () {
  const qs = new URLSearchParams(location.search);
  if (!(qs.has('android') || qs.has('standalone') || window.Android)) return;
  window.VK_DIRECT = true;
  // version de l'appli Android (APK) : demandée à l'appli ; l'interface, elle, se met à jour toute seule (voir update-ui.js)
  window.VK_APK = { code: 8, version: '1.4.1' };
  try { if (window.Android && Android.appCode) window.VK_APK = { code: +Android.appCode(), version: String(Android.appVersion()) }; } catch { }
  const realFetch = window.fetch.bind(window);
  const PL_TTL = 12 * 3600e3, EPG_TTL = 6 * 3600e3;
  const progress = {};

  /* ---------- petite base locale (IndexedDB) pour les gros fichiers */
  let dbp = null;
  const db = () => dbp || (dbp = new Promise((res, rej) => { const r = indexedDB.open('vktv', 1); r.onupgradeneeded = () => r.result.createObjectStore('kv'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); }));
  async function idb(op, key, val) {
    try {
      const d = await db();
      return await new Promise((res, rej) => { const t = d.transaction('kv', op === 'get' ? 'readonly' : 'readwrite'), st = t.objectStore('kv'); const r = op === 'get' ? st.get(key) : op === 'del' ? st.delete(key) : st.put(val, key); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
    } catch { return undefined; }
  }
  const lsGet = (k, d) => { try { const v = localStorage.getItem('vk.' + k); return v == null ? d : JSON.parse(v); } catch { return d; } };
  const lsSet = (k, v) => { try { localStorage.setItem('vk.' + k, JSON.stringify(v)); } catch { } };
  const state = () => lsGet('server-state', {});
  const findPl = id => (state().playlists || []).find(p => p.id === id) || null;

  const json = (o, code = 200, h = {}) => new Response(JSON.stringify(o), { status: code, headers: { 'content-type': 'application/json', ...h } });
  const text = (t, h = {}) => new Response(t, { status: 200, headers: { 'content-type': 'text/plain; charset=utf-8', ...h } });

  /* ---------- téléchargement avec suivi et coupure si le fournisseur ne répond plus */
  async function download(url, pid, { sniff, idle = 60000, max = 15 * 60000 } = {}) {
    const ctl = new AbortController();
    let tIdle = setTimeout(() => ctl.abort(), idle);
    const tMax = setTimeout(() => ctl.abort(), max);
    try {
      const r = await realFetch(url, { signal: ctl.signal, cache: 'no-store' });
      if (!r.ok) { const e = new Error(`le serveur a répondu ${r.status}`); e.status = r.status; throw e; }
      const ctype = (r.headers.get('content-type') || '').toLowerCase();
      const reader = r.body.getReader(), chunks = []; let n = 0, decided = !sniff;
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        clearTimeout(tIdle); tIdle = setTimeout(() => ctl.abort(), idle);
        chunks.push(value); n += value.length;
        if (pid) progress[pid] = Object.assign(progress[pid] || {}, { bytes: (progress[pid] && progress[pid].bytes0 || 0) + n });
        if (!decided && n >= 65536) { decided = true; const first = concat(chunks); const s = sniff(first, ctype); if (s) { try { ctl.abort(); } catch { } return s; } }
      }
      const all = concat(chunks);
      if (!decided) { const s = sniff(all, ctype); if (s) return s; }
      return all;
    } catch (e) { if (e.name === 'AbortError') throw new Error('le fournisseur ne répond plus'); if (e instanceof TypeError) throw new Error('fournisseur injoignable (connexion internet ?)'); throw e; }
    finally { clearTimeout(tIdle); clearTimeout(tMax); }
  }
  function concat(chunks) { let n = 0; for (const c of chunks) n += c.length; const out = new Uint8Array(n); let o = 0; for (const c of chunks) { out.set(c, o); o += c.length; } return out; }
  const dec = b => new TextDecoder('utf-8').decode(b);
  async function gunzipIfNeeded(b) {
    if (!(b[0] === 0x1f && b[1] === 0x8b) || typeof DecompressionStream === 'undefined') return b;
    const s = new Blob([b]).stream().pipeThrough(new DecompressionStream('gzip'));
    return new Uint8Array(await new Response(s).arrayBuffer());
  }

  /* ---------- playlists */
  const xtBase = p => { let s = String(p.server || '').trim().replace(/\/+$/, ''); if (s && !/^https?:\/\//i.test(s)) s = 'http://' + s; return s; };
  const playlistUrl = p => p.type === 'xtream' ? xtBase(p) + '/get.php?' + new URLSearchParams({ username: p.user || '', password: p.pass || '', type: 'm3u_plus', output: 'ts' }) : String(p.url || '').trim();
  function looksLikeStream(first, ctype) {
    const h = new TextDecoder('latin1').decode(first.subarray(0, 20000));
    if (/#EXT-X-TARGETDURATION|#EXT-X-STREAM-INF|#EXT-X-MEDIA-SEQUENCE/.test(h)) return true;
    if (/#EXTINF/.test(h) || /^\s*#EXTM3U/.test(h)) return false;
    if (first[0] === 0x1f && first[1] === 0x8b) return false;
    if (first.length > 376 && first[0] === 0x47 && first[188] === 0x47) return true;
    return /^(video|audio)\//.test(ctype) && !/mpegurl/.test(ctype);
  }
  const single = (p, url) => `#EXTM3U\n#EXTINF:-1 group-title="Mes flux",${String(p.name || 'Mon flux').replace(/[,\n\r]/g, ' ')}\n${url}\n`;
  async function m3u(p, pid) {
    const url = playlistUrl(p);
    if (!/^https?:\/\//i.test(url)) throw new Error('lien de playlist invalide (il doit commencer par http:// ou https://)');
    progress[pid] = { step: 'Téléchargement de la playlist', bytes: 0 };
    let b = await download(url, pid, { sniff: (f, ct) => looksLikeStream(f, ct) ? single(p, url) : null });
    if (typeof b === 'string') return b;
    b = await gunzipIfNeeded(b);
    const t = dec(b);
    if (!/#EXTINF/.test(t.slice(0, 300000))) { const sn = t.slice(0, 160).replace(/\s+/g, ' ').trim(); throw new Error(sn ? `le lien ne renvoie pas une playlist (réponse : « ${sn} »)` : 'le lien renvoie une playlist vide'); }
    return t;
  }
  async function xtJson(p, action, pid) {
    const q = { username: p.user || '', password: p.pass || '' }; if (action) q.action = action;
    const b = await download(xtBase(p) + '/player_api.php?' + new URLSearchParams(q), pid);
    const t = dec(b);
    try { return JSON.parse(t); } catch { const sn = t.slice(0, 160).replace(/\s+/g, ' ').trim(); throw new Error(sn ? `réponse inattendue du serveur (« ${sn} »)` : 'réponse vide du serveur'); }
  }
  async function xtAuth(p, pid) {
    let info;
    try { info = await xtJson(p, null, pid); } catch (e) { throw new Error(`serveur Xtream injoignable (${e.message}) — vérifie l'adresse du serveur, avec le port (ex : http://exemple.com:8080)`); }
    const u = info && info.user_info;
    if (!u) throw new Error("ce serveur ne répond pas comme un serveur Xtream — vérifie l'adresse");
    if (String(u.auth) !== '1') throw new Error('identifiant ou mot de passe refusé par le fournisseur');
    const st = String(u.status || '').toLowerCase();
    if (st && st !== 'active') throw new Error(`abonnement « ${u.status} » chez le fournisseur${u.exp_date ? ' (fin : ' + new Date(+u.exp_date * 1000).toLocaleDateString('fr-FR') + ')' : ''}`);
    return info;
  }
  const qe = s => String(s == null ? '' : s).replace(/"/g, "'").replace(/[\r\n]+/g, ' ').trim();
  async function xtApi(p, pid) {
    progress[pid] = { step: 'Connexion à ton abonnement', bytes: 0 };
    await xtAuth(p, pid);
    const base = xtBase(p), U = encodeURIComponent(p.user || ''), P = encodeURIComponent(p.pass || ''), out = ['#EXTM3U'];
    const grab = async (ca, la, label) => {
      progress[pid].step = 'Récupération : ' + label;
      const [cats, items] = await Promise.all([xtJson(p, ca, pid).catch(() => []), xtJson(p, la, pid).catch(() => [])]);
      const name = new Map(), order = new Map();
      (Array.isArray(cats) ? cats : []).forEach((c, i) => { name.set(String(c.category_id), c.category_name); order.set(String(c.category_id), i); });
      const list = Array.isArray(items) ? items : Object.values(items || {});
      list.sort((a, b) => (order.get(String(a.category_id)) ?? 1e9) - (order.get(String(b.category_id)) ?? 1e9) || (+a.num || 0) - (+b.num || 0));
      return { list, name };
    };
    const live = await grab('get_live_categories', 'get_live_streams', 'chaînes');
    for (const s of live.list) { out.push(`#EXTINF:-1 tvg-id="${qe(s.epg_channel_id)}" tvg-name="${qe(s.name)}" tvg-logo="${qe(s.stream_icon)}" group-title="${qe(live.name.get(String(s.category_id)) || 'Sans catégorie')}",${qe(s.name)}`); out.push(`${base}/live/${U}/${P}/${s.stream_id}.ts`); }
    const vod = await grab('get_vod_categories', 'get_vod_streams', 'films');
    for (const s of vod.list) { out.push(`#EXTINF:-1 tvg-name="${qe(s.name)}" tvg-logo="${qe(s.stream_icon)}" group-title="${qe(vod.name.get(String(s.category_id)) || 'Films')}",${qe(s.name)}`); out.push(`${base}/movie/${U}/${P}/${s.stream_id}.${s.container_extension || 'mp4'}`); }
    if (out.length < 3) throw new Error('ton abonnement ne contient aucune chaîne (compte vide ou bloqué ?)');
    return out.join('\n') + '\n';
  }
  const jobs = {};
  async function getPlaylist(pid, refresh) {
    const p = findPl(pid);
    const cached = await idb('get', 'pl:' + pid);
    if (!p || p.type === 'file') { if (!cached) throw new Error('Playlist introuvable — ré-importe ton fichier'); return { text: cached.text, stale: false }; }
    if (cached && !refresh && Date.now() - cached.at < PL_TTL) return { text: cached.text, stale: false };
    if (!jobs[pid]) jobs[pid] = (async () => {
      let t;
      if (p.type !== 'xtream') t = await m3u(p, pid);
      else { try { t = await m3u(p, pid); } catch (e) { t = await xtApi(p, pid); } }
      await idb('put', 'pl:' + pid, { text: t, at: Date.now() });
      return t;
    })().finally(() => { delete jobs[pid]; setTimeout(() => { delete progress[pid]; }, 5000); });
    try { return { text: await jobs[pid], stale: false }; }
    catch (e) { if (cached) return { text: cached.text, stale: true, error: e.message }; const m = e.message || String(e); throw new Error(m.charAt(0).toUpperCase() + m.slice(1)); }
  }

  /* ---------- guide des programmes (XMLTV), lu en continu pour économiser la mémoire */
  function xmltvTime(s) {
    const m = String(s || '').trim().match(/^(\d{4})(\d{2})(\d{2})(\d{2})?(\d{2})?(\d{2})?\s*([+-]\d{4})?/); if (!m) return NaN;
    let t = Date.UTC(+m[1], +m[2] - 1, +m[3], +(m[4] || 0), +(m[5] || 0), +(m[6] || 0)) / 1000;
    if (m[7]) { const z = m[7]; t -= (z[0] === '+' ? 1 : -1) * (+z.slice(1, 3) * 3600 + +z.slice(3, 5) * 60); }
    return t;
  }
  const ent = s => s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;|&#39;/g, "'").replace(/&#(\d+);/g, (_, n) => String.fromCharCode(+n)).replace(/&amp;/g, '&').trim();
  async function buildEpg(url) {
    const now = Date.now() / 1000, lo = now - 4 * 3600, hi = now + 30 * 3600, out = {};
    const r = await realFetch(url, { cache: 'no-store' });
    if (!r.ok) throw new Error('EPG ' + r.status);
    let stream = r.body;
    const gz = /\.gz(\?|$)/i.test(url) || /gzip/.test(r.headers.get('content-type') || '');
    if (gz && typeof DecompressionStream !== 'undefined') stream = stream.pipeThrough(new DecompressionStream('gzip'));
    const reader = stream.pipeThrough(new TextDecoderStream()).getReader();
    let buf = '';
    const re = /<programme\b([^>]*)>([\s\S]*?)<\/programme>/g;
    for (;;) {
      const { value, done } = await reader.read();
      if (value) buf += value;
      let m, last = 0; re.lastIndex = 0;
      while ((m = re.exec(buf))) {
        last = re.lastIndex;
        const a = m[1], attr = k => { const x = a.match(new RegExp(k + '="([^"]*)"')); return x ? x[1] : ''; };
        const s = xmltvTime(attr('start')), e = xmltvTime(attr('stop'));
        if (!(e > lo && s < hi)) continue;
        const t = (m[2].match(/<title[^>]*>([\s\S]*?)<\/title>/) || [])[1] || '', d = (m[2].match(/<desc[^>]*>([\s\S]*?)<\/desc>/) || [])[1] || '';
        const ch = ent(attr('channel')).toLowerCase();
        (out[ch] = out[ch] || []).push([s, e, ent(t), ent(d).slice(0, 280)]);
      }
      buf = last ? buf.slice(last) : buf.length > 2e6 ? buf.slice(-200000) : buf;
      if (done) break;
    }
    for (const k in out) out[k].sort((x, y) => x[0] - y[0]);
    return out;
  }
  async function getEpg(pid, refresh) {
    const c = await idb('get', 'epg:' + pid);
    if (c && !refresh && Date.now() - c.at < EPG_TTL) return c.data;
    const p = findPl(pid);
    let url = p && String(p.epg || '').trim();
    if (!url && p && p.type === 'xtream') url = xtBase(p) + '/xmltv.php?' + new URLSearchParams({ username: p.user || '', password: p.pass || '' });
    if (!url) { const pl = await idb('get', 'pl:' + pid); const m = pl && pl.text.slice(0, 4096).match(/(?:url-tvg|x-tvg-url)="([^"]+)"/); if (m) url = m[1].split(',')[0].trim(); }
    if (!url) return c ? c.data : {};
    try { const data = await buildEpg(url); await idb('put', 'epg:' + pid, { data, at: Date.now() }); return data; }
    catch (e) { console.log('[EPG]', e.message); return c ? c.data : {}; }
  }

  /* ---------- compte en ligne (VkCloud) */
  const cloudCfg = () => lsGet('cloud', null);
  const CS = { lastSync: 0, error: '' };
  function resolveUrl(a) {
    a = String(a || '').trim().replace(/\/+$/, '');
    if (!a) throw new Error('Indique le nom de ton compte');
    if (/^https?:\/\//i.test(a)) return a;
    if (/\.workers\.dev$/i.test(a)) return 'https://' + a;
    const sub = a.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9-]/g, '');
    if (!sub) throw new Error('Nom de compte invalide');
    return `https://vkcloud.${sub}.workers.dev`;
  }
  async function ccall(method, p, body, raw) {
    const c = cloudCfg(); if (!c) throw new Error('non connecté');
    const r = await realFetch(c.url + p, { method, cache: 'no-store', headers: { Authorization: 'Bearer ' + c.token, ...(body && !raw ? { 'Content-Type': 'application/json' } : {}) }, body: raw ? body : body ? JSON.stringify(body) : undefined });
    if (r.status === 401) { lsSet('cloud', null); CS.error = 'Connexion expirée : reconnecte-toi à ton compte'; throw new Error(CS.error); }
    return r;
  }
  const gz = async u8 => typeof CompressionStream === 'undefined' ? null : new Uint8Array(await new Response(new Blob([u8]).stream().pipeThrough(new CompressionStream('gzip'))).arrayBuffer());
  let pushT = null;
  const isGuest = () => (cloudCfg() || {}).role === 'guest';
  const cPush = (d = 4000) => { if (!cloudCfg() || isGuest()) return; clearTimeout(pushT); pushT = setTimeout(() => cPushNow().catch(() => { }), d); };
  async function cPushNow() {
    const c = cloudCfg(), st = state(); if (!c || !st.v || isGuest()) return;
    try {
      const r = await ccall('PUT', '/api/tv', st);
      if (r.status === 409) return cPull();
      c.files = c.files || {};
      for (const p of st.playlists || []) {
        if (p.type !== 'file') continue;
        const cached = await idb('get', 'pl:' + p.id); if (!cached || c.files[p.id] === cached.at) continue;
        const z = await gz(new TextEncoder().encode(cached.text)); if (!z) continue;
        if ((await ccall('PUT', '/api/tv/file/' + p.id, z, true)).ok) { c.files[p.id] = cached.at; lsSet('cloud', c); }
      }
      CS.lastSync = Date.now(); CS.error = '';
    } catch (e) { CS.error = e.message; }
  }
  async function cPull(force) {
    if (!cloudCfg() || isGuest()) return;
    try {
      const remote = await (await ccall('GET', '/api/tv')).json(), local = state();
      if (remote && remote.v && (force || (remote.ts || 0) > (local.ts || 0))) {
        remote.settings = { ...(remote.settings || {}) };
        for (const k of ['format', 'rewind', 'tv', 'tvAuto', 'm1']) { if ((local.settings || {})[k] !== undefined) remote.settings[k] = local.settings[k]; else delete remote.settings[k]; }
        if (force) remote.ts = Date.now();
        for (const p of remote.playlists || []) {
          if (p.type !== 'file' || await idb('get', 'pl:' + p.id)) continue;
          try { const r = await ccall('GET', '/api/tv/file/' + p.id); if (r.ok) { const t = dec(await gunzipIfNeeded(new Uint8Array(await r.arrayBuffer()))); const at = Date.now(); await idb('put', 'pl:' + p.id, { text: t, at }); const c = cloudCfg(); c.files = c.files || {}; c.files[p.id] = at; lsSet('cloud', c); } } catch { }
        }
        lsSet('server-state', remote);
      } else if (!remote || !remote.v || (local.ts || 0) > (remote.ts || 0)) cPush(500);
      CS.lastSync = Date.now(); CS.error = '';
    } catch (e) { CS.error = e.message; }
  }
  const cView = () => { const c = cloudCfg(); return c ? { connected: true, account: c.account, url: c.url, storage: !!c.storage, guest: c.role === 'guest', web: c.url + '/#t=' + c.token, lastSync: CS.lastSync, error: CS.error } : { connected: false, error: CS.error }; };
  async function cloudRoute(path, method, init) {
    const b = method === 'POST' && init.body ? JSON.parse(init.body) : {};
    if (path === 'cloud') return json(cView());
    if (path === 'cloud/login') {
      let url; try { url = resolveUrl(b.account); } catch (e) { return json({ error: e.message }, 400); }
      let r; try { r = await realFetch(url + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password: b.password || '' }) }); }
      catch { return json({ error: `Compte « ${b.account} » introuvable (vérifie le nom et ta connexion internet)` }, 400); }
      const j = await r.json().catch(() => ({}));
      if (!r.ok || !j.token) return json({ error: j.error ? j.error.charAt(0).toUpperCase() + j.error.slice(1) : `Compte « ${b.account} » introuvable` }, 400);
      let storage = false; try { storage = !!(await (await realFetch(url + '/api/ping')).json()).storage; } catch { }
      lsSet('cloud', { account: String(b.account).trim().toLowerCase(), url, token: j.token, storage, role: j.role || 'owner', files: {} }); CS.error = '';
      await cPull(true);
      return json(cView());
    }
    if (path === 'cloud/logout') { lsSet('cloud', null); return json(cView()); }
    if (path === 'cloud/sync') { await cPull(); await cPushNow(); return json(cView()); }
    return json({ error: 'Crée ton compte depuis VkTV sur ton PC' }, 400);
  }
  setTimeout(() => cPull(), 1500);
  setInterval(() => { if (!document.hidden) cPull(); }, 90e3);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) cPull(); });

  /* ---------- aiguillage des appels « api/… » de l'appli */
  window.fetch = async function (input, init = {}) {
    const url = typeof input === 'string' ? input : input && input.url || '';
    const m = url.match(/^(?:\.?\/)?api\/([^?#]+)(?:\?([^#]*))?/) || url.match(/^file:\/\/\/android_asset\/www\/api\/([^?#]+)(?:\?([^#]*))?/);
    if (!m) return realFetch(input, init);
    const path = m[1], q = new URLSearchParams(m[2] || ''), method = (init.method || 'GET').toUpperCase();
    try {
      if (path === 'state') {
        if (method === 'PUT') { lsSet('server-state', JSON.parse(init.body)); cPush(); const st = state(); for (const k of await listKeys()) { const id = k.split(':')[1]; if (!(st.playlists || []).some(p => p.id === id)) idb('del', k); } return json({ ok: true }); }
        { const st = state(), since = +q.get('since') || 0; if (since && (st.ts || 0) <= since) return new Response(null, { status: 204 }); return json(st); }
      }
      if (path === 'info') return json({ port: 0, lan: [], standalone: true });
      if (path === 'cloud' || path.startsWith('cloud/')) return await cloudRoute(path, method, init);
      let mm;
      if ((mm = path.match(/^progress\/([\w-]+)$/))) return json(progress[mm[1]] || {});
      if ((mm = path.match(/^playlist\/([\w-]+)\/file$/)) && method === 'POST') {
        const b = init.body instanceof Blob ? new Uint8Array(await init.body.arrayBuffer()) : new TextEncoder().encode(String(init.body || ''));
        await idb('put', 'pl:' + mm[1], { text: dec(await gunzipIfNeeded(b)), at: Date.now() });
        cPush();
        return json({ ok: true });
      }
      if ((mm = path.match(/^playlist\/([\w-]+)$/))) {
        try { const r = await getPlaylist(mm[1], q.has('refresh')); return text(r.text, { 'X-Stale': r.stale ? '1' : '0', 'X-Error': r.error ? encodeURIComponent(r.error) : '' }); }
        catch (e) { return json({ error: e.message }, 502); }
      }
      if ((mm = path.match(/^epg\/([\w-]+)$/))) return json(await getEpg(mm[1], q.has('refresh')));
      if ((mm = path.match(/^account\/([\w-]+)$/))) {
        const p = findPl(mm[1]); if (!p || p.type !== 'xtream') return json({});
        try { const u = (await xtJson(p, null, null)).user_info || {}; return json({ max_connections: u.max_connections, active_cons: u.active_cons, status: u.status, exp_date: u.exp_date }); } catch { return json({}); }
      }
      return json({ error: 'inconnu' }, 404);
    } catch (e) { return json({ error: String(e.message || e) }, 500); }
  };
  async function listKeys() {
    try { const d = await db(); return await new Promise(res => { const r = d.transaction('kv').objectStore('kv').getAllKeys(); r.onsuccess = () => res(r.result || []); r.onerror = () => res([]); }); } catch { return []; }
  }
})();

'use strict';
/* =====================================================================
   VkTV — « Mon compte en ligne » : retrouver playlists, codes, favoris et séries partout
   ===================================================================== */
ICONS.cloud = '<path d="M7 18a4.5 4.5 0 0 1-.6-8.96A6 6 0 0 1 18 9.5a4 4 0 0 1-.5 8.5z"/>';
ICONS.user = '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>';
ICONS.ext = '<path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>';
let CLOUD = { connected: false };
const ago = t => { if (!t) return 'jamais'; const s = Math.round((Date.now() - t) / 1000); return s < 60 ? "à l'instant" : s < 3600 ? `il y a ${Math.round(s / 60)} min` : `il y a ${Math.round(s / 3600)} h`; };
async function cloudGet() { try { CLOUD = await (await fetch('api/cloud', { cache: 'no-store' })).json(); } catch { CLOUD = { connected: false }; } return CLOUD; }
async function cloudPost(p, body) {
  const r = await fetch('api/cloud' + p, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body || {}) });
  const j = await r.json().catch(() => ({})); if (!r.ok || j.error) throw new Error(j.error || 'erreur'); return j;
}
// ouvre les séries en ligne : dans la même fenêtre sur Android (retour = revenir à VkTV), sinon dans le navigateur
function openSeriesWeb() {
  if (!CLOUD.web) return;
  if (window.VK_DIRECT) location.href = CLOUD.web; else window.open(CLOUD.web, '_blank');
}

async function fillCloud() {
  const box = $('#cloudBox'); if (!box) return;
  const c = await cloudGet();
  if (c.connected && c.guest) {
    box.innerHTML = `<div class="cl-row"><span class="cl-ic on">${ic('cloud')}</span><div class="grow"><b>Connecté au compte « ${esc(c.account)} » en invité</b><small>Tu peux regarder les séries mises en ligne. Tes playlists TV restent les tiennes, rien n'est partagé.</small></div></div>
      <div class="cl-acts"><button class="btn sm" id="clWeb">${ic('series')}Mes séries en ligne</button><button class="btn sm ghost" id="clOut">Se déconnecter</button></div>`;
    $('#clWeb').onclick = openSeriesWeb;
    $('#clOut').onclick = async () => { await cloudPost('/logout').catch(() => { }); fillCloud(); };
    return;
  }
  if (c.connected) {
    box.innerHTML = `<div class="cl-row"><span class="cl-ic on">${ic('cloud')}</span><div class="grow"><b>Connecté au compte « ${esc(c.account)} »</b><small>${c.error ? `<span style="color:#ff6b6b">${esc(c.error)}</span>` : `Synchronisé ${ago(c.lastSync)} · playlists, codes, favoris, catégories et listes`}</small></div></div>
      <div class="cl-acts"><button class="btn sm" id="clSync">${ic('refresh')}Synchroniser</button>${c.storage ? `<button class="btn sm ghost" id="clWeb">${ic('series')}Mes séries en ligne</button>` : ''}<button class="btn sm ghost" id="clOut">Se déconnecter</button></div>
      ${!c.storage && c.owner ? `<p class="mut" style="margin:10px 0 0">Pour mettre tes séries en ligne, branche ton stockage en ligne dans <b>VkSéries → En ligne</b>.</p>` : ''}
      <p class="mut" style="margin:10px 0 0">Sur un autre appareil (téléphone, box TV, autre PC) : VkTV → Paramètres → <b>Se connecter</b>, nom du compte <b>${esc(c.account)}</b> et ton mot de passe.</p>`;
    $('#clSync').onclick = async e => { e.currentTarget.disabled = true; try { await cloudPost('/sync'); await pullRemote(); toast('Synchronisé'); } catch (er) { toast(er.message, true); } fillCloud(); };
    $('#clOut').onclick = async () => { if (!confirm('Se déconnecter du compte sur cet appareil ?\n\nTes playlists restent sur cet appareil, mais elles ne seront plus synchronisées.')) return; await cloudPost('/logout').catch(() => { }); fillCloud(); };
    const w = $('#clWeb'); if (w) w.onclick = openSeriesWeb;
    return;
  }
  box.innerHTML = `<div class="cl-row"><span class="cl-ic">${ic('cloud')}</span><div class="grow"><b>Retrouve tout sur tes autres appareils</b><small>Tes playlists, codes, favoris et catégories sur ton téléphone, ta box TV ou un autre PC, sans rien retaper. Et tes séries VkSéries en ligne.</small></div></div>
    <div class="cl-acts"><button class="btn sm" id="clLogin">${ic('user')}Se connecter</button>${c.pc ? `<button class="btn sm ghost" id="clNew">${ic('plus')}Créer mon compte</button>` : ''}</div>
    ${c.pc ? '' : '<p class="mut" style="margin:10px 0 0">Pas encore de compte ? Crée-le depuis VkTV sur ton PC (Paramètres → Mon compte en ligne).</p>'}`;
  $('#clLogin').onclick = openCloudLogin;
  const n = $('#clNew'); if (n) n.onclick = openCloudSetup;
}

function cloudModal(html) { const m = $('#cloudm'); $('#cloudBody').innerHTML = html; m.hidden = false; setTimeout(() => $('#cloudBody input')?.focus(), 30); }
function openCloudLogin() {
  $('#cloudTitle').textContent = 'Se connecter à mon compte';
  cloudModal(`<form id="clf" class="cl-form"><label>Nom du compte<input id="clAcc" placeholder="ex : volkan" autocomplete="username" autocapitalize="off" spellcheck="false"></label>
    <label>Mot de passe<input id="clPw" type="password" autocomplete="current-password"></label>
    <div class="err" id="clErr"></div><button class="btn" type="submit" id="clGo">${ic('user')}Se connecter</button></form>`);
  $('#clf').onsubmit = async e => {
    e.preventDefault(); const b = $('#clGo'); b.disabled = true; $('#clErr').textContent = '';
    try {
      const r = await cloudPost('/login', { account: $('#clAcc').value.trim(), password: $('#clPw').value });
      $('#cloudm').hidden = true;
      if (r.guest) { toast('Connecté en invité ✓ tu peux regarder les séries en ligne'); renderSettings(); }
      else { await pullRemote(true); toast('Connecté ✓ tes playlists et favoris arrivent'); renderSettings(); }
    } catch (er) { $('#clErr').textContent = er.message; b.disabled = false; }
  };
}
function openCloudSetup() {
  $('#cloudTitle').textContent = 'Créer mon compte en ligne';
  cloudModal(`<div class="cl-steps">
    <p class="mut" style="margin-top:0">Ton compte est un petit serveur <b>rien qu'à toi</b>, hébergé gratuitement chez Cloudflare. Tu le crées une seule fois, ici, en 3 minutes.</p>
    <div class="cl-step"><span>1</span><div><b>Crée un compte Cloudflare gratuit</b> (ou connecte-toi) et confirme ton e-mail.<br><a class="btn sm ghost" href="https://dash.cloudflare.com/sign-up" target="_blank">${ic('ext')}Ouvrir Cloudflare</a></div></div>
    <div class="cl-step"><span>2</span><div><b>Crée un jeton</b> : Profil → Jetons d'API → <b>Créer un jeton</b> → modèle <b>« Edit Cloudflare Workers »</b> (« Modifier Cloudflare Workers ») → <b>Utiliser le modèle</b> → Ressources du compte : ton compte · Ressources de zone : <b>Toutes les zones</b> → Continuer → <b>Créer le jeton</b> → copie-le.<br><a class="btn sm ghost" href="https://dash.cloudflare.com/profile/api-tokens" target="_blank">${ic('ext')}Ouvrir les jetons</a></div></div>
    <form id="cls" class="cl-form">
      <label>Jeton Cloudflare<input id="clTok" placeholder="colle le jeton ici" autocomplete="off" spellcheck="false"></label>
      <label>Nom du compte <small class="mut">(lettres et chiffres, c'est ce que tu taperas sur tes autres appareils)</small><input id="clName" placeholder="ex : volkan" autocapitalize="off" spellcheck="false"></label>
      <label>Mot de passe<input id="clP1" type="password" autocomplete="new-password"></label>
      <label>Mot de passe (encore)<input id="clP2" type="password" autocomplete="new-password"></label>
      <div class="err" id="clErr"></div>
      <button class="btn" type="submit" id="clGo">${ic('cloud')}Créer mon compte</button>
    </form><div class="cl-prog" id="clProg" hidden><div class="spin"></div><span id="clStep">…</span></div></div>`);
  $('#cls').onsubmit = async e => {
    e.preventDefault(); $('#clErr').textContent = '';
    const tok = $('#clTok').value.trim(), name = $('#clName').value.trim(), p1 = $('#clP1').value;
    if (!tok) return $('#clErr').textContent = 'Colle le jeton Cloudflare (étape 3)';
    if (p1.length < 4) return $('#clErr').textContent = 'Mot de passe : 4 caractères minimum';
    if (p1 !== $('#clP2').value) return $('#clErr').textContent = 'Les deux mots de passe sont différents';
    try { await cloudPost('/setup', { cfToken: tok, name, password: p1 }); } catch (er) { return $('#clErr').textContent = er.message; }
    $('#cls').hidden = true; $('#clProg').hidden = false;
    const poll = async () => {
      const c = await cloudGet(), s = c.setup || {};
      if (s.error) { $('#clProg').hidden = true; $('#cls').hidden = false; $('#clErr').textContent = s.error; return; }
      if (s.done) {
        $('#cloudBody').innerHTML = `<div class="cl-done">${ic('check')}<h3>C'est prêt !</h3><p>Ton compte <b>« ${esc(s.account)} »</b> est créé et tes playlists sont déjà en ligne.</p>
          <p>Sur ton téléphone, ta box TV ou un autre PC : <b>VkTV → Paramètres → Se connecter</b>, avec le nom <b>${esc(s.account)}</b> et ton mot de passe.</p>
          ${s.storage ? '<p>✓ Le stockage des vidéos est activé : dans VkSéries, tu peux mettre tes séries en ligne.</p>' : '<p class="mut">Pour mettre tes séries en ligne : dans VkSéries → En ligne, branche ton stockage en ligne (ex. Railway).</p>'}
          <button class="btn" data-close>OK</button></div>`;
        renderSettings(); return;
      }
      $('#clStep').textContent = (s.step || 'Installation') + '…';
      setTimeout(poll, 900);
    };
    poll();
  };
}
$('#cloudm').addEventListener('click', e => { if (e.target.closest('[data-close]')) $('#cloudm').hidden = true; });

'use strict';
/* =====================================================================
   VkTV — lecteur IPTV
   ===================================================================== */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = () => Math.random().toString(36).slice(2, 10);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const isTouch = matchMedia('(pointer:coarse)').matches;
function norm(s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\+/g, ' plus ').replace(/[^a-z0-9]+/g, ' ').trim(); }

/* ------------------------------------------------------------ icônes */
const ICONS = {
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  star: '<path d="M12 3.6l2.6 5.2 5.8.9-4.2 4.1 1 5.8L12 16.9l-5.2 2.7 1-5.8-4.2-4.1 5.8-.9z"/>',
  cog: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  layers: '<path d="m12 3 9 5-9 5-9-5z"/><path d="m3 13 9 5 9-5"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  play: '<path d="M7 4.8v14.4L19 12z" fill="currentColor"/>',
  pause: '<path d="M7 4.5h3.4v15H7zM13.6 4.5H17v15h-3.4z" fill="currentColor"/>',
  vol: '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13"/>',
  mute: '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="m16 9.5 5 5m0-5-5 5"/>',
  full: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
  unfull: '<path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/>',
  pip: '<rect x="3" y="5" width="18" height="14" rx="2"/><rect x="12" y="11" width="7" height="6" rx="1" fill="currentColor"/>',
  prev: '<path d="m15 6-6 6 6 6"/>', next: '<path d="m9 6 6 6-6 6"/>',
  up: '<path d="M12 19V5M6 11l6-6 6 6"/>',
  eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  eyeoff: '<path d="M3 3l18 18M10.6 5.1A10 10 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-3.2 4.1M6.6 6.6A17 17 0 0 0 2 12s3.5 7 10 7a9.6 9.6 0 0 0 5.4-1.6M9.9 9.9a3 3 0 0 0 4.2 4.2"/>',
  grip: '<circle cx="9" cy="6" r="1.3" fill="currentColor"/><circle cx="15" cy="6" r="1.3" fill="currentColor"/><circle cx="9" cy="12" r="1.3" fill="currentColor"/><circle cx="15" cy="12" r="1.3" fill="currentColor"/><circle cx="9" cy="18" r="1.3" fill="currentColor"/><circle cx="15" cy="18" r="1.3" fill="currentColor"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  refresh: '<path d="M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7"/>',
  list: '<path d="M9 6h11M9 12h11M9 18h11M4 6h.01M4 12h.01M4 18h.01"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  tv: '<rect x="3" y="6" width="18" height="13" rx="2"/><path d="m8 2 4 4 4-4"/>',
  film: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 4v16M17 4v16M3 9h4M3 15h4M17 9h4M17 15h4"/>',
  series: '<rect x="2" y="7" width="20" height="13" rx="2"/><path d="M6 3h12M10 11v5l4-2.5z"/>',
  copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  check: '<path d="m5 12 5 5 9-10"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  grid: '<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>',
  bolt: '<path d="M13 2 4 14h7l-1 8 9-12h-7z" fill="currentColor" stroke="none"/>',
  multi: '<rect x="3" y="4" width="8" height="7" rx="1.5"/><rect x="13" y="4" width="8" height="7" rx="1.5"/><rect x="3" y="13" width="8" height="7" rx="1.5"/><rect x="13" y="13" width="8" height="7" rx="1.5" fill="currentColor"/>',
  expand: '<path d="M14 4h6v6M10 20H4v-6M20 4l-7 7M4 20l7-7"/>',
  swap: '<path d="M7 7h13M16 3l4 4-4 4M17 17H4M8 13l-4 4 4 4"/>',
  down: '<path d="M12 5v14M6 13l6 6 6-6"/>',
};
const ic = (n, c = '') => `<svg class="i ${c}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${ICONS[n] || ''}</svg>`;

/* ------------------------------------------------------------ état */
const ACCENTS = ['#e50914', '#ff5a36', '#7c5cff', '#2f9bff', '#16c79a', '#ff3d7f', '#f5b400'];
const DEFAULT = () => ({
  v: 1, ts: 0, playlists: [], activePid: null, cats: {},
  lists: [{ id: 'fav', name: 'Chaînes favorites', items: [] }],
  recents: [], favCats: {},
  settings: { format: 'auto', logos: true, tv: false, accent: ACCENTS[0], epg: true, rewind: 30 },
  last: null,
});
let S = DEFAULT();
let saveTimer = null;
const local = {
  get(k, d) { try { const v = localStorage.getItem('fluxtv.' + k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem('fluxtv.' + k, JSON.stringify(v)); } catch { } },
};
function save() { S.ts = Date.now(); local.set('state', S); clearTimeout(saveTimer); saveTimer = setTimeout(saveNow, 450); }
async function saveNow() {
  clearTimeout(saveTimer); saveTimer = null;
  try { await fetch('api/state', { method: 'PUT', headers: { 'content-type': 'application/json' }, body: JSON.stringify(S) }); } catch { }
}
async function fetchState(since) {
  try { const r = await fetch('api/state' + (since ? '?since=' + since : ''), { cache: 'no-store' }); if (r.status === 204) return null; if (r.ok) { const j = await r.json(); if (j && j.v) return j; } } catch { }
  return null;
}
// réglages propres à CET appareil : jamais remplacés par ceux d'un autre appareil (compte en ligne)
const DEVICE_KEYS = ['format', 'rewind', 'tv', 'tvAuto', 'm1'];
const keepDevice = (incoming, mine) => { const s = { ...(incoming.settings || {}) }; for (const k of DEVICE_KEYS) { if (mine && mine[k] !== undefined) s[k] = mine[k]; else delete s[k]; } return { ...incoming, settings: s }; };
function hydrate(o) {
  const d = DEFAULT();
  const s = Object.assign(d, o || {});
  s.settings = Object.assign(DEFAULT().settings, (o && o.settings) || {});
  if (!s.favCats || typeof s.favCats !== 'object') s.favCats = {};
  { const fl = s.lists.find(l => l.id === 'fav'); if (fl && fl.name === 'Favoris') fl.name = 'Chaînes favorites'; }
  if (!Array.isArray(s.lists) || !s.lists.find(l => l.id === 'fav')) s.lists = [{ id: 'fav', name: 'Chaînes favorites', items: [] }, ...(s.lists || [])];
  return s;
}
const UI = Object.assign({ kind: 'live', sel: { t: 'all' }, vol: 1, muted: false }, local.get('ui', {}));
const saveUI = () => local.set('ui', UI);

/* ------------------------------------------------------------ données */
let CH = [];                 // chaînes de la playlist active
let BYKEY = new Map();
let GROUPS = { live: new Map(), movie: new Map(), series: new Map() };
let EPG = {};
const KINDS = [
  { k: 'live', label: 'Direct', icon: 'tv' },
  { k: 'movie', label: 'Films', icon: 'film' },
  { k: 'series', label: 'Séries', icon: 'series' },
];
const view = { items: [], cursor: 0, filter: '', title: '', mode: 'virtual' };

const activePl = () => S.playlists.find(p => p.id === S.activePid) || S.playlists[0] || null;
function catSt(kind) {
  const pid = S.activePid || 'x';
  S.cats[pid] = S.cats[pid] || {};
  const c = S.cats[pid][kind] = S.cats[pid][kind] || {};
  c.order = c.order || []; c.hidden = c.hidden || {}; c.renamed = c.renamed || {};
  return c;
}
const catLabel = (kind, g) => catSt(kind).renamed[g] || g;
function orderedGroups(kind, withHidden) {
  const st = catSt(kind), all = GROUPS[kind], out = [], seen = new Set();
  for (const g of st.order) if (all.has(g) && !seen.has(g)) { out.push(g); seen.add(g); }
  for (const g of all.keys()) if (!seen.has(g)) out.push(g);
  return withHidden ? out : out.filter(g => !st.hidden[g]);
}
const isHidden = ch => !!catSt(ch.k).hidden[ch.g];
/* catégories favorites (par playlist) */
function favCats() { const pid = S.activePid || 'x'; S.favCats = S.favCats || {}; return S.favCats[pid] = S.favCats[pid] || []; }
const isFavCat = (k, g) => favCats().some(f => f.k === k && f.g === g);
const validFavCats = () => favCats().filter(f => GROUPS[f.k] && GROUPS[f.k].has(f.g));
function toggleFavCat(k, g) {
  const a = favCats(), i = a.findIndex(f => f.k === k && f.g === g);
  if (i >= 0) { a.splice(i, 1); toast(`Catégorie retirée des favoris : ${catLabel(k, g)}`); }
  else { a.push({ k, g }); toast(`★ Catégorie ajoutée aux favoris : ${catLabel(k, g)}`); }
  save(); renderSide(); if (window.homeFavChanged) homeFavChanged();
}
function moveFavCat(k, g, d) {
  const a = favCats(), i = a.findIndex(f => f.k === k && f.g === g), j = i + d;
  if (i < 0 || j < 0 || j >= a.length) return;
  [a[i], a[j]] = [a[j], a[i]]; save(); renderSide(); if (window.homeFavChanged) homeFavChanged(true);
}

/* ------------------------------------------------------------ parsing (worker) */
function parseM3U(txt) {
  const KQ = /\b(4K|UHD|FHD|1080P?|HEVC|H\.?265|HD|720P?|SD)\b/i;
  const out = []; let epg = null, cur = null, grp = null;
  const lines = txt.split(/\r?\n/);
  const attrRe = /([\w-]+)="([^"]*)"/g;
  for (let i = 0; i < lines.length; i++) {
    const L = lines[i].trim();
    if (!L) continue;
    if (L.charCodeAt(0) === 35) {
      if (L.startsWith('#EXTINF')) {
        let q = false, ci = -1;
        for (let j = 8; j < L.length; j++) { const c = L[j]; if (c === '"') q = !q; else if (c === ',' && !q) { ci = j; break; } }
        const head = ci < 0 ? L : L.slice(0, ci), name = ci < 0 ? '' : L.slice(ci + 1).trim();
        const a = {}; let m; attrRe.lastIndex = 0;
        while ((m = attrRe.exec(head))) a[m[1].toLowerCase()] = m[2];
        cur = { n: name || a['tvg-name'] || 'Sans nom', g: (a['group-title'] || '').trim(), l: a['tvg-logo'] || a.logo || '', t: (a['tvg-id'] || '').trim() };
      } else if (L.startsWith('#EXTGRP:')) grp = L.slice(8).trim();
      else if (L.startsWith('#EXTM3U')) { const m = L.match(/(?:url-tvg|x-tvg-url)="([^"]+)"/); if (m) epg = m[1].split(',')[0].trim(); }
      continue;
    }
    if (!cur) cur = { n: L.split('/').pop() || L, g: '', l: '', t: '' };
    cur.u = L;
    if (!cur.g) cur.g = grp || 'Sans catégorie';
    const ul = L.toLowerCase();
    cur.k = /\/series\//.test(ul) ? 'series' : (/\/movie\//.test(ul) || /\.(mp4|mkv|avi|mov|wmv|m4v)(\?|$)/.test(ul)) ? 'movie' : 'live';
    const qm = cur.n.match(KQ);
    if (qm) {
      const t = qm[1].toUpperCase().replace('.', '');
      cur.q = /4K|UHD/.test(t) ? '4K' : /FHD|1080/.test(t) ? 'FHD' : /HEVC|H265/.test(t) ? 'HEVC' : /HD|720/.test(t) ? 'HD' : 'SD';
      const dn = cur.n.replace(/\s*[\[(]?\b(4K|UHD|FHD|1080P?|HEVC|H\.?265|HD|720P?|SD)\b[\])]?/gi, ' ').replace(/\s{2,}/g, ' ').trim();
      if (dn && dn !== cur.n) cur.dn = dn;
    }
    cur.nn = norm(cur.n); cur.nc = cur.nn.replace(/ /g, '');
    out.push(cur); cur = null; grp = null;
  }
  return { chs: out, epg };
}
let worker = null;
function parseInWorker(txt) {
  return new Promise((res, rej) => {
    try {
      if (!worker) {
        const src = `${norm.toString()}\n${parseM3U.toString()}\nonmessage=e=>{try{postMessage(parseM3U(e.data))}catch(err){postMessage({error:String(err)})}}`;
        worker = new Worker(URL.createObjectURL(new Blob([src], { type: 'text/javascript' })));
      }
      worker.onmessage = e => e.data.error ? rej(new Error(e.data.error)) : res(e.data);
      worker.onerror = e => rej(e);
      worker.postMessage(txt);
    } catch (e) { try { res(parseM3U(txt)); } catch (er) { rej(er); } }
  });
}
function chKey(u) {
  const m = u.match(/\/(live|movie|series)\/[^/]+\/[^/]+\/(\d+)(?:\.\w+)?(?:[?#]|$)/i);
  if (m) return m[1].toLowerCase() + '/' + m[2];
  return u.replace(/^https?:\/\/[^/]+/i, '');
}
function ingest(res) {
  CH = res.chs; BYKEY = new Map(); GROUPS = { live: new Map(), movie: new Map(), series: new Map() };
  for (let i = 0; i < CH.length; i++) {
    const c = CH[i]; c.i = i; c.key = chKey(c.u); c.tl = c.t.toLowerCase();
    if (!BYKEY.has(c.key)) BYKEY.set(c.key, c);
    const G = GROUPS[c.k]; let a = G.get(c.g); if (!a) G.set(c.g, a = []); a.push(c);
  }
  // les favoris pointent vers les données fraîches
  for (const l of S.lists) for (const it of l.items) { const c = BYKEY.get(it.key); if (c) Object.assign(it, { n: c.n, l: c.l, u: c.u, g: c.g, k: c.k }); }
  if (!GROUPS[UI.kind].size) UI.kind = KINDS.find(k => GROUPS[k.k].size)?.k || 'live';
}
// une chaîne d'une liste perso → objet chaîne (ou instantané si absent de la playlist)
function resolve(it) { return BYKEY.get(it.key) || Object.assign({ missing: true, nn: norm(it.n), nc: norm(it.n).replace(/ /g, ''), t: '', tl: '' }, it); }
const snap = c => ({ key: c.key, n: c.n, dn: c.dn, q: c.q, l: c.l, u: c.u, g: c.g, k: c.k });

/* ------------------------------------------------------------ EPG */
function progs(c) { return (c && c.tl && EPG[c.tl]) || null; }
function nowProg(c, t = Date.now() / 1000) {
  const a = progs(c); if (!a) return null;
  for (let i = 0; i < a.length; i++) { if (a[i][0] <= t && a[i][1] > t) return a[i]; if (a[i][0] > t) break; }
  return null;
}
const hm = s => { const d = new Date(s * 1000); return d.getHours().toString().padStart(2, '0') + ':' + d.getMinutes().toString().padStart(2, '0'); };
async function loadEpg(refresh) {
  const p = activePl(); if (!p || !S.settings.epg) return;
  try {
    const r = await fetch(`api/epg/${p.id}` + (refresh ? '?refresh=1' : ''));
    if (!r.ok) return;
    EPG = await r.json() || {};
    paintRows(true); renderNP(); if (UI.layout === 'home') { renderHero(); homeRefreshEPG(); }
  } catch { }
}

/* ------------------------------------------------------------ éléments */
const app = $('#app'), side = $('#sideScroll'), listBody = $('#listBody'), rowsEl = $('#rows');
const video = $('#video'), player = $('#player');
function toast(msg, bad) {
  const t = document.createElement('div'); t.className = 'toast' + (bad ? ' bad' : ''); t.textContent = msg;
  $('#toasts').appendChild(t); setTimeout(() => t.remove(), bad ? 5200 : 2600);
}
function initials(n) {
  const w = String(n).replace(/^[^|:]{1,6}[|:]\s*/, '').replace(/[^\p{L}\p{N} ]/gu, ' ').trim().split(/\s+/);
  return ((w[0] || '?')[0] + (w[1] ? w[1][0] : (w[0] || '')[1] || '')).toUpperCase();
}
function hueOf(s) { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return h % 360; }
function logoHTML(c) {
  const ini = esc(initials(c.n)), bg = `hsl(${hueOf(c.n)} 45% 26%)`;
  if (S.settings.logos && c.l) return `<span class="lg" style="background:${bg}" data-ini="${ini}"><img src="${esc(c.l)}" loading="lazy" decoding="async" referrerpolicy="no-referrer" alt=""></span>`;
  return `<span class="lg" style="background:${bg}">${ini}</span>`;
}
document.addEventListener('error', e => {
  const im = e.target; if (im.tagName !== 'IMG' || !im.parentElement?.classList.contains('lg')) return;
  const p = im.parentElement; p.textContent = p.dataset.ini || '';
}, true);
document.addEventListener('load', e => {
  const im = e.target; if (im.tagName === 'IMG' && im.parentElement?.classList.contains('lg')) im.parentElement.style.background = '#0f1218';
}, true);

/* ------------------------------------------------------------ barre du haut */
function renderTop() {
  $('#btnDrawer').innerHTML = ic('menu');
  $('.logo-mark').innerHTML = ic('bolt');
  $('.sb-ic').innerHTML = ic('search'); $('.f-ic').innerHTML = ic('search');
  $('#btnOrganize').innerHTML = ic('layers'); $('#btnSettings').innerHTML = ic('cog');
  $('.idle-mark').innerHTML = ic('tv'); $('.pi-ic').innerHTML = ic('search');
  $$('#org .f-ic').forEach(e => e.innerHTML = ic('search'));
  $$('[data-close]').forEach(b => { if (!b.textContent.trim()) b.innerHTML = ic('x'); });
  $('#pbPrev').innerHTML = ic('prev'); $('#pbNext').innerHTML = ic('next'); $('#pbPip').innerHTML = ic('pip');
  $('#pbFav').innerHTML = ic('star'); $('#pbBack').innerHTML = ic('prev');
  renderKinds();
}
function renderKinds() {
  const ks = KINDS.filter(k => GROUPS[k.k].size || k.k === 'live');
  const favPage = UI.layout === 'home' && UI.page === 'fav';
  $('#kinds').innerHTML = ks.map(k => `<button data-k="${k.k}" class="${UI.kind === k.k && !favPage ? 'on' : ''}" title="${k.label}">${ic(k.icon)}<span>${k.label}</span></button>`).join('')
    + `<button data-page="fav" class="favtab${favPage ? ' on' : ''}" title="Mes favoris : chaînes et catégories">${ic('star')}<span>Favoris</span></button>`;
  $('#kinds').hidden = ks.length < 2 && !CH.length;
}
$('#kinds').onclick = e => {
  const b = e.target.closest('button'); if (!b) return;
  if (b.dataset.page === 'fav') {
    if (UI.layout !== 'home') { UI.layout = 'home'; UI.page = 'fav'; saveUI(); applyLayout(); renderKinds(); return; }
    UI.page = 'fav'; saveUI(); renderKinds(); renderHome(); app.scrollTop = 0; return;
  }
  if (UI.page === 'fav') { UI.page = 'home'; saveUI(); if (UI.kind === b.dataset.k) { renderKinds(); renderHome(); app.scrollTop = 0; return; } }
  setKind(b.dataset.k);
};
function setKind(k) {
  if (UI.kind === k) return;
  UI.kind = k; UI.sel = { t: 'all' }; saveUI(); renderKinds(); renderSide(); openView(); if (UI.layout === 'home') renderHome();
}

/* ------------------------------------------------------------ sidebar */
let catFilter = '';
function renderSide() {
  const kind = UI.kind, sel = UI.sel;
  const on = (t, id) => sel.t === t && (id === undefined || sel.id === id) ? ' on' : '';
  let h = `<div class="s-head">Mes listes<button id="sNewList" title="Nouvelle liste">${ic('plus')}</button></div>`;
  for (const l of S.lists) {
    h += `<button class="s-item${l.id === 'fav' ? ' fav' : ''}${on('list', l.id)}" data-nav data-t="list" data-id="${l.id}">${ic(l.id === 'fav' ? 'star' : 'list')}<span class="lbl">${esc(l.name)}</span><span class="n">${l.items.length || ''}</span></button>`;
  }
  const fcs = validFavCats();
  h += `<div class="s-head">Catégories favorites</div>`;
  for (const f of fcs) h += `<button class="s-item fav${f.k === kind ? on('cat', f.g) : ''}" data-nav data-t="fcat" data-k="${f.k}" data-id="${esc(f.g)}">${ic('star')}<span class="lbl">${esc(catLabel(f.k, f.g))}</span><span class="n">${f.k !== 'live' ? KINDS.find(x => x.k === f.k).label + ' · ' : ''}${GROUPS[f.k].get(f.g).length}</span></button>`;
  if (!fcs.length) h += `<div class="s-hint">Clique sur ☆ à côté d'une catégorie pour l'ajouter ici.</div>`;
  h += `<button class="s-item${on('recents')}" data-nav data-t="recents">${ic('clock')}<span class="lbl">Récents</span><span class="n">${S.recents.length || ''}</span></button>`;
  const groups = orderedGroups(kind, false), total = GROUPS[kind].size;
  h += `<div class="s-head">Catégories<button id="sOrg" title="Organiser">${ic('layers')}</button></div>`;
  if (total > 12) h += `<div class="s-cat-filter"><input id="sCatFilter" placeholder="Chercher une catégorie" value="${esc(catFilter)}" autocomplete="off"></div>`;
  const nAll = groups.reduce((s, g) => s + GROUPS[kind].get(g).length, 0);
  h += `<button class="s-item${on('all')}" data-nav data-t="all">${ic('grid')}<span class="lbl">Tout</span><span class="n">${nAll || ''}</span></button>`;
  const f = norm(catFilter);
  for (const g of groups) {
    const lab = catLabel(kind, g);
    if (f && !norm(lab).includes(f)) continue;
    const fc = isFavCat(kind, g);
    h += `<button class="s-item${on('cat', g)}" data-nav data-t="cat" data-id="${esc(g)}">${ic('folder')}<span class="lbl">${esc(lab)}</span><span class="s-star${fc ? ' on' : ''}" title="${fc ? 'Retirer des catégories favorites' : 'Ajouter aux catégories favorites'}">${ic('star')}</span><span class="n">${GROUPS[kind].get(g).length}</span></button>`;
  }
  if (!total) h += `<div class="s-hint">${CH.length ? 'Aucun contenu de ce type.' : 'Ajoute ta playlist dans les paramètres.'}</div>`;
  else if (groups.length < total) h += `<div class="s-hint">${total - groups.length} catégorie(s) masquée(s) · <a href="#" id="sShowOrg" style="color:var(--acc)">gérer</a></div>`;
  side.innerHTML = h;
  const cf = $('#sCatFilter');
  if (cf) cf.oninput = () => { catFilter = cf.value; const pos = cf.selectionStart; renderSide(); const n = $('#sCatFilter'); n.focus(); n.setSelectionRange(pos, pos); };
}
side.addEventListener('click', e => {
  if (e.target.closest('#sNewList')) return newList();
  if (e.target.closest('#sOrg') || e.target.closest('#sShowOrg')) { e.preventDefault(); return openOrganizer(); }
  const stb = e.target.closest('.s-star'); if (stb) { toggleFavCat(UI.kind, stb.closest('.s-item').dataset.id); return; }
  const b = e.target.closest('.s-item'); if (!b) return;
  if (b.dataset.t === 'fcat') {
    if (UI.kind !== b.dataset.k) { UI.kind = b.dataset.k; renderKinds(); }
    UI.sel = { t: 'cat', id: b.dataset.id }; saveUI(); renderSide(); openView(); closeDrawer(); return;
  }
  UI.sel = { t: b.dataset.t, id: b.dataset.id }; saveUI();
  $$('.s-item.on', side).forEach(x => x.classList.remove('on')); b.classList.add('on');
  openView(); closeDrawer();
  if (isTouch) return;
  if (document.body.classList.contains('tv')) focusZone('list');
});
side.addEventListener('contextmenu', e => {
  const b = e.target.closest('.s-item'); if (!b) return; e.preventDefault();
  sideMenu(b, e.clientX, e.clientY);
});
longPress(side, '.s-item', (b, x, y) => sideMenu(b, x, y));
function sideMenu(b, x, y) {
  const t = b.dataset.t, id = b.dataset.id, kind = UI.kind;
  if (t === 'fcat') {
    const k = b.dataset.k;
    return menu(x, y, [
      { label: 'Retirer des catégories favorites', icon: 'star', act: () => toggleFavCat(k, id) },
      { label: 'Monter', icon: 'up', act: () => moveFavCat(k, id, -1) },
      { label: 'Descendre', icon: 'down', act: () => moveFavCat(k, id, 1) },
    ]);
  }
  if (t === 'cat') {
    const st = catSt(kind);
    menu(x, y, [
      { label: isFavCat(kind, id) ? 'Retirer des catégories favorites' : 'Ajouter aux catégories favorites', icon: 'star', act: () => toggleFavCat(kind, id) },
      { label: 'Monter tout en haut', icon: 'up', act: () => { const o = orderedGroups(kind, true).filter(g => g !== id); st.order = [id, ...o]; save(); renderSide(); } },
      { label: 'Renommer', icon: 'edit', act: async () => { const n = await askText('Renommer la catégorie', catLabel(kind, id), { ok: 'Renommer' }); if (n == null) return; if (n.trim() && n.trim() !== id) st.renamed[id] = n.trim(); else delete st.renamed[id]; save(); renderSide(); openView(); } },
      { label: 'Masquer cette catégorie', icon: 'eyeoff', act: () => { st.hidden[id] = 1; if (UI.sel.t === 'cat' && UI.sel.id === id) UI.sel = { t: 'all' }; save(); renderSide(); openView(); toast('Catégorie masquée — Organiser pour la ré-afficher'); } },
      '-',
      { label: 'Tout ajouter à une liste…', icon: 'list', act: () => pickList(GROUPS[kind].get(id) || []) },
      { label: 'Organiser les catégories…', icon: 'layers', act: openOrganizer },
    ]);
  } else if (t === 'list') {
    const l = S.lists.find(l => l.id === id);
    const items = [{ label: 'Renommer', icon: 'edit', act: async () => { const n = await askText('Renommer la liste', l.name, { ok: 'Renommer' }); if (n && n.trim()) { l.name = n.trim(); save(); renderSide(); openView(); } } }];
    items.push({ label: 'Monter', icon: 'up', act: () => { const i = S.lists.indexOf(l); if (i > 0) { S.lists.splice(i, 1); S.lists.splice(i - 1, 0, l); save(); renderSide(); } } });
    items.push({ label: 'Trier A→Z', icon: 'list', act: () => { l.items.sort((a, b) => a.n.localeCompare(b.n, 'fr', { numeric: true })); save(); openView(); } });
    if (l.items.length) items.push({ label: 'Vider la liste', icon: 'trash', act: () => { if (confirm(`Vider « ${l.name} » ?`)) { l.items = []; save(); renderSide(); openView(); } } });
    if (id !== 'fav') items.push('-', { label: 'Supprimer la liste', icon: 'trash', act: () => { if (confirm(`Supprimer « ${l.name} » ?`)) { S.lists = S.lists.filter(x => x !== l); if (UI.sel.id === id) UI.sel = { t: 'list', id: 'fav' }; save(); renderSide(); openView(); } } });
    menu(x, y, items);
  } else if (t === 'recents') {
    menu(x, y, [{ label: "Effacer l'historique", icon: 'trash', act: () => { S.recents = []; save(); renderSide(); openView(); } }]);
  }
}
async function newList(then) {
  const n = await askText('Nouvelle liste', '', { ok: 'Créer', placeholder: 'ex : Foot, Info, Enfants' });
  if (!n || !n.trim()) return null;
  const l = { id: uid(), name: n.trim(), items: [] };
  S.lists.push(l); save(); renderSide();
  if (then) then(l);
  return l;
}
function openDrawer() { app.classList.add('drawer'); }
function closeDrawer() { app.classList.remove('drawer'); }
$('#btnDrawer').onclick = () => app.classList.toggle('drawer');
$('#scrim').onclick = closeDrawer;

/* ------------------------------------------------------------ liste des chaînes */
function computeItems() {
  const sel = UI.sel, kind = UI.kind;
  if (sel.t === 'list') { const l = S.lists.find(l => l.id === sel.id); if (!l) { UI.sel = { t: 'all' }; return computeItems(); } return { items: l.items.map(resolve), title: l.name, mode: 'static' }; }
  if (sel.t === 'recents') return { items: S.recents.map(resolve), title: 'Récents', mode: 'virtual' };
  if (sel.t === 'cat' && GROUPS[kind].has(sel.id)) return { items: GROUPS[kind].get(sel.id), title: catLabel(kind, sel.id), mode: 'virtual' };
  const out = []; for (const g of orderedGroups(kind, false)) for (const c of GROUPS[kind].get(g)) out.push(c);
  UI.sel = { t: 'all' };
  return { items: out, title: KINDS.find(k => k.k === kind).label + ' · tout', mode: 'virtual' };
}
let baseItems = [];
function openView(keepCursor) {
  const r = computeItems();
  baseItems = r.items; view.title = r.title; view.mode = r.mode;
  $('#listTitle').textContent = r.title;
  if (!keepCursor) { view.filter = ''; $('#filter').value = ''; }
  applyFilter(keepCursor);
}
function applyFilter(keepCursor) {
  const f = norm(view.filter);
  if (f) {
    const toks = f.split(' '), fc = f.replace(/ /g, '');
    view.items = baseItems.filter(c => toks.every(t => c.nn.includes(t)) || c.nc.includes(fc));
  } else view.items = baseItems;
  $('#listCount').textContent = view.items.length ? `${view.items.length.toLocaleString('fr-FR')} ${view.items.length > 1 ? 'éléments' : 'élément'}` : '';
  if (!keepCursor) {
    const pi = PL.ch ? view.items.findIndex(c => c.key === PL.ch.key) : -1;
    view.cursor = pi >= 0 ? pi : 0;
  } else view.cursor = clamp(view.cursor, 0, Math.max(0, view.items.length - 1));
  renderList();
  if (!keepCursor) { const pi = PL.ch ? view.items.findIndex(c => c.key === PL.ch.key) : -1; if (pi >= 0) scrollToIdx(pi, true); else listBody.scrollTop = 0; }
}
$('#filter').addEventListener('input', e => { view.filter = e.target.value; applyFilter(); });

const rowH = () => parseFloat(getComputedStyle(document.body).getPropertyValue('--row')) || 58;
let rowCache = new Map(), sortable = null, lastRange = '';
function renderList() {
  rowCache.forEach(el => el.remove()); rowCache = new Map(); lastRange = '';
  rowsEl.innerHTML = '';
  if (sortable) { sortable.destroy(); sortable = null; }
  const empty = $('#listEmpty');
  if (!view.items.length) {
    rowsEl.style.height = '0px';
    empty.hidden = false;
    empty.innerHTML = !CH.length && S.playlists.length && lastLoadError ? `<b>Playlist non chargée</b>${esc(lastLoadError)}<br><br><button class="btn" onclick="loadPlaylist(true)">Réessayer</button> <button class="btn ghost" onclick="openPlaylistForm(activePl())">Modifier</button>`
      : !CH.length && !S.playlists.length ? `<b>Bienvenue 👋</b>Ajoute ta playlist IPTV pour commencer.<br><br><button class="btn" onclick="openPlaylistForm()">${ic('plus')} Ajouter ma playlist</button>`
      : view.filter ? `<b>Rien trouvé ici</b>Essaie la recherche globale (Ctrl K)`
        : UI.sel.t === 'list' ? `<b>Liste vide</b>Clique sur l'étoile ☆ d'une chaîne<br>ou fais un clic droit → Ajouter à…`
          : UI.sel.t === 'recents' ? `<b>Pas encore d'historique</b>` : `<b>Rien à afficher</b>`;
    return;
  }
  empty.hidden = true;
  if (view.mode === 'static') {
    rowsEl.classList.add('static'); rowsEl.style.height = '';
    const fr = document.createDocumentFragment();
    view.items.forEach((c, i) => fr.appendChild(makeRow(c, i)));
    rowsEl.appendChild(fr);
    if (!view.filter && window.Sortable) {
      sortable = Sortable.create(rowsEl, {
        animation: 150, handle: isTouch ? '.num' : undefined, delay: isTouch ? 0 : 0, filter: '.star', preventOnFilter: false,
        onEnd: ev => {
          if (ev.oldIndex === ev.newIndex) return;
          const l = S.lists.find(l => l.id === UI.sel.id); const [m] = l.items.splice(ev.oldIndex, 1); l.items.splice(ev.newIndex, 0, m);
          save(); openView(true);
        },
      });
    }
    return;
  }
  rowsEl.classList.remove('static');
  rowsEl.style.height = view.items.length * rowH() + 'px';
  paintRows(true);
}
function makeRow(c, i) {
  const el = document.createElement('div');
  el.className = 'row'; el.dataset.i = i;
  fillRow(el, c, i);
  return el;
}
function subHTML(c) {
  if (c.k === 'live') {
    const p = nowProg(c);
    if (p) { const pc = clamp((Date.now() / 1000 - p[0]) / (p[1] - p[0]) * 100, 0, 100); return `<span class="tm">${hm(p[0])}</span><span class="t">${esc(p[2])}</span><span class="prog"><i style="width:${pc.toFixed(1)}%"></i></span>`; }
  }
  const showCat = UI.sel.t !== 'cat' || view.filter;
  return `<span class="t">${c.missing ? 'Absente de la playlist actuelle' : showCat ? esc(catLabel(c.k, c.g)) : ''}</span>`;
}
function fillRow(el, c, i) {
  const fav = isFav(c);
  const q = c.q ? `<span class="q ${c.q === '4K' ? 'uhd' : c.q === 'FHD' ? 'fhd' : ''}">${c.q}</span>` : '';
  el.innerHTML = `<span class="num">${i + 1}</span>${logoHTML(c)}<span class="mt"><span class="nm">${esc(c.dn || c.n)}${q}</span><span class="sub">${subHTML(c)}</span></span><button class="star${fav ? ' on' : ''}" title="Favori" tabindex="-1">${ic('star')}</button>`;
  el.classList.toggle('playing', !!PL.ch && PL.ch.key === c.key);
  el.classList.toggle('cur', i === view.cursor);
  if (c.missing) el.style.opacity = .55;
}
function paintRows(force) {
  if (view.mode === 'static') {
    if (force) $$('.row', rowsEl).forEach(el => { const i = +el.dataset.i; const c = view.items[i]; if (c) fillRow(el, c, i); });
    return;
  }
  const rh = rowH(), top = listBody.scrollTop, hgt = listBody.clientHeight || 600;
  const a = Math.max(0, Math.floor(top / rh) - 6), b = Math.min(view.items.length, Math.ceil((top + hgt) / rh) + 6);
  const key = a + ':' + b;
  if (!force && key === lastRange) return;
  lastRange = key;
  for (const [i, el] of rowCache) if (i < a || i >= b || force) { el.remove(); rowCache.delete(i); }
  const fr = document.createDocumentFragment();
  for (let i = a; i < b; i++) {
    if (rowCache.has(i)) continue;
    const el = makeRow(view.items[i], i);
    el.style.transform = `translateY(${i * rh}px)`;
    rowCache.set(i, el); fr.appendChild(el);
  }
  rowsEl.appendChild(fr);
}
let scrollRaf = 0;
listBody.addEventListener('scroll', () => { if (!scrollRaf) scrollRaf = requestAnimationFrame(() => { scrollRaf = 0; paintRows(false); }); }, { passive: true });
new ResizeObserver(() => { if (view.mode === 'virtual') { rowsEl.style.height = view.items.length * rowH() + 'px'; paintRows(true); } }).observe(listBody);
function rowEl(i) { return view.mode === 'static' ? rowsEl.children[i] : rowCache.get(i); }
function refreshMarks() {
  const els = view.mode === 'static' ? [...rowsEl.children] : [...rowCache.values()];
  for (const el of els) {
    const i = +el.dataset.i, c = view.items[i]; if (!c) continue;
    el.classList.toggle('playing', !!PL.ch && PL.ch.key === c.key);
    el.classList.toggle('cur', i === view.cursor);
    el.querySelector('.star')?.classList.toggle('on', isFav(c));
  }
}
function scrollToIdx(i, center) {
  const rh = rowH(), top = i * rh, h = listBody.clientHeight;
  if (center) listBody.scrollTop = Math.max(0, top - h / 2 + rh / 2);
  else if (top < listBody.scrollTop) listBody.scrollTop = top;
  else if (top + rh > listBody.scrollTop + h) listBody.scrollTop = top + rh - h;
  paintRows(false);
}
function setCursor(i, center) {
  if (!view.items.length) return;
  view.cursor = clamp(i, 0, view.items.length - 1);
  scrollToIdx(view.cursor, center); refreshMarks();
}
rowsEl.addEventListener('click', e => {
  const r = e.target.closest('.row'); if (!r) return;
  const i = +r.dataset.i, c = view.items[i];
  if (e.target.closest('.star')) { toggleFav(c); return; }
  view.cursor = i;
  if (PL.ch && PL.ch.key === c.key) { if (isTouch) return; toggleFull(); return; }
  play(c, view.items);
});
rowsEl.addEventListener('contextmenu', e => { const r = e.target.closest('.row'); if (!r) return; e.preventDefault(); chanMenu(view.items[+r.dataset.i], e.clientX, e.clientY); });
longPress(rowsEl, '.row', (r, x, y) => chanMenu(view.items[+r.dataset.i], x, y));

/* ------------------------------------------------------------ favoris & listes */
const favList = () => S.lists.find(l => l.id === 'fav');
let favSet = new Set();
function rebuildFavSet() { favSet = new Set(favList().items.map(i => i.key)); }
const isFav = c => favSet.has(c.key);
function toggleFav(c, force) {
  const l = favList(); const has = isFav(c);
  if (has && force !== true) { l.items = l.items.filter(i => i.key !== c.key); toast(`Retiré des chaînes favorites : ${c.n}`); }
  else if (!has) { l.items.push(snap(c)); toast(`★ Ajouté aux chaînes favorites : ${c.n}`); }
  rebuildFavSet(); save(); renderSide();
  if (UI.sel.t === 'list' && UI.sel.id === 'fav') openView(true); else refreshMarks();
  renderNP(); updateBar(); homeSync(c.key);
}
function addToList(l, chs) {
  const have = new Set(l.items.map(i => i.key)); let n = 0;
  for (const c of chs) if (!have.has(c.key)) { l.items.push(snap(c)); have.add(c.key); n++; }
  if (l.id === 'fav') rebuildFavSet();
  save(); renderSide(); if (UI.sel.t === 'list' && UI.sel.id === l.id) openView(true); else refreshMarks();
  homeSync();
  toast(n ? `${n > 1 ? n + ' éléments ajoutés' : 'Ajouté'} à « ${l.name} »` : `Déjà dans « ${l.name} »`);
  renderNP();
}
function pickList(chs) {
  const r = $('#btnSearch').getBoundingClientRect();
  menu(innerWidth / 2 - 120, Math.max(80, r.bottom + 40), [{ head: 'Ajouter à…' }, ...S.lists.map(l => ({ label: l.name, icon: l.id === 'fav' ? 'star' : 'list', act: () => addToList(l, chs) })), '-', { label: 'Nouvelle liste…', icon: 'plus', act: () => newList(l => addToList(l, chs)) }]);
}
function chanMenu(c, x, y) {
  if (!c) return;
  const items = [{ head: c.n }, { label: 'Lire', icon: 'play', act: () => play(c, view.items) }];
  for (const l of S.lists) {
    const inL = l.items.some(i => i.key === c.key);
    items.push({ label: (inL ? 'Retirer de ' : 'Ajouter à ') + l.name, icon: l.id === 'fav' ? 'star' : 'list', ck: inL, act: () => inL ? (l.id === 'fav' ? toggleFav(c) : removeFrom(l, c)) : addToList(l, [c]) });
  }
  items.push({ label: 'Nouvelle liste avec cette chaîne…', icon: 'plus', act: () => newList(l => addToList(l, [c])) });
  if (c.k === 'live' && window.mvAdd) items.push({ label: 'Ajouter au multi-live', icon: 'multi', act: () => mvAdd(c, true) });
  items.push('-');
  if (!c.missing) items.push({ label: 'Aller à sa catégorie', icon: 'folder', act: () => goCat(c) });
  items.push({ label: 'Copier le lien (pour VLC)', icon: 'copy', act: () => copy(c.u) });
  if (UI.sel.t === 'list') {
    const l = S.lists.find(l => l.id === UI.sel.id);
    const i = l.items.findIndex(x => x.key === c.key);
    if (i > 0) items.push({ label: 'Mettre en premier', icon: 'up', act: () => { const [m] = l.items.splice(i, 1); l.items.unshift(m); save(); openView(true); } });
  }
  menu(x, y, items);
}
function removeFrom(l, c) { l.items = l.items.filter(i => i.key !== c.key); if (l.id === 'fav') rebuildFavSet(); save(); renderSide(); if (UI.sel.t === 'list') openView(true); else refreshMarks(); toast(`Retiré de « ${l.name} »`); homeSync(); }
function goCat(c) {
  if (UI.kind !== c.k) { UI.kind = c.k; renderKinds(); }
  if (isHidden(c)) { delete catSt(c.k).hidden[c.g]; save(); toast('Catégorie ré-affichée'); }
  UI.sel = { t: 'cat', id: c.g }; saveUI(); renderSide(); openView();
  const i = view.items.findIndex(x => x.key === c.key); if (i >= 0) setCursor(i, true);
  $('.s-item.on', side)?.scrollIntoView({ block: 'nearest' });
}
async function copy(t) { try { await navigator.clipboard.writeText(t); toast('Lien copié'); } catch { showText('Copie ce lien', t); } }

/* ------------------------------------------------------------ menu contextuel */
const ctx = $('#ctx');
function menu(x, y, items) {
  ctx.innerHTML = items.map((it, i) => it === '-' ? '<hr>' : it.head ? `<div class="ch">${esc(it.head)}</div>` : `<button data-i="${i}">${ic(it.icon || 'next')}<span>${esc(it.label)}</span>${it.ck ? `<span class="ck">${ic('check')}</span>` : ''}</button>`).join('');
  ctx.hidden = false;
  const r = ctx.getBoundingClientRect();
  ctx.style.left = clamp(x, 8, innerWidth - r.width - 8) + 'px';
  ctx.style.top = clamp(y, 8, innerHeight - r.height - 8) + 'px';
  ctx.onclick = e => { const b = e.target.closest('button'); if (!b) return; closeMenu(); items[+b.dataset.i].act(); };
  setTimeout(() => ctx.querySelector('button')?.focus({ preventScroll: true }), 0);
}
function closeMenu() { ctx.hidden = true; }
document.addEventListener('pointerdown', e => { if (!ctx.hidden && !ctx.contains(e.target)) closeMenu(); }, true);
function longPress(root, sel, cb) {
  let t = null, sx = 0, sy = 0;
  root.addEventListener('touchstart', e => { const el = e.target.closest(sel); if (!el) return; const p = e.touches[0]; sx = p.clientX; sy = p.clientY; t = setTimeout(() => { t = null; navigator.vibrate?.(15); cb(el, sx, sy); }, 520); }, { passive: true });
  const cancel = e => { if (!t) return; if (e.type === 'touchmove') { const p = e.touches[0]; if (Math.hypot(p.clientX - sx, p.clientY - sy) < 10) return; } clearTimeout(t); t = null; };
  root.addEventListener('touchmove', cancel, { passive: true }); root.addEventListener('touchend', cancel); root.addEventListener('touchcancel', cancel);
}

/* ------------------------------------------------------------ lecteur */
const PL = { ch: null, ctx: [], vars: [], vi: 0, retries: 0, hls: null, mts: null, gen: 0, lastT: -1, lastMove: 0, stallSince: 0, osdT: 0, uiT: 0 };
const XT = /^(.*\/live\/[^/]+\/[^/]+\/\d+)\.(ts|m3u8)((?:\?.*)?)$/i;
const canMSE = () => !!(window.MediaSource || window.ManagedMediaSource);
function variants(u) {
  const m = u.match(XT);
  if (!m) return [u];
  const ts = m[1] + '.ts' + m[3], hl = m[1] + '.m3u8' + m[3], f = S.settings.format;
  if (f === 'hls' || !canMSE()) return [hl, ts];
  if (f === 'ts') return [ts, hl];
  return m[2].toLowerCase() === 'ts' ? [ts, hl] : [hl, ts];
}
const extOf = u => { const p = u.split(/[?#]/)[0]; const m = p.match(/\.([a-z0-9]{2,5})$/i); return m ? m[1].toLowerCase() : ''; };
// appli Android : pas de serveur, les flux sont lus directement
const proxied = u => window.VK_DIRECT ? u : 'p?u=' + encodeURIComponent(u);
const absUrl = u => new URL(u, location.href).href;

function stopEngines() {
  $('#stage').classList.remove('live');
  if (PL.hls) { try { PL.hls.destroy(); } catch { } PL.hls = null; }
  if (PL.mts) { try { PL.mts.pause(); PL.mts.unload(); PL.mts.detachMediaElement(); PL.mts.destroy(); } catch { } PL.mts = null; }
  try { video.pause(); video.removeAttribute('src'); video.load(); } catch { }
}
function pstate(s, msg) {
  $('#pIdle').hidden = s !== 'idle';
  $('#pSpin').hidden = s !== 'loading';
  $('#pErr').hidden = s !== 'error';
  if (s === 'error') $('#pErrTxt').textContent = msg || '';
}
function play(c, ctxList) {
  if (!c) return;
  if (PL.ch && PL.ch.key !== c.key && typeof recLeave === 'function') recLeave(PL.ch.key);
  PL.ch = c; if (ctxList) PL.ctx = ctxList;
  PL.vars = variants(c.u); PL.vi = 0; PL.retries = 0; PL.restarts = 0;
  addRecent(c); S.last = snap(c); save();
  player.classList.toggle('vod', c.k !== 'live');
  refreshMarks(); renderNP(); updateBar(); showOSD(); homeOnPlay();
  if ('mediaSession' in navigator) try { navigator.mediaSession.metadata = new MediaMetadata({ title: c.n, artist: catLabel(c.k, c.g), artwork: c.l ? [{ src: c.l }] : [] }); } catch { }
  if (window.VkCast && VkCast.active()) { stopEngines(); pstate('none'); VkCast.load(castMedia(c), castHooks); return; }
  start();
}
/* ---------- diffusion sur un autre écran (Chromecast / Google TV / TV connectée), appli Android */
function castMedia(c) {
  const vs = variants(c.u), hl = vs.find(u => extOf(u) === 'm3u8');
  const u = hl || vs[0], ext = extOf(u), live = c.k === 'live';
  const type = ext === 'm3u8' ? 'application/x-mpegurl' : ext === 'ts' || (live && !ext) ? 'video/mp2t' : ext === 'webm' ? 'video/webm' : ext === 'mp3' ? 'audio/mpeg' : 'video/mp4';
  return { url: absUrl(u), type, title: c.n, subtitle: catLabel(c.k, c.g), image: c.l || undefined, live, start: !live && video.currentTime > 5 ? video.currentTime : 0 };
}
const castHooks = {
  onStart: d => { stopEngines(); pstate('none'); player.classList.add('casting'); toast('Diffusion sur ' + d.name); },
  onStop: t => { player.classList.remove('casting'); if (PL.ch) { start(); if (t > 5 && PL.ch.k !== 'live') video.addEventListener('loadedmetadata', () => { try { video.currentTime = t; } catch { } }, { once: true }); } },
};
$('#pbCast').onclick = () => { if (!PL.ch || !window.VkCast) return; if (VkCast.active()) VkCast.load(castMedia(PL.ch), castHooks); else VkCast.pick(() => castMedia(PL.ch), castHooks); };
function start() {
  const gen = ++PL.gen;
  PL.behind = false; video.playbackRate = 1;
  stopEngines(); pstate('loading');
  PL.lastT = -1; PL.lastMove = Date.now(); PL.mediaRec = false;
  const u = PL.vars[PL.vi], ext = extOf(u), live = PL.ch.k === 'live';
  // la chaîne est « marquée » pour que l'enregistreur puisse recopier ce flux sans ouvrir de 2e connexion
  const src = proxied(u) + (live && !window.VK_DIRECT ? '&t=' + encodeURIComponent(PL.ch.key) : '');
  video.controls = !live;
  const failOnce = why => { if (gen === PL.gen) fail(why); };
  if (ext === 'm3u8') {
    if (window.Hls && Hls.isSupported()) {
      const rw = live ? rewindSecs() : 0;
      const hls = new Hls({ enableWorker: true, lowLatencyMode: false, backBufferLength: Math.max(30, rw), maxBufferLength: live ? Math.max(30, rw) : 30, maxMaxBufferLength: live ? Math.max(60, rw + 60) : 60, maxBufferSize: live && rw ? 900 * 1e6 : 60 * 1e6, liveDurationInfinity: true, liveSyncDurationCount: 3, manifestLoadingMaxRetry: 2, levelLoadingMaxRetry: 4, fragLoadingMaxRetry: 6, startFragPrefetch: true });
      PL.hls = hls;
      hls.on(Hls.Events.ERROR, (_, d) => {
        if (!d.fatal) return;
        if (d.type === Hls.ErrorTypes.MEDIA_ERROR && !PL.mediaRec) { PL.mediaRec = true; hls.recoverMediaError(); return; }
        failOnce(d.details || 'erreur HLS');
      });
      hls.on(Hls.Events.MANIFEST_PARSED, () => tryPlay());
      hls.loadSource(src); hls.attachMedia(video);
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) { video.src = src; tryPlay(); }
    else failOnce('Ce navigateur ne lit pas le HLS');
  } else if (live && (ext === 'ts' || ext === '' || !/^(mp4|mkv|webm|mov|avi|m4v|mp3|aac)$/.test(ext))) {
    if (window.mpegts && mpegts.getFeatureList().mseLivePlayback) {
      const p = mpegts.createPlayer({ type: 'mpegts', isLive: true, url: absUrl(src) }, {
        enableWorker: true, enableStashBuffer: true, stashInitialSize: 384 * 1024, lazyLoad: false,
        liveBufferLatencyChasing: false, liveSync: false,
        autoCleanupSourceBuffer: true, autoCleanupMaxBackwardDuration: Math.max(40, rewindSecs()), autoCleanupMinBackwardDuration: Math.max(20, rewindSecs() - 20),
      });
      PL.mts = p;
      p.on(mpegts.Events.ERROR, (t, d) => failOnce(`${t} · ${d}`));
      p.attachMediaElement(video); p.load(); tryPlay();
    } else failOnce('Flux TS non lisible ici');
  } else { video.src = src; tryPlay(); }
}
function tryPlay() {
  video.muted = UI.muted; video.volume = UI.vol;
  const pr = video.play();
  if (pr && pr.catch) pr.catch(e => {
    if (e && e.name === 'NotAllowedError') { video.muted = true; video.play().catch(() => { }); toast('Son coupé par le navigateur — clique sur 🔊 pour l\'activer'); updateBar(); }
  });
}
function fail(why) {
  if (PL.vi < PL.vars.length - 1) { PL.vi++; start(); return; }
  if (PL.retries < 1) { PL.retries++; PL.vi = 0; setTimeout(start, 900); return; }
  stopEngines(); pstate('error', explain(why));
}
function explain(why) {
  const w = String(why || '');
  if (/manifestLoad|NetworkError|HttpStatusCode|403|404|401|502/i.test(w)) return 'Le fournisseur ne répond pas pour cette chaîne (hors ligne, ou trop de connexions ouvertes sur ton abonnement).';
  if (/codec|Unsupported|MediaMSE|bufferAdd|incompatible/i.test(w)) return 'Le format vidéo de ce flux n\'est pas lisible par le navigateur (souvent du HEVC/H.265). Essaie « Autre format » ou ouvre-le dans VLC.';
  return 'Détail : ' + w.slice(0, 160);
}
$('#btnRetry').onclick = () => { PL.retries = 0; PL.vi = 0; start(); };
$('#btnAlt').onclick = () => { if (PL.vars.length > 1) { PL.vars.reverse(); PL.vi = 0; PL.retries = 1; start(); } else toast('Pas d\'autre format pour ce flux'); };
$('#btnCopyErr').onclick = () => PL.ch && copy(PL.ch.u);

video.addEventListener('playing', () => { pstate('none'); PL.retries = 0; updateBar(); $('#stage').classList.add('live'); });
video.addEventListener('waiting', () => { if (PL.ch) $('#pSpin').hidden = false; });
video.addEventListener('canplay', () => { $('#pSpin').hidden = true; });
video.addEventListener('pause', () => { if (PL.ch && PL.ch.k === 'live' && (PL.hls || PL.mts)) PL.behind = true; updateBar(); updateTS(); });
video.addEventListener('play', updateBar);
video.addEventListener('volumechange', () => { UI.vol = video.volume; UI.muted = video.muted; saveUI(); updateBar(); });
video.addEventListener('error', () => { if (PL.ch && !PL.hls && !PL.mts && video.getAttribute('src')) fail(video.error ? 'MediaError ' + video.error.code : 'erreur'); });
/* ---------- retour en arrière sur le direct (mémoire tampon en RAM, rien sur le disque) */
const IS_APP = /Electron/i.test(navigator.userAgent);
const QUOTA = (IS_APP ? 1800 : 130) * 1e6;       // place vidéo disponible dans le navigateur
function rewindSecs() { const m = +S.settings.rewind || 0; return m ? Math.min(m, IS_APP ? 120 : 3) * 60 : 0; }
const bufStart = () => { const b = video.buffered; return b.length ? b.start(0) : 0; };
const bufEnd = () => { const b = video.buffered; return b.length ? b.end(b.length - 1) : 0; };
function liveRef() {
  if (PL.hls && PL.hls.liveSyncPosition) return Math.min(PL.hls.liveSyncPosition, bufEnd() || PL.hls.liveSyncPosition);
  return Math.max(0, bufEnd() - 2.5);
}
const isLiveEngine = () => !!(PL.ch && PL.ch.k === 'live' && (PL.hls || PL.mts));
function fmtT(s) { s = Math.round(s); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60; return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(x).padStart(2, '0'); }
function tsSeek(t) {
  if (!isLiveEngine()) return;
  const s = bufStart() + 0.5, r = liveRef();
  video.currentTime = clamp(t, s, Math.max(s, r));
  PL.behind = r - video.currentTime > 6;
  if (video.paused) tryPlay();
  updateTS(); pokeUI();
}
function goLive() { if (!isLiveEngine()) return; PL.behind = false; video.currentTime = liveRef(); if (video.paused) tryPlay(); updateTS(); }
function updateTS() {
  const bar = $('#tsBar'), lb = $('#liveBadge');
  const on = isLiveEngine() && rewindSecs() > 0 && video.buffered.length;
  bar.hidden = !on;
  if (!on) { lb.classList.remove('behind'); lb.textContent = 'EN DIRECT'; return; }
  const s = bufStart(), r = Math.max(liveRef(), s + 0.1), span = Math.max(r - s, 0.1);
  const pos = clamp((video.currentTime - s) / span, 0, 1);
  $('#tsFill').style.width = (pos * 100) + '%'; $('#tsKnob').style.left = (pos * 100) + '%';
  const bh = Math.max(0, r - video.currentTime), behind = (PL.behind || video.paused) && bh > 3;
  $('#tsLab').textContent = behind ? '−' + fmtT(bh) : '';
  $('#tsMax').textContent = span > 15 ? 'jusqu\'à −' + fmtT(span) : 'mémorisation…';
  lb.classList.toggle('behind', behind); lb.textContent = behind ? 'REVENIR AU DIRECT' : 'EN DIRECT';
}
$('#liveBadge').onclick = () => goLive();
(() => {
  const tr = $('#tsTrack'); let drag = false;
  const at = e => { const r = tr.getBoundingClientRect(), f = clamp((e.clientX - r.left) / r.width, 0, 1); const s = bufStart(); tsSeek(s + f * (Math.max(liveRef(), s) - s)); };
  tr.addEventListener('pointerdown', e => { e.stopPropagation(); drag = true; tr.setPointerCapture(e.pointerId); at(e); });
  tr.addEventListener('pointermove', e => { if (drag) at(e); });
  tr.addEventListener('pointerup', () => { drag = false; });
  tr.addEventListener('click', e => e.stopPropagation());
})();
// rattrapage du direct (TS) + adaptation de la mémoire au débit de la chaîne
let tsTick = 0;
setInterval(() => {
  if (!isLiveEngine()) { if (!$('#tsBar').hidden) updateTS(); return; }
  const lag = liveRef() - video.currentTime;
  if (PL.mts && !PL.behind && !video.paused) {
    if (lag > 20) video.currentTime = liveRef();
    else video.playbackRate = lag > 6 ? 1.08 : lag < 1.5 ? 1 : video.playbackRate;
  } else if (video.playbackRate !== 1) video.playbackRate = 1;
  if (PL.behind && !video.paused && lag < 4) PL.behind = false;
  if (++tsTick % 10 === 0) {
    // garde la mémoire tampon sous la limite du navigateur selon le débit réel
    let bps = 0;
    try { if (PL.mts) bps = (PL.mts.statisticsInfo.speed || 0) * 1024; else if (PL.hls) { const l = PL.hls.levels[PL.hls.currentLevel]; bps = l ? l.bitrate / 8 : 0; } } catch { }
    const want = rewindSecs();
    const maxBack = bps > 0 ? clamp(QUOTA * 0.75 / bps - 30, 30, Math.max(30, want)) : Math.max(30, want);
    try {
      if (PL.mts && PL.mts._config) { PL.mts._config.autoCleanupMaxBackwardDuration = maxBack; PL.mts._config.autoCleanupMinBackwardDuration = Math.max(20, maxBack - 20); }
      if (PL.hls) PL.hls.config.backBufferLength = maxBack;
    } catch { }
    // en pause trop longtemps : on garde seulement la fenêtre possible
    if (video.paused && bufEnd() - video.currentTime > maxBack) video.currentTime = bufEnd() - maxBack * 0.85;
  }
  if (player.classList.contains('ui') || video.paused || PL.behind) updateTS();
}, 500);

// surveillance : si l'image se fige sur du direct, on relance tout seul
setInterval(() => {
  if (!PL.ch || PL.ch.k !== 'live' || video.paused || !$('#pErr').hidden) return;
  const t = video.currentTime;
  if (t !== PL.lastT) { PL.lastT = t; PL.lastMove = Date.now(); return; }
  if (Date.now() - PL.lastMove > 12000 && (PL.restarts || 0) < 4) { PL.restarts = (PL.restarts || 0) + 1; PL.lastMove = Date.now(); start(); }
}, 2000);

function zap(d) {
  const L = PL.ctx && PL.ctx.length ? PL.ctx : view.items; if (!L.length) return;
  let i = PL.ch ? L.findIndex(c => c.key === PL.ch.key) : -1;
  i = (i + d + L.length) % L.length;
  play(L[i]);
  if (L === view.items || view.items.indexOf(L[i]) >= 0) { const j = view.items.findIndex(c => c.key === L[i].key); if (j >= 0) setCursor(j); }
}
let lastPlayed = null;
function addRecent(c) {
  if (PL.prevKey && PL.prevKey !== c.key) lastPlayed = S.recents.find(r => r.key === PL.prevKey) || lastPlayed;
  PL.prevKey = c.key;
  S.recents = [snap(c), ...S.recents.filter(r => r.key !== c.key)].slice(0, 40);
  if (UI.sel.t === 'recents') { /* pas de re-tri pendant la navigation */ } else renderSideCounts();
}
function renderSideCounts() { const b = $('.s-item[data-t="recents"] .n', side); if (b) b.textContent = S.recents.length; }

/* OSD + barre */
function showOSD() {
  const c = PL.ch; if (!c) return;
  const p = nowProg(c), L = PL.ctx || [], n = L.findIndex(x => x.key === c.key);
  $('#osd').innerHTML = `${n >= 0 ? `<span class="o-num">${n + 1}</span>` : ''}${logoHTML(c)}<div><div class="o-nm">${esc(c.dn || c.n)}</div><div class="o-sub">${p ? `${hm(p[0])} – ${hm(p[1])} · ${esc(p[2])}` : esc(catLabel(c.k, c.g))}</div></div>`;
  $('#osd').classList.add('show'); clearTimeout(PL.osdT); PL.osdT = setTimeout(() => $('#osd').classList.remove('show'), 3800);
}
function updateBar() {
  $('#pbPlay').innerHTML = ic(video.paused ? 'play' : 'pause');
  $('#pbMute').innerHTML = ic(video.muted || video.volume === 0 ? 'mute' : 'vol');
  $('#pbVol').value = video.muted ? 0 : video.volume;
  $('#pbFull').innerHTML = ic(realFull() ? 'unfull' : 'full');
  $('#pbFav').classList.toggle('on', !!PL.ch && isFav(PL.ch));
  $('#pbTitle').textContent = PL.ch ? PL.ch.n : '';
  player.classList.toggle('paused', !!PL.ch && video.paused && !!(PL.hls || PL.mts || video.getAttribute('src')));
  $('#pbPip').hidden = !document.pictureInPictureEnabled;
  const cb = $('#pbCast'); if (window.VkCast && VkCast.native()) { cb.hidden = false; if (!cb.innerHTML) cb.innerHTML = VkCast.icon; }
  if (typeof recPaint === 'function') recPaint();
}
$('#pbPlay').onclick = () => video.paused ? tryPlay() : video.pause();
$('#pbMute').onclick = () => { video.muted = !video.muted; if (!video.muted && video.volume === 0) video.volume = .6; };
$('#pbVol').oninput = e => { video.volume = +e.target.value; video.muted = +e.target.value === 0; };
$('#pbPrev').onclick = () => zap(-1);
$('#pbNext').onclick = () => zap(1);
$('#pbFav').onclick = () => PL.ch && toggleFav(PL.ch);
$('#pbPip').onclick = async () => { try { document.pictureInPictureElement ? await document.exitPictureInPicture() : await video.requestPictureInPicture(); } catch { } };
$('#pbFull').onclick = toggleFull;
const isFull = () => !!(document.fullscreenElement || document.webkitFullscreenElement || player.classList.contains('fs') || app.classList.contains('watch'));
const realFull = () => !!(document.fullscreenElement || document.webkitFullscreenElement || player.classList.contains('fs'));
function toggleFull() {
  if (!PL.ch) return;
  if (UI.layout === 'home' && !app.classList.contains('watch')) return enterWatch();
  if (realFull()) { (document.exitFullscreen || document.webkitExitFullscreen)?.call(document); player.classList.remove('fs'); }
  else if (player.requestFullscreen) player.requestFullscreen().catch(() => player.classList.add('fs'));
  else if (player.webkitRequestFullscreen) player.webkitRequestFullscreen();
  else if (video.webkitEnterFullscreen) video.webkitEnterFullscreen();
  else player.classList.add('fs');
}
document.addEventListener('fullscreenchange', () => { updateBar(); if (isFull()) showOSD(); });
player.addEventListener('dblclick', e => { if (!e.target.closest('.pbar')) toggleFull(); });
player.addEventListener('click', e => {
  if (e.target.closest('.pbar,.p-err,.strip,.back')) return;
  if (UI.layout === 'home' && !app.classList.contains('watch')) { if (PL.ch) enterWatch(); return; }
  if (isTouch) { pokeUI(); return; }
  if (PL.ch && PL.ch.k === 'live') { /* simple clic : afficher l'info */ showOSD(); pokeUI(); }
});
function pokeUI() { player.classList.add('ui'); player.classList.remove('hidecur'); clearTimeout(PL.uiT); PL.uiT = setTimeout(() => { player.classList.remove('ui'); if (isFull()) player.classList.add('hidecur'); }, 2600); }
player.addEventListener('mousemove', pokeUI);

/* panneau « en cours » */
function renderNP() {
  const np = $('#np'), c = PL.ch;
  if (!c) {
    np.innerHTML = `<div class="np-tips"><span><kbd>Ctrl K</kbd>ou tape directement : recherche</span><span><kbd>↑</kbd><kbd>↓</kbd> parcourir</span><span><kbd>Entrée</kbd> lire / plein écran</span><span><kbd>1</kbd><kbd>2</kbd><kbd>3</kbd> aller au n°</span><span><kbd>⌫</kbd> chaîne précédente</span></div>`;
    return;
  }
  const fav = isFav(c), a = progs(c), t = Date.now() / 1000;
  let ep = '';
  if (a) {
    const i = a.findIndex(p => p[1] > t);
    const sl = i >= 0 ? a.slice(i, i + 5) : [];
    ep = sl.map((p, j) => { const now = p[0] <= t; const pc = now ? clamp((t - p[0]) / (p[1] - p[0]) * 100, 0, 100) : 0; const rb = typeof recEpBtn === 'function' ? recEpBtn(c, p) : ''; return `<div class="ep${now ? ' now' : ''}${rb ? ' hasrec' : ''}"><div class="tm">${hm(p[0])} – ${hm(p[1])}</div><div><div class="ti">${esc(p[2])}</div>${p[3] && j < 2 ? `<div class="ds">${esc(p[3])}</div>` : ''}${now ? `<div class="prog"><i style="width:${pc.toFixed(1)}%"></i></div>` : ''}</div>${rb}</div>`; }).join('');
  }
  np.innerHTML = `<div class="np-top">${logoHTML(c)}<div class="np-id"><div class="np-nm">${esc(c.dn || c.n)}</div><div class="np-cat">${esc(catLabel(c.k, c.g))}${c.q ? ' · ' + c.q : ''}</div></div></div>
  <div class="np-acts">
    <button class="act${fav ? ' on' : ''}" id="npFav">${ic('star')}${fav ? 'Dans tes favoris' : 'Ajouter aux favoris'}</button>
    <button class="act" id="npList">${ic('list')}Ajouter à une liste</button>
    <button class="act" id="npCat">${ic('folder')}Voir la catégorie</button>
    <button class="act" id="npFull">${ic('full')}Plein écran</button>
    <button class="act" id="npCopy">${ic('copy')}Lien VLC</button>
  </div>
  ${ep ? `<div class="epg">${ep}</div>` : ''}`;
  $('#npFav').onclick = () => toggleFav(c);
  $('#npList').onclick = e => { const r = e.currentTarget.getBoundingClientRect(); menu(r.left, r.bottom + 6, [...S.lists.map(l => ({ label: l.name, icon: l.id === 'fav' ? 'star' : 'list', ck: l.items.some(i => i.key === c.key), act: () => addToList(l, [c]) })), '-', { label: 'Nouvelle liste…', icon: 'plus', act: () => newList(l => addToList(l, [c])) }]); };
  $('#npCat').onclick = () => goCat(c);
  $('#npFull').onclick = toggleFull;
  $('#npCopy').onclick = () => copy(c.u);
  if (typeof recPaint === 'function') recPaint();
}
setInterval(() => { paintRows(true); if (PL.ch) renderNP(); }, 60000);

/* ------------------------------------------------------------ recherche globale */
const pal = $('#pal'), palIn = $('#palInput'), palRes = $('#palRes');
let palKind = 'all', palItems = [], palCur = 0;
const PAL_KINDS = [['all', 'Tout'], ['live', 'Direct'], ['movie', 'Films'], ['series', 'Séries'], ['cat', 'Catégories']];
function openSearch(initial = '') {
  closeMenu(); pal.hidden = false; palIn.value = initial; palCur = 0;
  palIn.focus(); palIn.setSelectionRange(palIn.value.length, palIn.value.length);
  renderChips(); runSearch();
}
function closeSearch() { pal.hidden = true; palIn.blur(); }
function renderChips() {
  const has = k => k === 'all' || k === 'cat' || GROUPS[k]?.size;
  $('#palChips').innerHTML = PAL_KINDS.filter(([k]) => has(k)).map(([k, l]) => `<button data-k="${k}" class="${palKind === k ? 'on' : ''}">${l}</button>`).join('');
}
$('#palChips').onclick = e => { const b = e.target.closest('button'); if (!b) return; palKind = b.dataset.k; renderChips(); runSearch(); palIn.focus(); };
function hl(name, toks) {
  // surligne les morceaux trouvés (approximatif mais suffisant)
  let s = esc(name);
  for (const t of toks) { if (t.length < 2) continue; const re = new RegExp('(' + t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'i'); s = s.replace(re, '<mark>$1</mark>'); }
  return s;
}
function scoreName(nn, nc, toks, q, qc) {
  if (nn === q) return 1000;
  let s = 0;
  for (const t of toks) { const p = nn.indexOf(t); if (p < 0) { s = -1; break; } s += p === 0 ? 60 : nn.charCodeAt(p - 1) === 32 ? 40 : 8; }
  if (s < 0) { if (qc.length > 2 && nc.includes(qc)) s = 30; else return 0; }
  if (nn.startsWith(q)) s += 200; else if (nn.includes(' ' + q)) s += 120; else if (nn.includes(q)) s += 60;
  return s - nn.length * 0.25;
}
function runSearch() {
  const raw = palIn.value, q = norm(raw), toks = q ? q.split(' ') : [], qc = q.replace(/ /g, '');
  const res = [];
  if (!q) {
    const rec = S.recents.slice(0, 8).map(resolve), fav = favList().items.slice(0, 12).map(resolve);
    if (rec.length) res.push({ h: 'Récents' }, ...rec.map(c => ({ c })));
    if (fav.length) res.push({ h: 'Chaînes favorites' }, ...fav.map(c => ({ c })));
    const fcs = validFavCats();
    if (fcs.length) res.push({ h: 'Catégories favorites' }, ...fcs.map(f => ({ cat: { k: f.k, g: f.g, lab: catLabel(f.k, f.g), n: GROUPS[f.k].get(f.g).length } })));
    if (!res.length) res.push({ empty: CH.length ? 'Tape le nom d\'une chaîne, d\'un film ou d\'un programme' : 'Ajoute d\'abord ta playlist dans les paramètres' });
  } else {
    const t0 = Date.now() / 1000;
    // catégories
    if (palKind === 'all' || palKind === 'cat') {
      const cats = [];
      for (const k of ['live', 'movie', 'series']) for (const g of GROUPS[k].keys()) {
        const lab = catLabel(k, g), ln = norm(lab); const sc = scoreName(ln, ln.replace(/ /g, ''), toks, q, qc);
        if (sc > 0) cats.push({ cat: { k, g, lab, n: GROUPS[k].get(g).length }, s: sc + (k === 'live' ? 20 : 0) + (isFavCat(k, g) ? 150 : 0) - (catSt(k).hidden[g] ? 80 : 0) });
      }
      cats.sort((a, b) => b.s - a.s);
      const lim = palKind === 'cat' ? 60 : 4;
      if (cats.length) res.push({ h: 'Catégories' }, ...cats.slice(0, lim));
    }
    if (palKind !== 'cat') {
      const hits = [], progHits = [];
      const recentKeys = new Map(S.recents.map((r, i) => [r.key, i]));
      for (let i = 0; i < CH.length; i++) {
        const c = CH[i];
        if (palKind !== 'all' && c.k !== palKind) continue;
        let sc = scoreName(c.nn, c.nc, toks, q, qc);
        if (sc > 0) {
          if (favSet.has(c.key)) sc += 150;
          const r = recentKeys.get(c.key); if (r !== undefined) sc += 90 - r;
          if (c.k === 'live') sc += 25;
          if (catSt(c.k).hidden[c.g]) sc -= 70;
          hits.push({ c, s: sc });
        } else if (c.k === 'live' && c.tl && q.length >= 3) {
          const p = nowProg(c, t0);
          if (p) { const pn = norm(p[2]); if (toks.every(t => pn.includes(t))) progHits.push({ c, p, s: (favSet.has(c.key) ? 50 : 0) - (catSt(c.k).hidden[c.g] ? 70 : 0) }); }
        }
      }
      hits.sort((a, b) => b.s - a.s);
      // dédoublonne les noms identiques (souvent la même chaîne en plusieurs qualités) : on garde l'ordre
      if (hits.length) res.push({ h: `Résultats · ${hits.length.toLocaleString('fr-FR')}` }, ...hits.slice(0, 80).map(x => ({ c: x.c })));
      if (progHits.length) { progHits.sort((a, b) => b.s - a.s); res.push({ h: 'En ce moment à l\'antenne' }, ...progHits.slice(0, 12).map(x => ({ c: x.c, p: x.p }))); }
    }
    if (!res.length) res.push({ empty: `Aucun résultat pour « ${raw} »` });
  }
  palItems = res; palCur = res.findIndex(r => r.c || r.cat); renderPal(toks);
}
function renderPal(toks) {
  palRes.innerHTML = palItems.map((r, i) => {
    if (r.h) return `<div class="pr-h">${esc(r.h)}</div>`;
    if (r.empty) return `<div class="pal-empty">${esc(r.empty)}</div>`;
    if (r.cat) return `<div class="pr${i === palCur ? ' on' : ''}" data-i="${i}"><span class="cat-ic">${ic('folder')}</span><span class="mt"><span class="nm">${hl(r.cat.lab, toks || [])}${isFavCat(r.cat.k, r.cat.g) ? ' <span class="fv">★</span>' : ''}</span><span class="sub"><span class="t">${KINDS.find(k => k.k === r.cat.k).label} · ${r.cat.n} éléments${catSt(r.cat.k).hidden[r.cat.g] ? ' · masquée' : ''}</span></span></span><span class="kd">Catégorie</span></div>`;
    const c = r.c, p = r.p || (c.k === 'live' ? nowProg(c) : null);
    return `<div class="pr${i === palCur ? ' on' : ''}" data-i="${i}">${logoHTML(c)}<span class="mt"><span class="nm">${hl(c.dn || c.n, toks || [])}${c.q ? `<span class="q">${c.q}</span>` : ''}${isFav(c) ? ` <span class="fv">★</span>` : ''}</span><span class="sub"><span class="t">${p ? `${hm(p[0])} · ${r.p ? hl(p[2], toks || []) : esc(p[2])}` : esc(catLabel(c.k, c.g))}</span></span></span><span class="kd">${c.k === 'live' ? 'Direct' : c.k === 'movie' ? 'Film' : 'Série'}</span></div>`;
  }).join('');
  palRes.querySelector('.pr.on')?.scrollIntoView({ block: 'nearest' });
}
let palRaf = 0;
palIn.addEventListener('input', () => { cancelAnimationFrame(palRaf); palRaf = requestAnimationFrame(runSearch); });
function palMove(d) {
  if (!palItems.length) return;
  let i = palCur;
  for (let n = 0; n < palItems.length; n++) { i = (i + d + palItems.length) % palItems.length; if (palItems[i].c || palItems[i].cat) break; }
  palCur = i;
  $$('.pr', palRes).forEach(el => el.classList.toggle('on', +el.dataset.i === palCur));
  palRes.querySelector('.pr.on')?.scrollIntoView({ block: 'nearest' });
}
function palPick(i, alt) {
  const r = palItems[i]; if (!r) return;
  if (r.cat && alt) { toggleFavCat(r.cat.k, r.cat.g); runSearch(); return; }
  if (r.cat) {
    closeSearch();
    if (UI.layout === 'home') { UI.page = 'home'; if (UI.kind !== r.cat.k) UI.kind = r.cat.k; return goList({ t: 'cat', id: r.cat.g }, r.cat.k); }
    if (UI.kind !== r.cat.k) { UI.kind = r.cat.k; renderKinds(); }
    if (catSt(r.cat.k).hidden[r.cat.g]) { delete catSt(r.cat.k).hidden[r.cat.g]; save(); }
    UI.sel = { t: 'cat', id: r.cat.g }; saveUI(); renderSide(); openView();
    $('.s-item.on', side)?.scrollIntoView({ block: 'center' });
    return;
  }
  if (!r.c) return;
  if (alt) { toggleFav(r.c); runSearch(); return; }
  closeSearch();
  // contexte de zapping : la catégorie de la chaîne
  const c = r.c;
  const ctxL = c.missing ? [c] : (GROUPS[c.k].get(c.g) || [c]);
  play(c, ctxL);
  const j = view.items.findIndex(x => x.key === c.key); if (j >= 0) setCursor(j, true);
}
palRes.addEventListener('click', e => { const el = e.target.closest('.pr'); if (el) palPick(+el.dataset.i); });
palRes.addEventListener('contextmenu', e => { const el = e.target.closest('.pr'); if (!el) return; const r = palItems[+el.dataset.i]; if (r?.c) { e.preventDefault(); chanMenu(r.c, e.clientX, e.clientY); } });
palIn.addEventListener('keydown', e => {
  if (e.key === 'ArrowDown') { e.preventDefault(); palMove(1); }
  else if (e.key === 'ArrowUp') { e.preventDefault(); palMove(-1); }
  else if (e.key === 'PageDown') { e.preventDefault(); for (let i = 0; i < 8; i++) palMove(1); }
  else if (e.key === 'PageUp') { e.preventDefault(); for (let i = 0; i < 8; i++) palMove(-1); }
  else if (e.key === 'Enter') { e.preventDefault(); palPick(palCur, e.ctrlKey || e.metaKey); }
  else if (e.key === 'Tab') { e.preventDefault(); const ks = [...$$('#palChips button')].map(b => b.dataset.k); palKind = ks[(ks.indexOf(palKind) + (e.shiftKey ? ks.length - 1 : 1)) % ks.length]; renderChips(); runSearch(); }
  else if (e.key === 'Escape') { e.preventDefault(); closeSearch(); }
});
pal.addEventListener('pointerdown', e => { if (e.target === pal) closeSearch(); });
$('#btnSearch').onclick = () => openSearch();

/* ------------------------------------------------------------ organiser les catégories */
let orgKind = 'live', orgSortable = null;
function openOrganizer() {
  closeMenu(); closeDrawer();
  if (!CH.length) { toast('Ajoute d\'abord ta playlist'); return openSettings(); }
  orgKind = GROUPS[UI.kind].size ? UI.kind : 'live';
  $('#org').hidden = false; $('#orgFilter').value = ''; renderOrg();
  setTimeout(() => $('#orgFilter').focus(), 30);
}
function orgVisible() {
  const f = norm($('#orgFilter').value), toks = f ? f.split(' ') : [];
  return orderedGroups(orgKind, true).filter(g => !toks.length || toks.every(t => norm(g + ' ' + catLabel(orgKind, g)).includes(t)));
}
function renderOrg() {
  $('#orgKinds').innerHTML = KINDS.filter(k => GROUPS[k.k].size).map(k => `<button data-k="${k.k}" class="${orgKind === k.k ? 'on' : ''}">${k.label}</button>`).join('');
  const st = catSt(orgKind), vis = orgVisible(), all = GROUPS[orgKind].size;
  const hid = Object.keys(st.hidden).filter(g => GROUPS[orgKind].has(g)).length;
  $('#orgStats').textContent = `${all - hid} visibles · ${hid} masquées${vis.length !== all ? ` · ${vis.length} affichées par le filtre` : ''}`;
  const filt = !!$('#orgFilter').value.trim();
  $('#orgOnly').hidden = $('#orgHideRes').hidden = $('#orgShowRes').hidden = !filt;
  const list = $('#orgList');
  list.innerHTML = vis.map(g => {
    const off = !!st.hidden[g], ren = st.renamed[g];
    return `<div class="oc${off ? ' off' : ''}" data-g="${esc(g)}"><span class="grip">${ic('grip')}</span><span class="on"><b>${esc(ren || g)}</b>${ren ? `<small>${esc(g)}</small>` : ''}</span><span class="n">${GROUPS[orgKind].get(g).length}</span><button class="ostar${isFavCat(orgKind, g) ? ' on' : ''}" title="Catégorie favorite">${ic('star')}</button><button class="top" title="Tout en haut">${ic('up')}</button><button class="ren" title="Renommer">${ic('edit')}</button><button class="eye" title="${off ? 'Afficher' : 'Masquer'}">${ic(off ? 'eyeoff' : 'eye')}</button></div>`;
  }).join('') || '<div class="pal-empty">Aucune catégorie</div>';
  if (orgSortable) orgSortable.destroy();
  orgSortable = Sortable.create(list, {
    animation: 150, handle: '.grip', onEnd: () => {
      const newVis = [...list.children].map(el => el.dataset.g);
      const full = orderedGroups(orgKind, true), set = new Set(vis);
      let k = 0; st.order = full.map(g => set.has(g) ? newVis[k++] : g);
      save(); renderSide(); if (UI.sel.t === 'all') openView(true);
    },
  });
}
$('#orgKinds').onclick = e => { const b = e.target.closest('button'); if (b) { orgKind = b.dataset.k; renderOrg(); } };
$('#orgFilter').oninput = renderOrg;
$('#orgList').addEventListener('click', e => {
  const row = e.target.closest('.oc'); if (!row) return; const g = row.dataset.g, st = catSt(orgKind);
  if (e.target.closest('.ostar')) { toggleFavCat(orgKind, g); renderOrg(); return; }
  if (e.target.closest('.eye')) { st.hidden[g] ? delete st.hidden[g] : st.hidden[g] = 1; }
  else if (e.target.closest('.top')) { st.order = [g, ...orderedGroups(orgKind, true).filter(x => x !== g)]; }
  else if (e.target.closest('.ren')) return renameInline(row, g);
  else return;
  save(); renderOrg(); renderSide(); openView(true);
});
$('#orgList').addEventListener('dblclick', e => { const row = e.target.closest('.oc'); if (row && !e.target.closest('button')) renameInline(row, row.dataset.g); });
function renameInline(row, g) {
  const st = catSt(orgKind), slot = row.querySelector('.on');
  slot.innerHTML = `<input value="${esc(st.renamed[g] || g)}">`;
  const inp = slot.querySelector('input'); inp.focus(); inp.select();
  const done = ok => { if (ok) { const v = inp.value.trim(); if (v && v !== g) st.renamed[g] = v; else delete st.renamed[g]; save(); renderSide(); openView(true); } renderOrg(); };
  inp.onkeydown = e => { e.stopPropagation(); if (e.key === 'Enter') done(true); if (e.key === 'Escape') done(false); };
  inp.onblur = () => done(true);
}
function orgBulk(fn) { const st = catSt(orgKind); fn(st, orgVisible()); save(); renderOrg(); renderSide(); openView(true); }
$('#orgHideRes').onclick = () => orgBulk((st, v) => v.forEach(g => st.hidden[g] = 1));
$('#orgShowRes').onclick = () => orgBulk((st, v) => v.forEach(g => delete st.hidden[g]));
$('#orgOnly').onclick = () => orgBulk((st, v) => { const keep = new Set(v); for (const g of GROUPS[orgKind].keys()) keep.has(g) ? delete st.hidden[g] : st.hidden[g] = 1; toast(`${v.length} catégorie(s) gardée(s), les autres sont masquées`); });
$('#orgSortAZ').onclick = () => orgBulk(st => { st.order = orderedGroups(orgKind, true).sort((a, b) => catLabel(orgKind, a).localeCompare(catLabel(orgKind, b), 'fr', { numeric: true })); });
$('#orgReset').onclick = () => { if (confirm('Remettre l\'ordre d\'origine, ré-afficher et dé-renommer toutes les catégories de cet onglet ?')) orgBulk(st => { st.order = []; st.hidden = {}; st.renamed = {}; }); };
$('#btnOrganize').onclick = openOrganizer;

/* ------------------------------------------------------------ paramètres */
function openSettings() { closeMenu(); closeDrawer(); $('#set').hidden = false; renderSettings(); }
async function renderSettings() {
  const st = S.settings;
  const pls = S.playlists.map(p => `<div class="pl${p.id === S.activePid ? ' on' : ''}" data-id="${p.id}"><span class="dot"></span><span class="pl-t"><b>${esc(p.name)}</b><small>${p.type === 'xtream' ? 'Xtream · ' + esc(p.server) : p.type === 'file' ? 'Fichier importé' : esc(p.url)}</small></span>
    ${p.id !== S.activePid ? `<button class="btn sm ghost" data-a="use">Utiliser</button>` : `<button class="btn sm ghost" data-a="refresh" title="Recharger depuis le fournisseur">${ic('refresh')}Actualiser</button>`}
    <button class="ibtn" data-a="edit" title="Modifier">${ic('edit')}</button><button class="ibtn" data-a="del" title="Supprimer">${ic('trash')}</button></div>`).join('');
  const tg = (k, t, d) => `<div class="tg"><div><b>${t}</b><small>${d}</small></div><button class="sw${st[k] ? ' on' : ''}" data-k="${k}"></button></div>`;
  $('#setBody').innerHTML = `
  <div class="set-sec"><h4>Playlists</h4>${pls || '<p class="mut">Aucune playlist pour l\'instant.</p>'}<button class="btn" id="setAdd">${ic('plus')}Ajouter une playlist</button></div>
  <div class="set-sec"><h4>Mon compte en ligne</h4><div id="cloudBox"><p class="mut">…</p></div></div>
  ${(IS_APP && !window.VK_DIRECT) || window.VK_APK ? '<div class="set-sec"><h4>Version et mises à jour</h4><div id="updBox"></div></div>' : ''}
  <div class="set-sec"><h4>Sur ton téléphone et ta TV</h4><div class="qr-box" id="qrBox"><p class="mut">Recherche de l'adresse…</p></div></div>
  <div class="set-sec"><h4>Lecture</h4>
    <div class="tg"><div><b>Format des flux en direct</b><small>« Auto » convient presque toujours. Si une chaîne saccade ou ne se lance pas, essaie HLS.</small></div>
    <div class="seg" id="fmtSeg">${[['auto', 'Auto'], ['ts', 'TS'], ['hls', 'HLS']].map(([k, l]) => `<button data-f="${k}" class="${st.format === k ? 'on' : ''}">${l}</button>`).join('')}</div></div>
    <div class="tg"><div><b>Retour en arrière sur le direct</b><small>Depuis le moment où tu lances la chaîne. Gardé en mémoire vive (RAM), rien n'est écrit sur ton disque.${IS_APP ? '' : ' Sur téléphone/TV : 3 min max.'}</small></div>
    <div class="seg" id="rwSeg">${[[0, 'Non'], [10, '10 min'], [30, '30 min'], [60, '1 h']].map(([k, l]) => `<button data-rw="${k}" class="${+st.rewind === k ? 'on' : ''}">${l}</button>`).join('')}</div></div>
    ${tg('epg', 'Guide des programmes', 'Affiche le programme en cours et permet de chercher « PSG », « JT »…')}
  </div>
  <div class="set-sec"><h4>Affichage</h4>
    ${tg('logos', 'Logos des chaînes', 'Désactive si ta playlist a beaucoup de logos cassés')}
    ${tg('tv', 'Mode TV (télécommande)', 'Gros textes, navigation aux flèches ← ↑ → ↓ et OK. Idéal sur le navigateur de ta TV.')}
    <div class="tg"><div><b>Couleur</b><small>Couleur d'accent de l'interface</small></div><div class="swatches">${ACCENTS.map(a => `<button data-c="${a}" class="${st.accent === a ? 'on' : ''}" style="background:${a}"></button>`).join('')}</div></div>
  </div>
  <div class="set-sec"><h4>Sauvegarde</h4><p class="mut" style="margin:0 0 10px">Tes catégories, favoris et listes sont enregistrés sur ce PC et partagés avec ton téléphone et ta TV. Exporte-les de temps en temps pour avoir une sauvegarde.</p>
    <button class="btn ghost" id="setExport">${ic('down')}Exporter ma config</button> <label class="btn ghost" style="cursor:pointer">${ic('up')}Importer<input type="file" id="setImport" accept=".json" hidden></label></div>`;
  fillQR(); if (typeof fillCloud === 'function') fillCloud(); if (typeof updLoad === 'function') { if (window.VK_DIRECT) fillUpdate(); else updLoad(); }
}
async function fillQR() {
  const box = $('#qrBox'); if (!box) return;
  if (window.VK_DIRECT) {
    box.innerHTML = `<div><p>Cette appli fonctionne seule, sans le PC.</p><p class="mut">Pour récupérer tes playlists, catégories et favoris de VkTV sur ton PC (même Wi-Fi, VkTV ouvert sur le PC) :</p><button class="btn" id="pullPc">Copier la config de mon PC</button></div>`;
    $('#pullPc').onclick = pullFromPc;
    return;
  }
  let urls = [];
  try { const r = await fetch('api/info'); const j = await r.json(); urls = j.lan || []; } catch { }
  const here = location.hostname;
  const url = (here !== 'localhost' && here !== '127.0.0.1') ? location.origin : urls[0];
  if (!url) { box.innerHTML = '<p class="mut">Adresse réseau introuvable — vérifie que le PC est connecté au Wi-Fi/au box.</p>'; return; }
  let img = '';
  try { const q = qrcode(0, 'M'); q.addData(url); q.make(); img = `<div class="qr">${q.createImgTag(4, 0)}</div>`; } catch { }
  box.innerHTML = `${img}<div><p>Sur le même Wi-Fi, scanne ce code ou ouvre :</p><code>${esc(url)}</code><p>📱 <b>Téléphone</b> : ouvre le lien puis « Ajouter à l'écran d'accueil » → ça devient une appli.<br>📺 <b>TV</b> : ouvre ce lien dans le navigateur de la TV puis active le <b>Mode TV</b>.<br><span class="mut">Le PC doit rester allumé avec VkTV lancé.</span></p></div>`;
}
$('#setBody').addEventListener('click', async e => {
  const t = e.target;
  if (t.closest('#setAdd')) return openPlaylistForm();
  const sw = t.closest('.sw');
  if (sw) { const k = sw.dataset.k; S.settings[k] = !S.settings[k]; save(); applySettings(); renderSettings(); if (k === 'logos') paintRows(true); if (k === 'epg' && S.settings.epg) loadEpg(); return; }
  const rwb = t.closest('#rwSeg button'); if (rwb) { S.settings.rewind = +rwb.dataset.rw; save(); renderSettings(); if (PL.ch && PL.ch.k === 'live') play(PL.ch); return; }
  const f = t.closest('#fmtSeg button'); if (f) { S.settings.format = f.dataset.f; save(); renderSettings(); if (PL.ch) play(PL.ch); return; }
  const c = t.closest('.swatches button'); if (c) { S.settings.accent = c.dataset.c; save(); applySettings(); renderSettings(); return; }
  if (t.closest('#setExport')) { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(S, null, 1)], { type: 'application/json' })); a.download = 'vktv-config.json'; a.click(); return; }
  const pl = t.closest('.pl'); const a = t.closest('[data-a]');
  if (pl && a) {
    const p = S.playlists.find(x => x.id === pl.dataset.id);
    if (a.dataset.a === 'use') { S.activePid = p.id; save(); closeModals(); await loadPlaylist(); }
    if (a.dataset.a === 'refresh') { closeModals(); await loadPlaylist(true); }
    if (a.dataset.a === 'edit') openPlaylistForm(p);
    if (a.dataset.a === 'del' && confirm(`Supprimer la playlist « ${p.name} » ? (tes favoris restent)`)) {
      S.playlists = S.playlists.filter(x => x !== p); if (S.activePid === p.id) S.activePid = S.playlists[0]?.id || null; save(); renderSettings(); loadPlaylist();
    }
  }
});
$('#setBody').addEventListener('change', async e => {
  if (e.target.id !== 'setImport' || !e.target.files[0]) return;
  try { const o = JSON.parse(await e.target.files[0].text()); if (!o.v) throw 0; S = hydrate(o); rebuildFavSet(); save(); await saveNow(); applySettings(); closeModals(); toast('Config importée'); loadPlaylist(); }
  catch { toast('Fichier de config invalide', true); }
});
async function pullFromPc() {
  const last = local.get('pcip', '192.168.1.');
  const ip = await askText('Adresse de ton PC (affichée dans VkTV sur le PC : Paramètres › Sur ton téléphone et ta TV)', last, { placeholder: 'ex : 192.168.1.20', ok: 'Récupérer' });
  if (!ip) return;
  local.set('pcip', ip.trim());
  const base = /^https?:/.test(ip.trim()) ? ip.trim().replace(/\/$/, '') : 'http://' + ip.trim().replace(/\/$/, '') + (/:\d+$/.test(ip.trim()) ? '' : ':8787');
  try {
    const r = await fetch(base + '/api/state', { cache: 'no-store' });
    const o = await r.json();
    if (!o || !o.v) throw new Error('réponse vide');
    S = hydrate({ ...o, settings: { ...o.settings, tv: S.settings.tv } }); rebuildFavSet(); save(); await saveNow(); applySettings(); closeModals();
    toast(`Config copiée : ${S.playlists.length} playlist${S.playlists.length > 1 ? 's' : ''}`); loadPlaylist(true);
  } catch (e) { toast('PC introuvable — vérifie l\'adresse, le Wi-Fi et que VkTV est ouvert sur le PC', true); }
}
function applySettings() {
  document.body.classList.toggle('tv', !!S.settings.tv || new URLSearchParams(location.search).has('tv'));
  document.documentElement.style.setProperty('--acc', S.settings.accent || ACCENTS[0]);
  if (view.mode === 'virtual') { rowsEl.style.height = view.items.length * rowH() + 'px'; paintRows(true); }
}
$('#btnSettings').onclick = openSettings;

/* formulaire playlist */
let plmEdit = null, plmType = 'xtream';
function openPlaylistForm(p) {
  plmEdit = p || null; plmType = p?.type || 'xtream';
  $('#plmTitle').textContent = p ? 'Modifier la playlist' : 'Ajouter ta playlist';
  $('#plmName').value = p?.name || ''; $('#plmServer').value = p?.server || ''; $('#plmUser').value = p?.user || '';
  $('#plmPass').value = p?.pass || ''; $('#plmUrl').value = p?.url || ''; $('#plmEpg').value = p?.epg || ''; $('#plmFile').value = '';
  $('#plmErr').hidden = true; $('#plm').hidden = false; plmSetType(plmType);
}
function plmSetType(t) {
  plmType = t;
  $$('#plmType button').forEach(b => b.classList.toggle('on', b.dataset.t === t));
  $$('#plm [data-show]').forEach(d => d.hidden = d.dataset.show !== t);
}
$('#plmType').onclick = e => { const b = e.target.closest('button'); if (b) plmSetType(b.dataset.t); };
// coller un lien get.php complet dans le champ M3U : on propose de le transformer en Xtream
$('#plmUrl').addEventListener('change', () => {
  const v = $('#plmUrl').value.trim();
  try {
    const u = new URL(v); const us = u.searchParams.get('username'), pw = u.searchParams.get('password');
    if (us && pw && /get\.php/i.test(u.pathname)) { plmSetType('xtream'); $('#plmServer').value = u.origin; $('#plmUser').value = us; $('#plmPass').value = pw; toast('Lien Xtream détecté : identifiants remplis automatiquement'); }
  } catch { }
});
$('#plmSave').onclick = async () => {
  const err = m => { $('#plmErr').textContent = m; $('#plmErr').hidden = false; };
  const p = plmEdit || { id: uid() };
  p.type = plmType; p.name = $('#plmName').value.trim() || (plmType === 'xtream' ? 'Mon abonnement' : 'Ma playlist'); p.epg = $('#plmEpg').value.trim();
  if (plmType === 'xtream') {
    p.server = $('#plmServer').value.trim(); p.user = $('#plmUser').value.trim(); p.pass = $('#plmPass').value.trim();
    if (!p.server || !p.user || !p.pass) return err('Remplis le serveur, l\'utilisateur et le mot de passe.');
  } else if (plmType === 'm3u') {
    p.url = $('#plmUrl').value.trim(); if (!/^https?:\/\//i.test(p.url)) return err('Le lien doit commencer par http:// ou https://');
  } else {
    const f = $('#plmFile').files[0]; if (!f && !plmEdit) return err('Choisis un fichier .m3u');
    if (f) { $('#plmSave').disabled = true; try { const r = await fetch(`api/playlist/${p.id}/file`, { method: 'POST', body: f }); if (!r.ok) throw 0; } catch { $('#plmSave').disabled = false; return err('Envoi du fichier impossible'); } $('#plmSave').disabled = false; }
  }
  if (!plmEdit) S.playlists.push(p);
  S.activePid = p.id; save(); await saveNow();
  closeModals();
  const ok = await loadPlaylist(true);
  if (!ok) openPlaylistForm(p), err(lastLoadError || 'Chargement impossible');
};

/* ------------------------------------------------------------ chargement */
let lastLoadError = '';
let progT = 0;
function loading(on, txt, pid) {
  $('#listLoading').hidden = true;
  const bl = $('#bigLoad'); bl.hidden = !on;
  if (txt) $('#blTxt').textContent = txt;
  clearInterval(progT);
  if (!on) return;
  $('#blSub').textContent = '';
  if (!pid) return;
  const t0 = Date.now();
  progT = setInterval(async () => {
    try {
      const j = await (await fetch(`api/progress/${pid}`, { cache: 'no-store' })).json();
      if (j.step) $('#blTxt').textContent = j.step + '…';
      const s = Math.round((Date.now() - t0) / 1000);
      $('#blSub').textContent = (j.bytes ? (j.bytes < 1048576 ? Math.max(1, Math.round(j.bytes / 1024)) + ' Ko' : (j.bytes / 1048576).toFixed(1).replace('.', ',') + ' Mo') + ' reçus · ' : '') + s + ' s' + (s > 20 ? ' — les grosses playlists peuvent prendre 1 à 2 minutes' : '');
    } catch { }
  }, 600);
}
async function loadPlaylist(refresh) {
  const p = activePl();
  if (!p) { CH = []; ingest({ chs: [] }); renderKinds(); renderSide(); openView(); return false; }
  S.activePid = p.id;
  loading(true, refresh ? 'Connexion à ton fournisseur…' : 'Chargement de ta playlist…', p.id);
  try {
    const r = await fetch(`api/playlist/${p.id}` + (refresh ? '?refresh=1' : ''));
    if (!r.ok) { let m = 'Erreur ' + r.status; try { m = (await r.json()).error || m; } catch { } throw new Error(m); }
    if (r.headers.get('X-Stale') === '1') toast('Mise à jour impossible (' + decodeURIComponent(r.headers.get('X-Error') || '') + ') : ancienne version de la playlist utilisée', true);
    const txt = await r.text();
    clearInterval(progT); loading(true, `Analyse de ${(txt.length / 1048576).toFixed(1).replace('.', ',')} Mo…`);
    const res = await parseInWorker(txt);
    if (!res.chs.length) throw new Error("La playlist ne contient aucune chaîne. Début reçu : « " + txt.slice(0, 120).replace(/\s+/g, ' ') + ' »');
    ingest(res);
    if (PL.ch && !BYKEY.has(PL.ch.key)) { stopEngines(); PL.ch = null; PL.ctx = []; PL.gen++; pstate('idle'); player.classList.remove('vod'); updateBar(); renderNP(); }
    loading(false); lastLoadError = '';
    renderKinds(); renderSide(); openView(); if (UI.layout === 'home') renderHome();
    if (refresh) toast(`${res.chs.length.toLocaleString('fr-FR')} éléments chargés`);
    restoreLast();
    loadEpg();
    return true;
  } catch (e) {
    loading(false); lastLoadError = e.message || String(e);
    renderKinds(); renderSide(); openView(); if (UI.layout === 'home') renderHome();
    return false;
  }
}
function restoreLast() {
  if (PL.ch || !S.last) return;
  const c = BYKEY.get(S.last.key); if (!c) return;
  PL.ch = c; PL.ctx = GROUPS[c.k].get(c.g) || [c];
  refreshMarks(); renderNP(); updateBar();
  $('#pIdle').innerHTML = `<div class="idle-mark">${ic('play')}</div><p>Reprendre <b>${esc(c.n)}</b><br><span>Clique ici ou appuie sur Entrée</span></p>`;
  $('#pIdle').style.cursor = 'pointer';
  $('#pIdle').onclick = () => { $('#pIdle').onclick = null; $('#pIdle').style.cursor = ''; play(c, PL.ctx); };
  PL.resume = true;
}

/* ------------------------------------------------------------ modales */
function closeModals() { $$('.modal').forEach(m => m.hidden = true); }
$$('.modal').forEach(m => {
  m.addEventListener('pointerdown', e => { if (e.target === m) m.hidden = true; });
  m.addEventListener('click', e => { if (e.target.closest('[data-close]')) m.hidden = true; });
});
const anyModal = () => $$('.modal').some(m => !m.hidden);

/* ------------------------------------------------------------ clavier / télécommande */
let zone = 'list', numBuf = '', numT = 0;
function focusZone(z) {
  zone = z;
  if (z === 'side') { const on = $('.s-item.on', side) || $('.s-item', side); on?.focus(); }
  else { document.activeElement?.blur?.(); refreshMarks(); }
}
function typeNumber(d) {
  numBuf = (numBuf + d).slice(0, 4);
  const z = $('#zapnum'); z.hidden = false; z.textContent = numBuf;
  clearTimeout(numT);
  numT = setTimeout(() => {
    z.hidden = true; const n = parseInt(numBuf, 10); numBuf = '';
    const L = isFull() && PL.ctx.length ? PL.ctx : view.items;
    const c = L[n - 1]; if (!c) return toast(`Pas de n°${n} dans cette liste`);
    play(c, L); if (L === view.items) setCursor(n - 1, true);
  }, 1100);
}
document.addEventListener('keydown', e => {
  const k = e.key, code = e.keyCode, tag = (e.target.tagName || '').toLowerCase();
  const typing = tag === 'input' || tag === 'textarea' || e.target.isContentEditable;
  const back = k === 'Escape' || k === 'BrowserBack' || code === 10009 || code === 461 || k === 'GoBack';
  if ((e.ctrlKey || e.metaKey) && k.toLowerCase() === 'k') { e.preventDefault(); return pal.hidden ? openSearch() : closeSearch(); }
  if (!ctx.hidden) {
    if (back) { e.preventDefault(); closeMenu(); }
    else if (k === 'ArrowDown' || k === 'ArrowUp') { e.preventDefault(); const bs = $$('button', ctx); const i = bs.indexOf(document.activeElement); bs[(i + (k === 'ArrowDown' ? 1 : -1) + bs.length) % bs.length]?.focus(); }
    return;
  }
  if (anyModal()) { if (back && pal.hidden && !typing) { e.preventDefault(); closeModals(); } else if (k === 'Escape' && pal.hidden) { closeModals(); } return; }
  if (typing) {
    if (k === 'Escape') { e.target.blur(); if (e.target.id === 'filter' && view.filter) { view.filter = ''; e.target.value = ''; applyFilter(); } }
    if (e.target.id === 'filter' && (k === 'ArrowDown' || k === 'Enter')) { e.preventDefault(); e.target.blur(); zone = 'list'; if (k === 'Enter' && view.items[0]) play(view.items[view.cursor] || view.items[0], view.items); else setCursor(view.cursor); }
    return;
  }
  if (e.altKey || (e.ctrlKey && !['ArrowUp', 'ArrowDown'].includes(k))) return;
  const full = isFull();
  // zapping
  if (k === 'ChannelUp' || k === 'MediaTrackNext' || (e.ctrlKey && k === 'ArrowDown') || (full && k === 'ArrowDown')) { e.preventDefault(); return zap(1); }
  if (k === 'ChannelDown' || k === 'MediaTrackPrevious' || (e.ctrlKey && k === 'ArrowUp') || (full && k === 'ArrowUp')) { e.preventDefault(); return zap(-1); }
  if (/^[0-9]$/.test(k)) { e.preventDefault(); return typeNumber(k); }
  if (k === ' ' || k === 'MediaPlayPause') { e.preventDefault(); if (PL.ch) video.paused ? tryPlay() : video.pause(); return; }
  if (back) { if (realFull()) { e.preventDefault(); toggleFull(); } else if (app.classList.contains('watch')) { e.preventDefault(); exitWatch(); } else if (zone === 'side') { e.preventDefault(); focusZone('list'); } else if (app.classList.contains('drawer')) closeDrawer(); return; }
  if (k === 'Backspace') { e.preventDefault(); if (realFull()) return toggleFull(); if (app.classList.contains('watch')) return exitWatch(); if (lastPlayed) { const c = resolve(lastPlayed); play(c, c.missing ? [c] : GROUPS[c.k].get(c.g)); } return; }
  if ((full || e.shiftKey) && (k === 'ArrowLeft' || k === 'ArrowRight') && isLiveEngine()) { e.preventDefault(); return tsSeek(video.currentTime + (k === 'ArrowLeft' ? -10 : 10)); }
  if (full) { if (k.toLowerCase() === 'l' && isLiveEngine()) return goLive(); if (k.toLowerCase() === 'f') { if (realFull() || !app.classList.contains('watch')) toggleFull(); else player.requestFullscreen?.().catch(() => { }); } else if (k.toLowerCase() === 'm') video.muted = !video.muted; else if (k.toLowerCase() === 'r' && typeof recMenu === 'function') { const r = $('#pbRec').getBoundingClientRect(); pokeUI(); recMenu(r.left, r.top - 268); } else if (k === 'Enter') showOSD(); return; }
  if (UI.layout === 'home' && homeKey(e, k)) return;
  if (zone === 'side' && document.activeElement && side.contains(document.activeElement)) {
    const items = $$('[data-nav]', side), i = items.indexOf(document.activeElement);
    if (k === 'ArrowDown' || k === 'ArrowUp') { e.preventDefault(); items[clamp(i + (k === 'ArrowDown' ? 1 : -1), 0, items.length - 1)]?.focus(); return; }
    if (k === 'ArrowRight') { e.preventDefault(); focusZone('list'); return; }
    if (k === 'Enter') return; // le bouton gère
  }
  if (k === 'ArrowDown') { e.preventDefault(); zone = 'list'; return setCursor(view.cursor + 1); }
  if (k === 'ArrowUp') { e.preventDefault(); zone = 'list'; return setCursor(view.cursor - 1); }
  if (k === 'PageDown') { e.preventDefault(); return setCursor(view.cursor + Math.floor(listBody.clientHeight / rowH())); }
  if (k === 'PageUp') { e.preventDefault(); return setCursor(view.cursor - Math.floor(listBody.clientHeight / rowH())); }
  if (k === 'Home') { e.preventDefault(); return setCursor(0); }
  if (k === 'End') { e.preventDefault(); return setCursor(view.items.length - 1); }
  if (k === 'ArrowLeft') { e.preventDefault(); if (innerWidth <= 1040) openDrawer(); return focusZone('side'); }
  if (k === 'ArrowRight') { e.preventDefault(); return; }
  if (k === 'Enter') {
    e.preventDefault();
    if (PL.resume && !video.getAttribute('src') && PL.ch && !PL.hls && !PL.mts) { PL.resume = false; return play(PL.ch, PL.ctx); }
    const c = view.items[view.cursor]; if (!c) return;
    if (PL.ch && PL.ch.key === c.key && (PL.hls || PL.mts || video.getAttribute('src'))) return toggleFull();
    return play(c, view.items);
  }
  if (k === '*' || k === 'F2') { const c = view.items[view.cursor] || PL.ch; if (c) toggleFav(c); return; }
  // n'importe quelle lettre → recherche directe
  if (k.length === 1 && /[\p{L}+&]/u.test(k) && !e.ctrlKey && !e.metaKey) { e.preventDefault(); openSearch(k); }
});

/* ------------------------------------------------------------ synchro entre appareils */
async function pullRemote(force) {
  if (saveTimer && !force) return;
  let r = await fetchState(force ? 0 : S.ts); if (!r || !r.v || !(force || r.ts > S.ts)) return;
  r = keepDevice(r, S.settings);
  const pidChanged = r.activePid !== S.activePid || JSON.stringify(r.playlists) !== JSON.stringify(S.playlists);
  S = hydrate(r); rebuildFavSet(); local.set('state', S); applySettings();
  if (pidChanged) loadPlaylist(); else { for (const l of S.lists) for (const it of l.items) { const c = BYKEY.get(it.key); if (c) Object.assign(it, snap(c)); } renderSide(); openView(true); renderNP(); }
}
document.addEventListener('visibilitychange', () => { if (!document.hidden) setTimeout(() => pullRemote(), 1500); });
window.addEventListener('focus', () => pullRemote());
setInterval(() => { if (!document.hidden) pullRemote(); }, 30000); // changements venus du compte en ligne
window.addEventListener('pagehide', () => { if (saveTimer) { try { fetch('api/state', { method: 'PUT', body: JSON.stringify(S), keepalive: true, headers: { 'content-type': 'application/json' } }); } catch { } } });

/* ------------------------------------------------------------ démarrage */
(async function boot() {
  renderTop();
  const remote = await fetchState();
  const loc = local.get('state', null);
  S = hydrate(remote && (!loc || (remote.ts || 0) >= (loc.ts || 0)) ? remote : (loc || remote));
  if (!remote && loc) saveNow();
  if (!S.activePid && S.playlists[0]) S.activePid = S.playlists[0].id;
  if (!S.settings.m1) { S.settings.m1 = 1; if (S.settings.accent === '#ff5a36') S.settings.accent = '#e50914'; save(); }
  // boîtier Android TV : mode télécommande activé d'office la 1re fois
  // une seule fois : le format du flux a pu être remplacé par celui d'un autre appareil (compte en ligne) → retour à « Auto » sur le PC
  if (IS_APP && !window.VK_DIRECT && !local.get('devfix1', 0)) { local.set('devfix1', 1); if (S.settings.format && S.settings.format !== 'auto') { S.settings.format = 'auto'; save(); } }
  if (!S.settings.tvAuto) { S.settings.tvAuto = 1; try { if (window.Android && Android.isTv()) S.settings.tv = true; } catch { } save(); }
  rebuildFavSet(); applySettings(); applyLayout();
  video.volume = UI.vol; video.muted = UI.muted;
  updateBar(); renderNP(); renderSide(); openView();
  if (!S.playlists.length) { openPlaylistForm(); return; }
  await loadPlaylist(false);
})();

/* =====================================================================
   Télécommande : bouton Retour (Android) et déplacement aux flèches dans les fenêtres
   ===================================================================== */
window.vkBack = function () {
  const esc = () => document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
  if (!ctx.hidden) { closeMenu(); return true; }
  if (typeof MV !== 'undefined' && MV.open) { if (MV.panel) mvPanel(false); else mvClose(); return true; }
  if (anyModal()) { closeModals(); return true; }
  if (player.classList.contains('fs') || document.fullscreenElement) { toggleFull(); return true; }
  if (app.classList.contains('watch')) { exitWatch(); return true; }
  if (app.classList.contains('drawer')) { closeDrawer(); return true; }
  if (document.activeElement && /input|textarea/i.test(document.activeElement.tagName)) { document.activeElement.blur(); return true; }
  if (UI.layout === 'home' && UI.page === 'fav') { UI.page = 'home'; saveUI(); renderKinds(); renderHome(); return true; }
  if (UI.layout === 'list' && UI.sel.t !== 'all') { UI.sel = { t: 'all' }; saveUI(); renderSide(); openView(); return true; }
  if (UI.layout === 'home' && app.scrollTop > 200) { app.scrollTo({ top: 0, behavior: 'smooth' }); $('#heroPlay')?.focus({ preventScroll: true }); return true; }
  if (window.Android && Android.exit) { if (PL.ch) { stopEngines(); } Android.exit(); }
  return false;
};
window.vkPause = function () { try { video.pause(); if (typeof MV !== 'undefined' && MV.open) mvClose(false); } catch { } };

// déplacement « spatial » : la flèche va vers l'élément le plus proche dans la direction choisie
function spatialMove(dir, root) {
  const els = [...root.querySelectorAll('button, a[href], input, select, textarea, [tabindex="0"]')].filter(el => !el.disabled && el.offsetParent !== null && !el.closest('[hidden]'));
  if (!els.length) return false;
  const cur = document.activeElement && root.contains(document.activeElement) ? document.activeElement : null;
  if (!cur) { els[0].focus(); return true; }
  const r = cur.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2;
  let best = null, bd = Infinity;
  for (const el of els) {
    if (el === cur) continue;
    const b = el.getBoundingClientRect(), x = b.left + b.width / 2, y = b.top + b.height / 2, dx = x - cx, dy = y - cy;
    const ok = dir === 'ArrowDown' ? dy > 4 : dir === 'ArrowUp' ? dy < -4 : dir === 'ArrowRight' ? dx > 4 : dx < -4;
    if (!ok) continue;
    const main = dir === 'ArrowDown' || dir === 'ArrowUp' ? Math.abs(dy) : Math.abs(dx), side = dir === 'ArrowDown' || dir === 'ArrowUp' ? Math.abs(dx) : Math.abs(dy);
    const d = main + side * 2.2;
    if (d < bd) { bd = d; best = el; }
  }
  if (best) { best.focus(); best.scrollIntoView({ block: 'nearest', inline: 'nearest' }); return true; }
  return false;
}
document.addEventListener('keydown', e => {
  if (!['ArrowDown', 'ArrowUp', 'ArrowLeft', 'ArrowRight'].includes(e.key) || e.ctrlKey || e.altKey) return;
  const t = document.activeElement;
  // dans un champ de texte, gauche/droite déplacent le curseur
  if (t && /input|textarea/i.test(t.tagName) && t.type !== 'checkbox' && (e.key === 'ArrowLeft' || e.key === 'ArrowRight')) return;
  if (t && t.tagName === 'SELECT') return;
  const root = !ctx.hidden ? null : anyModal() ? $$('.modal').find(m => !m.hidden) : null;
  if (!root || root.id === 'pal') return;
  if (spatialMove(e.key, root)) { e.preventDefault(); e.stopImmediatePropagation(); }
}, true);

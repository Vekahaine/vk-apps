'use strict';
/* VkTV — mises à jour automatiques : bandeau « nouvelle version prête » + ligne dans les paramètres */
const UPD = { on: IS_APP && !window.VK_DIRECT, st: {}, hidden: false };
async function updLoad(force) {
  if (!UPD.on) return;
  try { UPD.st = await (await fetch(force ? 'api/update/check' : 'api/update', { method: force ? 'POST' : 'GET', cache: 'no-store' })).json(); } catch { return; }
  const b = $('#upd'), s = UPD.st;
  if (s.current) $('#appVer').textContent = 'v' + s.current;
  b.hidden = UPD.hidden || s.status !== 'ready';
  if (!b.hidden) b.innerHTML = `${ic('refresh')}<span><b>VkTV ${esc(s.version)}</b> est prête${s.notes ? ' · ' + esc(s.notes) : ''}</span><button class="btn sm" id="updGo">Redémarrer maintenant</button><button class="ibtn" id="updLater" title="Plus tard (elle s'installera au prochain lancement)">${ic('x')}</button>`;
  const g = $('#updGo'); if (g) g.onclick = updApply;
  const l = $('#updLater'); if (l) l.onclick = () => { UPD.hidden = true; b.hidden = true; toast('La mise à jour s\'installera au prochain lancement de VkTV'); };
  fillUpdate();
}
async function updApply() {
  const r = await (await fetch('api/update/apply', { method: 'POST' })).json().catch(() => ({}));
  if (r.error) return toast(r.error, true);
  if (!r.ok) return toast('Ferme VkTV puis rouvre-le depuis le raccourci du Bureau : la mise à jour s\'installera à l\'ouverture', true);
  document.body.insertAdjacentHTML('beforeend', '<div style="position:fixed;inset:0;z-index:2000;display:grid;place-content:center;color:#aaa;font:16px system-ui;background:#0a0a0a">Mise à jour de VkTV… elle va se rouvrir toute seule.</div>');
}
function fillUpdate(msg) {
  const box = $('#updBox'); if (!box) return;
  const s = UPD.st || {};
  const cur = window.VK_DIRECT ? (window.VK_APK && VK_APK.version) : s.current;
  const txt = msg || ({ uptodate: '✓ Tu as la dernière version', checking: 'Recherche…', downloading: `Téléchargement de la ${esc(s.version || '')} : ${Math.round((s.progress || 0) * 100)} %`, ready: `La version ${esc(s.version)} est prête à être installée`, error: `Dernière vérification impossible (${esc(s.error || '')})`, manual: `La version ${esc(s.version || '')} demande un nouveau fichier d'installation : demande-le à Claude` }[s.status] || 'Les mises à jour se font automatiquement');
  box.innerHTML = `<div class="cl-row"><div class="grow"><b>VkTV ${esc(cur || '')}</b><small id="updTxt">${txt}</small></div><button class="btn sm" id="updNow">${ic('refresh')}Mettre à jour</button></div>`;
  $('#updNow').onclick = updateNow;
}
// bouton « Mettre à jour » : vérifie, télécharge et installe d'un coup
async function updateNow() {
  const b = $('#updNow'), say = t => { const e = $('#updTxt'); if (e) e.innerHTML = t; };
  if (b) { b.disabled = true; b.innerHTML = '<span class="spin" style="width:14px;height:14px;border-width:2px"></span>Recherche…'; }
  if (window.VK_DIRECT) return androidUpdate(true).finally(() => { if (b) { b.disabled = false; b.innerHTML = `${ic('refresh')}Mettre à jour`; } });
  say('Recherche d\'une nouvelle version…');
  try { UPD.st = await (await fetch('api/update/check', { method: 'POST', cache: 'no-store' })).json(); } catch { UPD.st = { status: 'error', error: 'VkTV ne répond pas' }; }
  const s = UPD.st;
  if (s.status === 'ready') { say(`Installation de la version ${esc(s.version)}… VkTV va se rouvrir tout seul.`); return updApply(); }
  if (s.status === 'off') { say('Les mises à jour automatiques marchent sur l\'appli PC installée'); }
  fillUpdate();
}
if (UPD.on) { updLoad(); setTimeout(updLoad, 25000); setInterval(updLoad, 60e3); }
else if (window.VK_APK) { try { $('#appVer').textContent = 'v' + window.VK_APK.version; } catch { } }
$('#appVer').onclick = e => { e.stopPropagation(); openSettings(); setTimeout(() => $('#updBox') && $('#updBox').scrollIntoView({ block: 'center' }), 60); };
$('#appVer').title = 'Version : clique pour mettre à jour';

/* Android : l'interface se met à jour toute seule (comme sur PC, sans APK) ; l'APK seulement quand l'appli elle-même change */
const verCmp = (a, b) => { const x = String(a || '0').split('.').map(n => parseInt(n) || 0), y = String(b || '0').split('.').map(n => parseInt(n) || 0); for (let i = 0; i < Math.max(x.length, y.length); i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) < (y[i] || 0) ? -1 : 1; } return 0; };
async function webUpdate(w, manual) {
  const say = t => { if (manual) fillUpdate(t); };
  Android.webUpdate(new URL(w.zip, 'https://raw.githubusercontent.com/Vekahaine/vk-apps/main/').href, w.sha256 || '', w.version);
  say(`Téléchargement de la ${esc(w.version)}…`);
  for (let i = 0; i < 600; i++) {
    await new Promise(r => setTimeout(r, 500));
    let s = {}; try { s = JSON.parse(Android.webUpdateState()); } catch { }
    if (s.state === 'done') {
      // en train de regarder : on n'interrompt pas, la nouvelle version s'ouvrira au prochain lancement
      if (!manual && PL.ch && !video.paused) { toast(`VkTV ${w.version} est prête : elle s'ouvrira au prochain lancement`); return; }
      document.body.insertAdjacentHTML('beforeend', '<div style="position:fixed;inset:0;z-index:2000;display:grid;place-content:center;color:#aaa;font:16px system-ui;background:#0a0a0a">Mise à jour de VkTV…</div>');
      setTimeout(() => Android.webReload(), 400); return;
    }
    if (s.state === 'error') { say(`Mise à jour impossible : ${esc(s.error || '')}`); return; }
    if (manual) say(`Téléchargement de la ${esc(w.version)} : ${Math.round((s.p || 0) * 100)} %`);
  }
}
async function androidUpdate(manual) {
  let a, j;
  try { j = await (await fetch('https://raw.githubusercontent.com/Vekahaine/vk-apps/main/latest.json?t=' + Date.now(), { cache: 'no-store' })).json(); a = j.android; }
  catch { if (manual) fillUpdate('Pas de connexion au serveur de mises à jour'); return; }
  const w = j.android_www;
  if (w && window.Android && Android.webUpdate && (!w.minApk || window.VK_APK.code >= w.minApk) && verCmp(w.version, Android.webVersion()) > 0) return webUpdate(w, manual);
  if (!a || !(a.code > window.VK_APK.code)) { if (manual) fillUpdate('✓ Tu as la dernière version' + (window.Android && Android.webVersion ? ` (interface ${esc(Android.webVersion())})` : '')); return; }
  const url = new URL(a.apk, 'https://raw.githubusercontent.com/Vekahaine/vk-apps/main/').href;
  const install = () => {
    const ok = window.Android && Android.openUrl && Android.openUrl(url);
    const msg = ok ? `Téléchargement de la ${esc(a.version)} : ouvre le fichier <b>VkTV.apk</b> puis appuie sur <b>Installer</b> (tes réglages sont gardés).` : `Ouvre ce lien dans un navigateur de cet appareil : <b>github.com/Vekahaine/vk-apps</b> (dossier android)`;
    fillUpdate(msg); const b = $('#upd'); b.innerHTML = `<span>${msg}</span><button class="ibtn" id="updLater">${ic('x')}</button>`; b.hidden = false; $('#updLater').onclick = () => { b.hidden = true; };
  };
  if (manual) return install();
  const b = $('#upd');
  b.innerHTML = `${ic('refresh')}<span><b>VkTV ${esc(a.version)}</b> est disponible${a.notes ? ' · ' + esc(a.notes) : ''}</span><button class="btn sm" id="updGo">Installer</button><button class="ibtn" id="updLater">${ic('x')}</button>`;
  b.hidden = false;
  $('#updLater').onclick = () => { b.hidden = true; };
  $('#updGo').onclick = install;
}
if (window.VK_DIRECT && window.VK_APK) setTimeout(() => androidUpdate(false), 6000);

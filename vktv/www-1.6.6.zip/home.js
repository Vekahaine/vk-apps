/* =====================================================================
   VkTV — vue Accueil façon Netflix (bannière + rangées + lecture immersive)
   ===================================================================== */
const homeEl = $('#home');
let ROWS = [], rowsShown = 0, homeIO = null;
const CHUNK = 24;
if (!UI.layout) UI.layout = 'home';
if (!UI.page) UI.page = 'home';

function applyLayout() {
  const home = UI.layout === 'home';
  app.classList.toggle('home', home);
  if (!home) exitWatch(true);
  $('#btnLayout').innerHTML = ic(home ? 'list' : 'grid');
  $('#btnLayout').title = home ? 'Vue liste (classique)' : 'Vue accueil';
  renderKinds();
  if (home) renderHome(); else { openView(true); renderNP(); }
}
$('#btnLayout').onclick = () => { UI.layout = UI.layout === 'home' ? 'list' : 'home'; saveUI(); applyLayout(); };
app.addEventListener('scroll', () => { if (UI.layout === 'home') $('.top').classList.toggle('solid', app.scrollTop > 30); }, { passive: true });

/* ---------- rangées */
function kindFilter(arr) { return arr.map(resolve).filter(c => c.k === UI.kind); }
function buildRows() {
  if (UI.page === 'fav') return favRows();
  const rows = [], kind = UI.kind;
  const rec = kindFilter(S.recents);
  if (rec.length) rows.push({ id: 'recents', title: 'Reprendre', items: rec, sel: { t: 'recents' }, kind: 'mixed' });
  for (const l of S.lists) {
    const it = kindFilter(l.items);
    if (it.length) rows.push({ id: 'list:' + l.id, title: l.name, items: it, sel: { t: 'list', id: l.id }, kind: 'mixed' });
  }
  for (const g of orderedGroups(kind, false)) rows.push({ id: 'cat:' + g, title: catLabel(kind, g), items: GROUPS[kind].get(g), sel: { t: 'cat', id: g }, kind, cat: { k: kind, g } });
  return rows;
}
// page ★ Favoris : chaînes favorites + listes perso + catégories favorites
function favRows() {
  const rows = [];
  for (const l of S.lists) {
    const it = l.items.map(resolve);
    if (it.length) rows.push({ id: 'list:' + l.id, title: l.name, items: it, sel: { t: 'list', id: l.id }, kind: 'mixed' });
  }
  const fcs = validFavCats();
  fcs.forEach((f, i) => rows.push({ id: 'fcat:' + f.k + ':' + f.g, title: catLabel(f.k, f.g), items: GROUPS[f.k].get(f.g), sel: { t: 'cat', id: f.g }, kind: f.k, cat: f, fi: i, fn: fcs.length }));
  return rows;
}
function renderHome() {
  if (UI.layout !== 'home') return;
  ROWS = buildRows(); rowsShown = 0;
  homeEl.innerHTML = '';
  if (homeIO) homeIO.disconnect();
  app.classList.toggle('nochan', !CH.length);
  if (!CH.length) {
    const pl = activePl();
    homeEl.innerHTML = pl && lastLoadError
      ? `<div class="home-empty bad"><h2>Impossible de charger « ${esc(pl.name)} »</h2><p class="why">${esc(lastLoadError)}</p><div class="he-acts"><button class="btn big" id="heRetry">${ic('refresh')}Réessayer</button><button class="btn big ghost" id="heEdit">${ic('edit')}Modifier la playlist</button></div><p class="hint">Astuce : vérifie l'adresse du serveur (avec le port, ex : http://exemple.com:8080), ton identifiant et ton mot de passe. Si ton fournisseur t'a donné un lien « get.php?username=… », colle-le dans « Lien M3U / flux ».</p></div>`
      : `<div class="home-empty"><h2>Bienvenue sur VkTV</h2><p>Ajoute ton abonnement IPTV pour remplir ton accueil.</p><button class="btn big" onclick="openPlaylistForm()">${ic('plus')}Ajouter ma playlist</button></div>`;
    const r = $('#heRetry'); if (r) { r.onclick = () => loadPlaylist(true); $('#heEdit').onclick = () => openPlaylistForm(pl); }
    renderHero(); return;
  }
  if (UI.page === 'fav' && !ROWS.length) {
    homeEl.innerHTML = `<div class="home-empty"><h2>Tes favoris sont vides</h2><p>Deux types de favoris :<br>★ sur une <b>chaîne</b> → elle arrive dans « Chaînes favorites »<br>★ à côté du titre d'une <b>catégorie</b> → toute la catégorie arrive ici</p><button class="btn big" id="heBack">${ic('tv')}Parcourir les chaînes</button></div>`;
    $('#heBack').onclick = () => { UI.page = 'home'; saveUI(); renderKinds(); renderHome(); };
    renderHero(); return;
  }
  const sent = document.createElement('div'); sent.className = 'home-sentinel'; homeEl.appendChild(sent);
  homeIO = new IntersectionObserver(es => { if (es.some(e => e.isIntersecting)) moreRows(6); }, { root: app, rootMargin: '900px 0px' });
  homeIO.observe(sent);
  moreRows(7);
  renderHero();
}
function moreRows(n) {
  const sent = $('.home-sentinel', homeEl); const fr = document.createDocumentFragment();
  const end = Math.min(ROWS.length, rowsShown + n);
  for (; rowsShown < end; rowsShown++) fr.appendChild(makeHRow(rowsShown));
  homeEl.insertBefore(fr, sent);
  if (rowsShown >= ROWS.length && homeIO) { homeIO.disconnect(); sent.remove(); }
}
function isPoster(r) { return r.kind === 'movie' || r.kind === 'series'; }
function makeHRow(ri) {
  const r = ROWS[ri], el = document.createElement('div');
  el.className = 'hrow' + (isPoster(r) ? ' posters' : ''); el.dataset.r = ri; el.dataset.id = r.id;
  const fc = r.cat && isFavCat(r.cat.k, r.cat.g);
  const star = r.cat ? `<button class="rstar${fc ? ' on' : ''}" title="${fc ? 'Retirer la catégorie des favoris' : 'Ajouter toute la catégorie aux favoris'}">${ic('star')}<span>${fc ? 'Catégorie favorite' : 'Catégorie en favori'}</span></button>` : '';
  const kindTag = UI.page === 'fav' && r.cat && r.cat.k !== 'live' ? `<span class="rkind">${KINDS.find(k => k.k === r.cat.k).label}</span>` : '';
  const order = r.fi !== undefined && r.fn > 1 ? `<button class="rmove" data-d="-1" title="Monter" ${r.fi === 0 ? 'disabled' : ''}>${ic('up')}</button><button class="rmove" data-d="1" title="Descendre" ${r.fi === r.fn - 1 ? 'disabled' : ''}>${ic('down')}</button>` : '';
  el.innerHTML = `<div class="hrow-h"><h3>${esc(r.title)}</h3>${kindTag}<span class="hc">${r.items.length.toLocaleString('fr-FR')}</span>${star}${order}<button class="seeall">Tout voir ${ic('next')}</button></div>
  <div class="hwrap"><button class="hnav l" tabindex="-1" aria-label="Précédent">${ic('prev')}</button><div class="hscroll"></div><button class="hnav r" tabindex="-1" aria-label="Suivant">${ic('next')}</button></div>`;
  const sc = el.querySelector('.hscroll');
  fillCards(sc, r, 0);
  sc.addEventListener('scroll', () => {
    if (sc.scrollLeft + sc.clientWidth > sc.scrollWidth - 600) fillCards(sc, r, sc.children.length);
    el.classList.toggle('scrolled', sc.scrollLeft > 4);
  }, { passive: true });
  return el;
}
function fillCards(sc, r, from) {
  if (from >= r.items.length) return;
  const to = Math.min(r.items.length, from + CHUNK);
  let h = '';
  for (let i = from; i < to; i++) h += cardHTML(r.items[i], i);
  sc.insertAdjacentHTML('beforeend', h);
}
function cardHTML(c, i) {
  const p = c.k === 'live' ? nowProg(c) : null, fav = isFav(c), hue = hueOf(c.n);
  const name = esc(c.dn || c.n), playing = PL.ch && PL.ch.key === c.key;
  const vis = S.settings.logos && c.l
    ? `<img src="${esc(c.l)}" loading="lazy" decoding="async" referrerpolicy="no-referrer" alt="">`
    : `<span class="cini">${esc(initials(c.n))}</span>`;
  const sub = p ? `<span class="tm">${hm(p[0])}</span> ${esc(p[2])}` : esc(catLabel(c.k, c.g));
  const pc = p ? clamp((Date.now() / 1000 - p[0]) / (p[1] - p[0]) * 100, 0, 100) : 0;
  return `<button class="card${playing ? ' playing' : ''}" data-i="${i}" data-key="${esc(c.key)}" style="--h:${hue}">
    <span class="cv" data-ini="${esc(initials(c.n))}">${vis}</span>
    ${c.q ? `<span class="cq${c.q === '4K' ? ' uhd' : ''}">${c.q}</span>` : ''}
    ${playing ? '<span class="clive">EN COURS</span>' : ''}
    <span class="cfav${fav ? ' on' : ''}" title="Ma liste">${ic('star')}</span>
    <span class="cplay">${ic('play')}</span>
    <span class="cinfo"><b>${name}</b><small>${sub}</small>${p ? `<i class="cprog"><i style="width:${pc.toFixed(1)}%"></i></i>` : ''}</span>
  </button>`;
}
// images cassées des cartes → initiales
document.addEventListener('error', e => {
  const im = e.target; if (im.tagName !== 'IMG') return;
  const cv = im.parentElement; if (!cv || !cv.classList.contains('cv')) return;
  cv.innerHTML = `<span class="cini">${esc(cv.dataset.ini || '')}</span>`;
}, true);

homeEl.addEventListener('click', e => {
  const row = e.target.closest('.hrow');
  if (e.target.closest('.home-empty')) return;
  if (!row) return;
  const r = ROWS[+row.dataset.r];
  if (e.target.closest('.seeall')) { goList(r.sel, r.cat && r.cat.k); return; }
  if (e.target.closest('.rstar')) { toggleFavCat(r.cat.k, r.cat.g); return; }
  const mv = e.target.closest('.rmove'); if (mv) { moveFavCat(r.cat.k, r.cat.g, +mv.dataset.d); return; }
  const nav = e.target.closest('.hnav');
  if (nav) { const sc = row.querySelector('.hscroll'); sc.scrollBy({ left: (nav.classList.contains('l') ? -1 : 1) * sc.clientWidth * 0.85, behavior: 'smooth' }); return; }
  const card = e.target.closest('.card'); if (!card) return;
  const c = r.items[+card.dataset.i];
  if (e.target.closest('.cfav')) { toggleFav(c); return; }
  openCard(c, r.items);
});
homeEl.addEventListener('contextmenu', e => {
  const card = e.target.closest('.card'), row = e.target.closest('.hrow'); if (!card || !row) return;
  e.preventDefault(); chanMenu(ROWS[+row.dataset.r].items[+card.dataset.i], e.clientX, e.clientY);
});
longPress(homeEl, '.card', (card, x, y) => { const row = card.closest('.hrow'); chanMenu(ROWS[+row.dataset.r].items[+card.dataset.i], x, y); });

function openCard(c, ctxList) {
  const active = PL.ch && PL.ch.key === c.key && (PL.hls || PL.mts || video.getAttribute('src'));
  if (!active) play(c, c.missing ? [c] : ctxList);
  enterWatch();
}
function goList(sel, kind) {
  if (kind && kind !== UI.kind) UI.kind = kind;
  UI.layout = 'list'; UI.sel = sel; saveUI(); applyLayout(); renderKinds(); renderSide(); openView();
}
// une catégorie a été ajoutée / retirée des favoris
window.homeFavChanged = function (reorder) {
  if (UI.layout !== 'home') return;
  if (UI.page === 'fav') { const y = app.scrollTop; renderHome(); app.scrollTop = y; return; }
  $$('.hrow', homeEl).forEach(el => {
    const r = ROWS[+el.dataset.r]; if (!r || !r.cat) return;
    const b = el.querySelector('.rstar'), on = isFavCat(r.cat.k, r.cat.g);
    b.classList.toggle('on', on); b.title = on ? 'Retirer la catégorie des favoris' : 'Ajouter toute la catégorie aux favoris';
    b.querySelector('span').textContent = on ? 'Catégorie favorite' : 'Catégorie en favori';
  });
};

// garde l'accueil à jour sans perdre la position de défilement
function homeSync(key) {
  if (UI.layout !== 'home' || !ROWS.length) return;
  if (key) $$(`.card[data-key="${CSS.escape(key)}"] .cfav`, homeEl).forEach(f => f.classList.toggle('on', favSet.has(key)));
  const fresh = buildRows();
  const ids = fresh.filter(r => r.id === 'recents' || r.id.startsWith('list:')).map(r => r.id);
  const old = ROWS.filter(r => r.id === 'recents' || r.id.startsWith('list:')).map(r => r.id);
  if (ids.join('|') !== old.join('|')) { const y = app.scrollTop; renderHome(); app.scrollTop = y; return; }
  for (const id of ids) {
    const ri = ROWS.findIndex(r => r.id === id), el = $(`.hrow[data-r="${ri}"]`, homeEl);
    ROWS[ri] = fresh.find(r => r.id === id);
    if (!el) continue;
    const sc = el.querySelector('.hscroll'), x = sc.scrollLeft;
    sc.innerHTML = ''; fillCards(sc, ROWS[ri], 0); sc.scrollLeft = x;
    el.querySelector('.hc').textContent = ROWS[ri].items.length;
  }
  renderHero();
}
function homeOnPlay() {
  if (UI.layout !== 'home') return;
  $$('.card.playing', homeEl).forEach(c => { c.classList.remove('playing'); c.querySelector('.clive')?.remove(); });
  if (PL.ch) $$(`.card[data-key="${CSS.escape(PL.ch.key)}"]`, homeEl).forEach(c => { c.classList.add('playing'); if (!c.querySelector('.clive')) c.insertAdjacentHTML('afterbegin', '<span class="clive">EN COURS</span>'); });
  clearTimeout(homeOnPlay.t); homeOnPlay.t = setTimeout(() => homeSync(), 1500); // « Reprendre » se met à jour
  renderHero();
  if (app.classList.contains('watch')) renderStrip();
}
function homeRefreshEPG() {
  $$('.hrow', homeEl).forEach(el => {
    const r = ROWS[+el.dataset.r]; if (!r) return;
    $$('.card', el).forEach(card => { const c = r.items[+card.dataset.i]; if (c && c.k === 'live') card.outerHTML = cardHTML(c, +card.dataset.i); });
  });
}
setInterval(() => { if (UI.layout === 'home' && !document.hidden) { homeRefreshEPG(); renderHero(); } }, 60000);

/* ---------- bannière */
function featured() {
  if (UI.page === 'fav') {
    if (PL.ch) return PL.ch;
    if (S.last) { const c = BYKEY.get(S.last.key); if (c) return c; }
    const f = favList().items.map(resolve).find(c => !c.missing); if (f) return f;
    const fc = validFavCats()[0]; if (fc) return GROUPS[fc.k].get(fc.g)[0];
  }
  const k = UI.kind;
  if (PL.ch && PL.ch.k === k) return PL.ch;
  if (S.last) { const c = BYKEY.get(S.last.key); if (c && c.k === k) return c; }
  const r = S.recents.map(resolve).find(c => !c.missing && c.k === k); if (r) return r;
  const f = favList().items.map(resolve).find(c => !c.missing && c.k === k); if (f) return f;
  const g = orderedGroups(UI.kind, false)[0]; return g ? GROUPS[UI.kind].get(g)[0] : null;
}
function renderHero() {
  if (UI.layout !== 'home') return;
  const c = featured(), info = $('#heroInfo'), bg = $('#heroBg');
  if (!c) { info.innerHTML = ''; bg.innerHTML = ''; bg.style.cssText = ''; return; }
  const hue = hueOf(c.n);
  bg.style.cssText = `--h:${hue}`;
  bg.innerHTML = S.settings.logos && c.l ? `<img class="hb-blur" src="${esc(c.l)}" referrerpolicy="no-referrer" alt=""><img class="hb-logo" src="${esc(c.l)}" referrerpolicy="no-referrer" alt="" onerror="this.remove()">` : `<span class="hb-ini">${esc(initials(c.n))}</span>`;
  const p = c.k === 'live' ? nowProg(c) : null, nx = p ? (progs(c) || []).find(x => x[0] >= p[1]) : null;
  const active = PL.ch && PL.ch.key === c.key && (PL.hls || PL.mts || video.getAttribute('src'));
  const fav = isFav(c);
  const pc = p ? clamp((Date.now() / 1000 - p[0]) / (p[1] - p[0]) * 100, 0, 100) : 0;
  info.innerHTML = `
    <div class="hi-kick">${c.k === 'live' ? '<span class="hi-live">DIRECT</span>' : ''}<span>${esc(catLabel(c.k, c.g))}</span>${c.q ? `<span class="hi-q">${c.q}</span>` : ''}</div>
    <h1>${esc(c.dn || c.n)}</h1>
    ${p ? `<div class="hi-now"><b>${esc(p[2])}</b><span>${hm(p[0])} – ${hm(p[1])}</span><i class="cprog"><i style="width:${pc.toFixed(1)}%"></i></i></div>${p[3] ? `<p class="hi-desc">${esc(p[3])}</p>` : ''}${nx ? `<div class="hi-next">Ensuite · ${hm(nx[0])} ${esc(nx[2])}</div>` : ''}` : `<p class="hi-desc">${active ? 'En cours de lecture.' : PL.resume || (S.last && S.last.key === c.key) ? 'Ta dernière chaîne regardée.' : 'Lance une chaîne ou tape son nom pour la trouver.'}</p>`}
    <div class="hi-acts">
      <button class="hbtn play" id="heroPlay">${ic('play')}${active ? 'Plein écran' : 'Regarder'}</button>
      <button class="hbtn" id="heroFav">${ic(fav ? 'check' : 'star')}${fav ? 'En favori' : 'Favori'}</button>
      <button class="hbtn" id="heroCat">${ic('folder')}Catégorie</button>
      ${active && c.k === 'live' && typeof REC !== 'undefined' && REC.on ? `<button class="hbtn herorec" id="heroRec">${ic('rec')}Enregistrer</button>` : ''}
    </div>`;
  $('#heroPlay').onclick = () => openCard(c, c.missing ? [c] : (GROUPS[c.k].get(c.g) || [c]));
  $('#heroFav').onclick = () => toggleFav(c);
  $('#heroCat').onclick = () => goList({ t: 'cat', id: c.g }, c.k);
  const hr = $('#heroRec'); if (hr) { hr.onclick = () => { const r = hr.getBoundingClientRect(); recMenu(r.left, r.bottom + 6); }; recPaint(); }
}

/* ---------- lecture immersive */
let watchPushed = false;
function enterWatch() {
  if (UI.layout !== 'home' || !PL.ch) return;
  if (!app.classList.contains('watch')) {
    app.classList.add('watch');
    try { history.pushState({ watch: 1 }, ''); watchPushed = true; } catch { }
  }
  renderStrip(); pokeUI(); showOSD(); updateBar();
  player.focus({ preventScroll: true });
}
function exitWatch(silent) {
  if (!app.classList.contains('watch')) return;
  if (document.fullscreenElement) document.exitFullscreen().catch(() => { });
  app.classList.remove('watch'); player.classList.remove('hidecur');
  if (watchPushed && !silent) { watchPushed = false; try { history.back(); } catch { } } else watchPushed = false;
  updateBar(); renderHero();
  if (!silent) setTimeout(() => ($(`.card.playing`, homeEl) || $('#heroPlay'))?.focus({ preventScroll: true }), 50);
}
window.addEventListener('popstate', () => { if (app.classList.contains('watch')) { watchPushed = false; exitWatch(true); renderHero(); } });
$('#pbBack').onclick = () => exitWatch();

function renderStrip() {
  const st = $('#strip'); if (!PL.ch) { st.innerHTML = ''; return; }
  const L = PL.ctx && PL.ctx.length ? PL.ctx : [PL.ch];
  const ci = Math.max(0, L.findIndex(c => c.key === PL.ch.key));
  const a = Math.max(0, ci - 20), b = Math.min(L.length, ci + 40);
  let h = '';
  for (let i = a; i < b; i++) h += cardHTML(L[i], i);
  st.innerHTML = `<div class="strip-h">${esc(catLabel(PL.ch.k, PL.ch.g))} · ${ci + 1}/${L.length} <span>↑ ↓ zapper · ← → reculer / avancer de 10 s · L direct</span></div><div class="hscroll">${h}</div>`;
  const cur = st.querySelector('.card.playing');
  if (cur) { const sc = st.querySelector('.hscroll'); sc.scrollLeft = cur.offsetLeft - sc.clientWidth / 2 + cur.offsetWidth / 2; }
}
$('#strip').addEventListener('click', e => {
  e.stopPropagation();
  const card = e.target.closest('.card'); if (!card) return;
  const L = PL.ctx && PL.ctx.length ? PL.ctx : [PL.ch], c = L[+card.dataset.i];
  if (e.target.closest('.cfav')) return toggleFav(c);
  if (c && c.key !== PL.ch.key) play(c);
});

/* ---------- clavier / télécommande sur l'accueil */
function homeKey(e, k) {
  if (app.classList.contains('watch')) return false;
  const a = document.activeElement;
  const card = a && a.closest ? a.closest('#home .card') : null;
  const heroBtn = a && a.closest ? a.closest('.hi-acts .hbtn') : null;
  if (k === 'Enter' && (card || heroBtn)) { e.preventDefault(); a.click(); return true; }
  if (!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(k)) return false;
  e.preventDefault();
  const focus = el => { if (!el) return; el.focus({ preventScroll: true }); el.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'smooth' }); };
  if (heroBtn) {
    const bs = $$('.hi-acts .hbtn'), i = bs.indexOf(heroBtn);
    if (k === 'ArrowLeft') focus(bs[i - 1]); else if (k === 'ArrowRight') focus(bs[i + 1]);
    else if (k === 'ArrowDown') { const f = $('#home .hrow .card'); if (f) { f.focus({ preventScroll: true }); f.closest('.hrow').scrollIntoView({ block: 'center', behavior: 'smooth' }); } }
    return true;
  }
  if (!card) { const t = $('#heroPlay') || $('#home .card'); t?.focus({ preventScroll: true }); app.scrollTo({ top: 0, behavior: 'smooth' }); return true; }
  const row = card.closest('.hrow'), sc = row.querySelector('.hscroll');
  if (k === 'ArrowRight') {
    let n = card.nextElementSibling;
    if (!n) { fillCards(sc, ROWS[+row.dataset.r], sc.children.length); n = card.nextElementSibling; }
    focus(n); return true;
  }
  if (k === 'ArrowLeft') { focus(card.previousElementSibling); return true; }
  let target = k === 'ArrowDown' ? row.nextElementSibling : row.previousElementSibling;
  if (k === 'ArrowDown' && (!target || !target.classList.contains('hrow'))) { moreRows(4); target = row.nextElementSibling; }
  if (!target || !target.classList.contains('hrow')) {
    if (k === 'ArrowUp') { $('#heroPlay')?.focus({ preventScroll: true }); app.scrollTo({ top: 0, behavior: 'smooth' }); }
    return true;
  }
  const x = card.getBoundingClientRect().left;
  let best = null, bd = 1e9;
  for (const c of target.querySelectorAll('.card')) { const d = Math.abs(c.getBoundingClientRect().left - x); if (d < bd) { bd = d; best = c; } }
  if (best) { best.focus({ preventScroll: true }); target.scrollIntoView({ block: 'center', behavior: 'smooth' }); best.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'smooth' }); }
  return true;
}

'use strict';
/* =====================================================================
   VDIZI — tes séries, tes playlists, tes sous-titres
   ===================================================================== */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const uid = () => Math.random().toString(36).slice(2, 10);
const norm = s => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, ' ').trim();
const K = new URLSearchParams(location.search).get('k') || '';
const VK = window.vk || null;   // fonctions de l'appli (choix de dossiers…), absentes dans un simple navigateur
// spectateur (visiteur ou compte) : regarder seulement, aucun outil d'administration ne doit apparaître
// version affichée pour TOUT LE MONDE (à côté du logo et en bas des Réglages)
// PC : version installée (mises à jour) · téléphone : version de l'interface · site : version de la page
let APP_VER = window.VK_VER || '';
function showVer(v) {
  if (v) APP_VER = String(v);
  const a = document.getElementById('appVer'); if (a && APP_VER) a.textContent = 'v' + APP_VER;
  const b = document.getElementById('verAll'); if (b) b.textContent = APP_VER ? 'VDIZI ' + APP_VER : '';
}
setTimeout(() => showVer(), 0);
const viewer = () => window.VK_REMOTE ? !VK_REMOTE.owner() : !!(typeof CLOUD !== 'undefined' && CLOUD && CLOUD.guest);

const ICONS = {
  play: '<path d="M7 4.5v15L19.5 12z" fill="currentColor" stroke="none"/>',
  pause: '<path d="M6.5 4.5h4v15h-4zM13.5 4.5h4v15h-4z" fill="currentColor" stroke="none"/>',
  plus: '<path d="M12 5v14M5 12h14"/>', check: '<path d="m5 12 5 5 9-10"/>', x: '<path d="M6 6l12 12M18 6 6 18"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>', cog: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1"/>',
  back: '<path d="M19 12H5M11 6l-6 6 6 6"/>', next: '<path d="M5 4.5v15l10-7.5zM17 4.5h2.5v15H17z" fill="currentColor" stroke="none"/>',
  bk: '<path d="M11.5 7 6 12l5.5 5M18 7l-5.5 5 5.5 5"/>', fw: '<path d="M12.5 7 18 12l-5.5 5M6 7l5.5 5L6 17"/>',
  music: '<path d="M9 18V5l11-2v13"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/>',
  vol: '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13"/>', mute: '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="m16 9.5 5 5m0-5-5 5"/>',
  full: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>', unfull: '<path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/>',
  cc: '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10.5 10.2a2.3 2.3 0 1 0 0 3.6M17 10.2a2.3 2.3 0 1 0 0 3.6"/>',
  eps: '<rect x="3" y="4" width="18" height="5" rx="1.5"/><rect x="3" y="11" width="18" height="5" rx="1.5"/><path d="M3 20h18"/>',
  list: '<path d="M9 6h11M9 12h11M9 18h11M4 6h.01M4 12h.01M4 18h.01"/>', more: '<circle cx="5" cy="12" r="1.6" fill="currentColor"/><circle cx="12" cy="12" r="1.6" fill="currentColor"/><circle cx="19" cy="12" r="1.6" fill="currentColor"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>', trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>', image: '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="m21 16-5-5-9 9"/>',
  refresh: '<path d="M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7"/>', shuffle: '<path d="M16 3h5v5M4 20 21 3M21 16v5h-5M15 15l6 6M4 4l5 5"/>',
  grip: '<circle cx="9" cy="6" r="1.3" fill="currentColor"/><circle cx="15" cy="6" r="1.3" fill="currentColor"/><circle cx="9" cy="12" r="1.3" fill="currentColor"/><circle cx="15" cy="12" r="1.3" fill="currentColor"/><circle cx="9" cy="18" r="1.3" fill="currentColor"/><circle cx="15" cy="18" r="1.3" fill="currentColor"/>',
  magic: '<path d="M5 19 19 5M15 4l1 2 2 1-2 1-1 2-1-2-2-1 2-1zM6 3l.7 1.3L8 5l-1.3.7L6 7l-.7-1.3L4 5l1.3-.7z"/>', eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  upload: '<path d="M12 16V4M7 9l5-5 5 5M4 20h16"/>', up: '<path d="M12 19V5M6 11l6-6 6 6"/>',
};
const ic = n => `<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${ICONS[n] || ''}</svg>`;

/* ---------- serveur */
async function api(p, opt = {}) {
  const r = await fetch(p, { ...opt, headers: { 'x-k': K, 'content-type': 'application/json', ...(opt.headers || {}) }, body: opt.body && typeof opt.body !== 'string' ? JSON.stringify(opt.body) : opt.body });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || 'Erreur ' + r.status);
  return j;
}
const u = (p, extra = '') => window.VK_REMOTE ? VK_REMOTE.url(p, extra) : `${p}${p.includes('?') ? '&' : '?'}k=${encodeURIComponent(K)}${extra}`; // téléphone : fichiers en ligne (remote.js)

/* ---------- réglages du site (page Administration) */
const TAB_DEFAULT = { home: 'Accueil', series: 'Catalogue', playlists: 'Playlists', auto: 'Travaux', community: 'Communauté', download: 'Télécharger VDIZI' };
let SITE = {}; try { SITE = JSON.parse(localStorage.getItem('vk.site') || '{}'); } catch { }
const label = k => (SITE.labels || {})[k] || TAB_DEFAULT[k];
function applySite(s) {
  SITE = s || {}; try { localStorage.setItem('vk.site', JSON.stringify(SITE)); } catch { }
  document.documentElement.style.setProperty('--acc', SITE.accent || '#E11D2E');
  for (const a of document.querySelectorAll('#nav a')) { const k = a.dataset.r; if (TAB_DEFAULT[k]) { if (k === 'community') { if (typeof suggBadge === 'function') suggBadge(); else a.textContent = label(k); } else a.textContent = label(k); } }
}
// mode maintenance (Administration › Site) : le public ne voit qu'un message ; le propriétaire voit un bandeau
function showMaint() {
  const m = SITE.maintenance && SITE.maintenance.on ? SITE.maintenance : null;
  let d = document.getElementById('maint');
  if (!m) { if (d) d.remove(); return; }
  if (!d) { d = document.createElement('div'); d.id = 'maint'; document.body.appendChild(d); }
  if (viewer()) { d.className = 'maint'; d.innerHTML = `<div><div class="big-ic"></div><h1>🛠️ VDIZI est en maintenance</h1><p>${esc(m.msg || 'On revient très vite !')}</p></div>`; }
  else { d.className = 'maint-own'; d.innerHTML = `🛠️ <b>Mode maintenance activé</b> : le public voit seulement le message. <a href="#/admin" id="maintOff">Le désactiver</a>`; const a = d.querySelector('#maintOff'); if (a) a.onclick = () => { if (typeof ADMIN_AT !== 'undefined') { ADMIN_AT = 'site'; try { localStorage.setItem('vk.adminTab', 'site'); } catch { } } }; }
}
function showAnnounce() {
  const old = document.getElementById('announce'); if (old) old.remove();
  if (!SITE.announce || route.name !== 'home') return;
  const d = document.createElement('div'); d.id = 'announce'; d.className = 'announce'; d.textContent = SITE.announce; view.prepend(d);
}
// calendrier géré dans l'Administration : les sorties à venir, sur l'accueil
function showUpcoming() {
  const old = document.getElementById('upcoming'); if (old) old.remove();
  if (route.name !== 'home') return;
  const n = new Date(), today = `${n.getFullYear()}-${String(n.getMonth() + 1).padStart(2, '0')}-${String(n.getDate()).padStart(2, '0')}`;
  const list = (SITE.calendar || []).filter(x => x.date >= today).slice(0, 8); if (!list.length) return;
  const d = document.createElement('section'); d.id = 'upcoming'; d.className = 'up';
  d.innerHTML = `<h2>À venir</h2><div class="up-l">${list.map(x => `<div class="up-i"><span>${esc(new Date(x.date + 'T12:00:00').toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short' }))}</span><b>${esc(x.title)}</b>${x.note ? `<small>${esc(x.note)}</small>` : ''}</div>`).join('')}</div>`;
  const hero = view.querySelector('.hero'); if (hero) hero.after(d); else view.prepend(d);
}

/* ---------- état */
let LIB = { series: [], playlists: [], progress: {}, settings: {} };
let JOBS = { keys: {}, queue: [], cur: null, done: [] };
let CHECKS = { queue: [], cur: null, done: [] }; // vérifications des sous-titres (voir check.js)
const EPS = new Map();          // id → { ...ep, sid }
function indexLib() { EPS.clear(); for (const s of LIB.series) for (const e of s.eps) EPS.set(e.id, Object.assign(e, { sid: s.id })); }
async function loadLib() { LIB = await api('/api/lib'); indexLib(); if (!viewer() && typeof loadLocks === 'function' && !loadLib.locks) { loadLib.locks = 1; loadLocks().then(() => LOCKED.size && render(true)); } }
const seriesOf = id => LIB.series.find(s => s.id === id);
const prog = id => LIB.progress[id];
const fmt = s => { s = Math.max(0, Math.floor(s || 0)); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60; return h ? `${h}:${String(m).padStart(2, '0')}:${String(x).padStart(2, '0')}` : `${m}:${String(x).padStart(2, '0')}`; };
const fmtDur = s => !s ? '' : s >= 3600 ? `${Math.floor(s / 3600)} h ${String(Math.round(s % 3600 / 60)).padStart(2, '0')}` : `${Math.round(s / 60)} min`;
const epCode = e => `S${String(e.s).padStart(2, '0')}E${String(e.e).padStart(2, '0')}`;
const epLabel = e => `${epCode(e)}${e.title ? ' · ' + e.title : ''}`;
const thumb = id => u(`/thumb/${id}.jpg`);
const cover = s => u(`/cover/${s.id}.jpg`, s.cover ? '&v=' + s.cover : '');
const savePlaylists = () => api('/api/playlists', { method: 'PUT', body: { playlists: LIB.playlists } }).catch(() => { });
const saveSettings = () => api('/api/settings', { method: 'PUT', body: LIB.settings }).catch(() => { });

function toast(msg, bad, action) {
  const t = document.createElement('div'); t.className = 'toast' + (bad ? ' bad' : ''); t.textContent = msg;
  if (action) { const b = document.createElement('button'); b.textContent = action.label; b.onclick = () => { action.fn(); t.remove(); }; t.appendChild(b); }
  $('#toasts').appendChild(t); setTimeout(() => t.remove(), action ? 7000 : bad ? 5500 : 2800);
}

/* ---------- prochaines lectures */
function seriesNext(s) {
  // épisode à reprendre / suivant dans une série
  const eps = s.eps.filter(e => !e.missing || e.cloud);
  let last = null, lastAt = 0;
  for (const e of eps) { const p = prog(e.id); if (p && p.at > lastAt) { lastAt = p.at; last = e; } }
  if (!last) return { ep: eps[0], resume: false };
  const p = prog(last.id);
  if (!p.done) return { ep: last, resume: p.t > 15 };
  const i = eps.indexOf(last);
  return { ep: eps[i + 1] || null, resume: false, finished: !eps[i + 1] };
}
function continueList() {
  const out = [];
  for (const s of LIB.series) {
    const lastAt = Math.max(0, ...s.eps.map(e => (prog(e.id) || {}).at || 0));
    if (!lastAt) continue;
    const n = seriesNext(s); if (!n.ep) continue;
    out.push({ s, ...n, at: lastAt });
  }
  return out.sort((a, b) => b.at - a.at);
}
function playlistEps(pl) {
  const out = [];
  for (const it of pl.items) {
    if (it.t === 'e') { const e = EPS.get(it.id); if (e) out.push(e); }
    else { const s = seriesOf(it.id); if (s) out.push(...s.eps.filter(e => !e.missing || e.cloud)); }
  }
  return out;
}

/* =====================================================================
   Vues
   ===================================================================== */
const view = $('#view');
const appEl = $('#app');
appEl.addEventListener('scroll', () => $('#top').classList.toggle('solid', appEl.scrollTop > 40), { passive: true });
let route = { name: 'home' };
function parseRoute() {
  const h = location.hash.replace(/^#\/?/, '');
  const [a, b, c] = h.split('/');
  if (a === 'auto' && viewer()) return { name: 'home' };
  if (a === 's' && b) return { name: 'serie', id: b, season: c ? +c : null };
  if (a === 'p' && b) return { name: 'playlist', id: b };
  if (a === 'series') return { name: 'series' };
  if (a === 'playlists') return { name: 'playlists' };
  if (a === 'auto') return { name: 'auto' };
  if (a === 'download') return { name: 'download' };
  if (a === 'community') return { name: 'community' };
  if (a === 'admin') return { name: viewer() ? 'home' : 'admin' };
  return { name: 'home' };
}
function render(keepScroll) {
  document.documentElement.classList.toggle('viewer', viewer());
  route = parseRoute();
  const y = appEl.scrollTop;
  $$('#nav a').forEach(a => a.classList.toggle('on', a.dataset.r === route.name || (route.name === 'serie' && a.dataset.r === 'series') || (route.name === 'playlist' && a.dataset.r === 'playlists')));
  const q = norm($('#q').value);
  if (q || route.name !== 'serie') stopMusic();
  if (q) renderSearch(q);
  else if (route.name === 'download') renderDownload();
  else if (route.name === 'community') renderCommunity();
  else if (route.name === 'admin') renderAdmin();
  else if (!LIB.series.length && route.name !== 'auto') renderWelcome();
  else if (route.name === 'serie') renderSerie();
  else if (route.name === 'series') renderSeriesGrid();
  else if (route.name === 'playlists') renderPlaylists();
  else if (route.name === 'playlist') renderPlaylist();
  else if (route.name === 'auto') renderAuto();
  else renderHome();
  showUpcoming(); showAnnounce(); showMaint();
  appEl.scrollTop = keepScroll ? y : 0;
}
window.addEventListener('hashchange', () => render());

function renderWelcome() {
  if (viewer()) { view.innerHTML = `<div class="empty"><div class="big-ic"></div><h1>Bienvenue sur VDIZI</h1><p>Aucune série en ligne pour le moment. Reviens bientôt !</p></div>`; return; }
  view.innerHTML = `<div class="empty"><div class="big-ic"></div><h1>Bienvenue sur VDIZI</h1>
  <p>Ajoute tes séries depuis ton PC. Tes fichiers restent où ils sont : rien n'est copié, ça ne prend pas de place en plus.</p>
  <button class="btn big" id="wAdd">${ic('folder')}Ajouter un dossier de série</button>
  <div class="steps">
    <div><span class="n">1</span><span><b>Un dossier par série</b> (avec ou sans sous-dossiers « Saison 1 », « Season 2 »…). Les épisodes sont rangés tout seuls grâce à leur nom (S01E02, 1x02, Épisode 2…).</span></div>
    <div><span class="n">2</span><span><b>Glisse-dépose</b> aussi des dossiers ou des fichiers directement dans la fenêtre.</span></div>
    <div><span class="n">3</span><span><b>Sous-titres</b> : ceux intégrés aux fichiers et les .srt à côté sont trouvés automatiquement. Sinon, l'IA les crée en français en 2-3 minutes par épisode.</span></div>
  </div></div>`;
  $('#wAdd').onclick = () => addFlow('folders');
}

function heroHTML(c) {
  const s = c.s, e = c.ep, p = prog(e.id);
  return `<section class="hero"><div class="bg" style="background-image:url('${cover(s)}')"></div><div class="shade"></div>
    <div class="info"><div class="kick"><span class="tag">${c.resume ? 'EN COURS' : 'À SUIVRE'}</span><span>${s.eps.length} épisodes</span></div>
    <h1>${esc(s.name)}</h1>
    <div class="sub">${esc(epLabel(e))}</div>
    <div class="meta">${c.resume && p ? `Reprise à ${fmt(p.t)} · reste ${fmtDur((p.d || e.dur) - p.t)}` : fmtDur(e.dur)}</div>
    ${c.resume && p && p.d ? `<div class="pbar"><i style="width:${(p.t / p.d * 100).toFixed(1)}%"></i></div>` : ''}
    <div class="acts"><button class="btn white big" data-play="${e.id}">${ic('play')}${c.resume ? 'Reprendre' : 'Lecture'}</button><a class="btn ghost big" href="#/s/${s.id}">${ic('eps')}Épisodes</a></div></div></section>`;
}
function epCard(e, opts = {}) {
  const p = prog(e.id), s = seriesOf(e.sid);
  const pc = p && p.d && !p.done ? p.t / p.d * 100 : 0;
  return `<button class="card" data-play="${e.id}" ${opts.ctx ? `data-ctx="${opts.ctx}"` : ''} title="${esc(s.name + ' — ' + epLabel(e))}"><span class="cv" style="background-image:url('${thumb(e.id)}')"></span>
    ${e.autoFr ? '<span class="badge fr">FR</span>' : ''}
    <span class="play">${ic('play')}</span>
    <span class="ct"><b>${esc(opts.showSeries ? s.name : epLabel(e))}</b><small>${esc(opts.showSeries ? epLabel(e) : fmtDur(e.dur))}</small>${pc ? `<span class="pbar"><i style="width:${pc.toFixed(1)}%"></i></span>` : ''}</span></button>`;
}
function seriesCard(s) {
  const n = seriesNext(s), seasons = new Set(s.eps.map(e => e.s)).size;
  return `<a class="card" href="#/s/${s.id}" data-sid="${s.id}" title="${esc(s.name)}"><span class="cv" style="background-image:url('${cover(s)}')"></span><span class="play">${ic('eps')}</span>
    <span class="ct"><b>${isLocked(s) ? '🔒 ' : ''}${esc(s.name)}</b><small>${s.soon ? '<span class="soonb">⏳ Bientôt disponible</span>' : s.locked && !s.unlocked && viewer() ? 'Protégée par mot de passe' : `${seasons > 1 ? seasons + ' saisons · ' : ''}${s.eps.length} épisode${s.eps.length > 1 ? 's' : ''}${n.finished ? ' · terminée ✓' : ''}`}</small></span></a>`;
}
function playlistCard(pl) {
  const eps = playlistEps(pl), pics = eps.slice(0, 4);
  return `<a class="card pl" href="#/p/${pl.id}"><span class="mosaic">${pics.map(e => `<i style="background-image:url('${thumb(e.id)}')"></i>`).join('')}</span><span class="play">${ic('list')}</span>
    <span class="ct"><b>${esc(pl.name)}</b><small>${eps.length} épisode${eps.length > 1 ? 's' : ''} · ${fmtDur(eps.reduce((a, e) => a + (e.dur || 0), 0)) || 'playlist'}</small></span></a>`;
}
function rowHTML(title, cards, extra = '') { return cards.length || extra ? `<section class="row"><h2>${title}</h2><div class="rscroll">${cards.join('')}${extra}</div></section>` : ''; }

function renderHome() {
  const cont = continueList();
  const avail = LIB.series.filter(s => !s.soon), soon = catOrder(LIB.series.filter(s => s.soon));
  const hero = cont[0] || (() => { const s = [...avail].sort((a, b) => b.added - a.added)[0]; const n = seriesNext(s); return n.ep ? { s, ...n } : null; })();
  const recent = [...avail].sort((a, b) => b.added - a.added);
  view.innerHTML = (hero ? heroHTML(hero) : '<div style="height:80px"></div>') + `<div class="rows">
    ${rowHTML('Continuer à regarder', cont.map(c => epCard(c.ep, { showSeries: true })))}
    ${rowHTML('⏳ Bientôt disponible', soon.map(seriesCard))}
    ${rowHTML('Mes playlists', LIB.playlists.map(playlistCard), `<button class="card addc" id="newPl">${ic('plus')}Nouvelle playlist</button>`)}
    ${rowHTML(esc(label('series')) + ' <small>' + avail.length + '</small>', recent.map(seriesCard), `<button class="card addc" data-add>${ic('plus')}Ajouter une série</button>`)}
  </div>`;
  $('#newPl') && ($('#newPl').onclick = () => newPlaylist());
}
// ordre du catalogue choisi par le propriétaire (réglages du site : le même pour tout le monde) ; les séries
// pas encore placées viennent ensuite, par ordre alphabétique
function catOrder(list) {
  const ord = Array.isArray(SITE.order) ? SITE.order : [], pos = new Map(ord.map((id, i) => [id, i]));
  return [...list].sort((a, b) => (pos.has(a.id) ? pos.get(a.id) : 1e9) - (pos.has(b.id) ? pos.get(b.id) : 1e9) || a.name.localeCompare(b.name, 'fr'));
}
// tous les réglages du site, pour les renvoyer au serveur sans en perdre (il remplace l'ensemble)
const siteBody = extra => ({ labels: SITE.labels || {}, announce: SITE.announce || '', accent: SITE.accent || '', calendar: SITE.calendar || [], maintenance: !!(SITE.maintenance && SITE.maintenance.on), maintenanceMsg: (SITE.maintenance && SITE.maintenance.msg) || '', order: SITE.order || [], ...extra });
function reorderCatalog() {
  const g = $('#catGrid'); if (!g || !window.Sortable) return toast('Réorganisation impossible ici', true);
  g.classList.add('reorder');
  $('#catBar').innerHTML = `<span class="grow"><b>↕️ Glisse les séries</b> dans l'ordre voulu (le public verra cet ordre dans le catalogue).</span><button class="btn ghost" id="ordNo">Annuler</button><button class="btn" id="ordOk">${ic('check')}Enregistrer l'ordre</button>`;
  $$('#catGrid a').forEach(a => a.addEventListener('click', e => { if (g.classList.contains('reorder')) e.preventDefault(); }, true));
  const so = Sortable.create(g, { animation: 150 });
  $('#ordNo').onclick = () => { so.destroy(); renderSeriesGrid(); };
  $('#ordOk').onclick = async () => {
    const order = $$('#catGrid [data-sid]').map(x => x.dataset.sid);
    try { const s = await api('/api/cloud/site', { method: 'POST', body: siteBody({ order }) }); applySite(s); so.destroy(); renderSeriesGrid(); toast('Ordre du catalogue enregistré : visible tout de suite par tout le monde ✓'); }
    catch (e) { toast(e.message, true); }
  };
}
function renderSeriesGrid() {
  view.innerHTML = `<div class="page"><div class="ph"><h1>${esc(label('series'))}</h1><span class="grow"></span>${viewer() ? '' : `<button class="btn ghost" id="ordGo">↕️ Réorganiser</button>`}<button class="btn ghost" id="newSer">${ic('plus')}Nouvelle série</button><button class="btn" data-add>${ic('plus')}Ajouter</button></div>
    ${LIB.series.some(s => s.soon) ? `<h2 class="soonh">⏳ Bientôt disponible</h2><div class="grid soong">${catOrder(LIB.series.filter(s => s.soon)).map(seriesCard).join('')}</div><h2 class="soonh">Disponibles</h2>` : ''}
    <div class="catbar" id="catBar"></div><div class="grid" id="catGrid">${catOrder(LIB.series.filter(s => !s.soon)).map(seriesCard).join('')}</div></div>`;
  $('#newSer').onclick = () => newSeries();
  const og = $('#ordGo'); if (og) og.onclick = () => reorderCatalog();
}

/* ---------- créer une série vide, déplacer un épisode */
async function addEpisodesTo(s) { const f = await VK.pickFiles(); if (!f || !f.length) return; const before = s.eps.length; try { LIB = await api(`/api/series/${s.id}`, { method: 'POST', body: { paths: f } }); indexLib(); render(true); const n = (seriesOf(s.id) || s).eps.length - before; toast(n > 0 ? `${n} épisode${n > 1 ? 's' : ''} ajouté${n > 1 ? 's' : ''} à « ${s.name} »` : 'Ces épisodes étaient déjà dans la série'); } catch (e) { toast(e.message, true); } }

async function newSeries(thenEp) {
  const name = await askText('Nouvelle série', '', { ok: 'Créer', placeholder: 'ex : Kara Sevda' });
  if (!name || !name.trim()) return null;
  try {
    const r = await api('/api/newseries', { method: 'POST', body: { name: name.trim() } });
    LIB = r.lib; indexLib();
    if (thenEp) await moveEp(thenEp, r.id);
    else { location.hash = '#/s/' + r.id; toast(`Série « ${name.trim()} » créée : ajoute-lui des épisodes`); }
    return r.id;
  } catch (e) { toast(e.message, true); return null; }
}
async function moveEp(e, sid) {
  try {
    LIB = await api(`/api/ep/${e.id}`, { method: 'POST', body: { moveTo: sid } }); indexLib();
    const to = seriesOf(sid); toast(`Épisode déplacé vers « ${to ? to.name : ''} »`);
    location.hash = '#/s/' + sid; render(true);
  } catch (er) { toast(er.message, true); }
}
function moveMenu(e, x, y) {
  const others = LIB.series.filter(s => s.id !== e.sid).sort((a, b) => a.name.localeCompare(b.name, 'fr'));
  menu(x, y, [{ h: 'Déplacer vers…' }, ...others.map(s => ({ label: s.name, icon: 'eps', act: () => moveEp(e, s.id) })), '-', { label: 'Nouvelle série…', icon: 'plus', act: () => newSeries(e) }]);
}
function renderSearch(q) {
  const toks = q.split(' ');
  const ser = LIB.series.filter(s => toks.every(t => norm(s.name).includes(t)));
  const eps = [...EPS.values()].filter(e => { const h = norm(seriesOf(e.sid).name + ' ' + epCode(e) + ' ' + e.title + ' ' + e.file); return toks.every(t => h.includes(t)); }).slice(0, 60);
  view.innerHTML = `<div class="page"><div class="ph"><h1>Résultats</h1></div>
    ${ser.length ? `<h2 style="margin:6px 0 10px">Séries</h2><div class="grid">${ser.map(seriesCard).join('')}</div>` : ''}
    ${eps.length ? `<h2 style="margin:26px 0 10px">Épisodes</h2><div class="grid">${eps.map(e => epCard(e, { showSeries: true })).join('')}</div>` : ''}
    ${!ser.length && !eps.length ? '<p style="color:#999">Aucun résultat.</p>' : ''}</div>`;
}

/* ---------- page série */
// propriétaire : à quel épisode commence chaque saison (séries numérotées en continu : Bölüm 1, 2… 70)
function openSeasons(s0) {
  const sheet = $('#sheet');
  const draw = (starts) => {
    const s = seriesOf(s0.id); if (!s) return;
    const nums = s.eps.map(e => e.e).filter(n => n != null), lo = Math.min(...nums), hi = Math.max(...nums);
    const st = [...new Set(starts)].filter(n => n > 1).sort((x, y) => x - y);
    const bounds = [lo, ...st], prev = bounds.map((from, i) => { const to = i + 1 < bounds.length ? bounds[i + 1] - 1 : hi; const n = s.eps.filter(e => e.e >= from && e.e <= to).length; return `<li><b>Saison ${i + 1}</b> : épisodes ${from} à ${to} <small class="mut">(${n} épisode${n > 1 ? 's' : ''})</small></li>`; }).join('');
    sheet.innerHTML = `<h3>Saisons de « ${esc(s.name)} »</h3>
      <p class="mut">Indique à quel épisode commence chaque nouvelle saison. Les spectateurs pourront ensuite choisir « Toutes » (par défaut) ou une saison précise.</p>
      <div class="seasl">${st.map((n, i) => `<div class="kform"><span>La <b>saison ${i + 2}</b> commence à l'épisode</span><input type="number" min="2" value="${n}" data-st="${i}" style="width:90px"><button class="btn sm ghost" data-strm="${i}" title="Retirer">${ic('x')}</button></div>`).join('')}</div>
      <button class="btn ghost" id="stAdd" style="margin:10px 0">${ic('plus')}Ajouter une saison</button>
      <div class="note"><b>Aperçu</b><ul style="margin:6px 0 0 18px">${prev}</ul></div>
      <div class="foot"><button class="btn ghost" id="stReset">D'après les noms de fichiers</button><span class="grow"></span><button class="btn ghost" id="stNo">Annuler</button><button class="btn" id="stOk">${ic('check')}Enregistrer</button></div>`;
    const read = () => $$('[data-st]').map(i => +i.value).filter(n => n > 1);
    $$('[data-st]').forEach(i => i.onchange = () => draw(read()));
    $$('[data-strm]').forEach(b => b.onclick = () => { const r = read(); r.splice(+b.dataset.strm, 1); draw(r); });
    $('#stAdd').onclick = () => { const r = read(); const last = r.length ? r[r.length - 1] : lo; draw([...r, Math.min(hi, last + Math.max(1, Math.round((hi - lo + 1) / (r.length + 2))))]); };
    $('#stNo').onclick = () => { $('#modal').hidden = true; };
    const save = async list => { try { LIB = await api(`/api/series/${s.id}`, { method: 'POST', body: { seasonStarts: list } }); indexLib(); $('#modal').hidden = true; render(true); toast(list.length ? `${list.length + 1} saisons enregistrées ✓` : 'Saisons recalculées d\'après les noms de fichiers'); } catch (e) { toast(e.message, true); } };
    $('#stOk').onclick = () => save(read());
    $('#stReset').onclick = () => save([]);
  };
  draw(Array.isArray(s0.seasonStarts) ? s0.seasonStarts : []);
  $('#modal').hidden = false;
}
// « Bientôt disponible » vu par un spectateur : présentation seulement (les épisodes sont réservés au propriétaire)
function renderSoon(s) {
  view.innerHTML = `<section class="sh">${heroBg(s)}<div class="shade"></div>
    <div class="info"><h1>${esc(s.name)}</h1><div class="meta"><span class="soonb big">⏳ Bientôt disponible</span></div>
    ${s.desc ? `<p class="sdesc">${esc(s.desc)}</p>` : ''}
    <div class="acts">${musList(s).length ? '<div id="sMusic" class="smus"></div>' : ''}</div></div></section>
    <div class="page"><p style="color:#aaa;font-size:16px;padding:10px 0 40px">Les épisodes de cette série arrivent bientôt sur VDIZI. Reviens vite !</p></div>`;
  playMusic(s); startSlides();
  const mb = $('#sMusic'); if (mb) { mb.onclick = ev => { const b = ev.target.closest('[data-mus]'); if (b && b.dataset.mus !== 'vol') musAction(s, b.dataset.mus); }; mb.oninput = ev => { if (ev.target.dataset.mus === 'vol') musAction(s, 'vol', +ev.target.value); }; musBtn(s); }
}
// série protégée par mot de passe : cadenas (le propriétaire voit aussi ses séries protégées)
const isLocked = s => !!s.locked || (typeof LOCKED !== 'undefined' && LOCKED.has(s.id));
function renderLocked(s) {
  view.innerHTML = `<section class="sh"><div class="bg" style="background-image:url('${cover(s)}')"></div><div class="shade"></div>
    <div class="info"><h1>🔒 ${esc(s.name)}</h1><div class="meta">Cette série est protégée par un mot de passe.</div>${s.desc ? `<p class="sdesc">${esc(s.desc)}</p>` : ''}
    <form class="lockf" id="lockF"><input type="password" id="lockPw" placeholder="Mot de passe de la série" autocomplete="off"><button class="btn white big" type="submit">${ic('play')}Ouvrir la série</button></form><div class="err" id="lockErr"></div></div></section>`;
  $('#lockF').onsubmit = async e => {
    e.preventDefault(); const pw = $('#lockPw').value; if (!pw) return $('#lockPw').focus();
    $('#lockErr').textContent = 'Vérification…';
    try { await api('/api/unlock', { method: 'POST', body: { sid: s.id, password: pw } }); await loadLib(); toast(`« ${s.name} » est ouverte sur cet appareil ✓`); render(); }
    catch (er) { $('#lockErr').textContent = er.message.charAt(0).toUpperCase() + er.message.slice(1); $('#lockPw').select(); }
  };
  setTimeout(() => $('#lockPw') && $('#lockPw').focus(), 50);
}
// description d'une série (propriétaire) : écrite à la main ou par l'IA, visible par tout le monde, même sans compte
function openDesc(s) {
  const sheet = $('#sheet');
  sheet.innerHTML = `<h3>Description de « ${esc(s.name)} »</h3>
    <p class="mut">Un court résumé qui donne envie de regarder, visible par tout le monde (même sans compte). L'IA s'appuie sur le synopsis officiel (cherché sur internet, s'il correspond bien à la série), sur les résumés de tous les épisodes sous-titrés et sur les personnages, sans rien révéler de la suite ; une relecture retire tout ce qui n'est pas prouvé.</p>
    <textarea id="dTxt" class="adm-t" rows="6" maxlength="1200" placeholder="Ex : Dans un quartier d'Istanbul, quatre amis d'enfance…">${esc(s.desc || '')}</textarea>
    <div class="foot"><button class="btn ghost" id="dAi">✨ Écrire avec l'IA</button><span class="grow"></span><button class="btn ghost" id="dNo">Annuler</button><button class="btn" id="dOk">${ic('check')}Enregistrer</button></div>`;
  $('#modal').hidden = false;
  $('#dNo').onclick = () => { $('#modal').hidden = true; };
  $('#dAi').onclick = async () => {
    const b = $('#dAi'); b.disabled = true; b.textContent = '✨ L\'IA écrit…';
    try { const r = await api(`/api/series/${s.id}/describe`, { method: 'POST', body: {} }); if (r.desc) $('#dTxt').value = r.desc; const B = r.basis || {}; toast(`Description proposée${B.summaries !== undefined ? ` d'après ${B.official ? 'le synopsis officiel, ' : ''}${B.summaries} résumé${B.summaries > 1 ? 's' : ''} d'épisodes et ${B.characters} personnages${B.fixed ? ` (${B.fixed} correction${B.fixed > 1 ? 's' : ''} à la relecture)` : ''}` : ''} : relis-la, puis Enregistrer`); }
    catch (e) { toast(e.message, true); }
    b.disabled = false; b.textContent = '✨ Réécrire avec l\'IA';
  };
  $('#dOk').onclick = async () => {
    try { LIB = await api(`/api/series/${s.id}`, { method: 'POST', body: { desc: $('#dTxt').value } }); indexLib(); $('#modal').hidden = true; render(true); toast('Description enregistrée : visible par tout le monde ✓'); }
    catch (e) { toast(e.message, true); }
  };
}
function renderSerie() {
  const s = seriesOf(route.id); if (!s) { location.hash = '#/series'; return; }
  if (s.locked && !s.unlocked && viewer()) return renderLocked(s);
  if (s.soon && viewer()) return renderSoon(s);
  const seasons = [...new Set(s.eps.map(e => e.s))].sort((a, b) => a - b);
  const n = seriesNext(s);
  // saison choisie (null = toutes les saisons, par défaut)
  const cur = seasons.length > 1 && route.season != null && seasons.includes(route.season) ? route.season : null;
  const eps = cur == null ? s.eps : s.eps.filter(e => e.s === cur);
  const nFr = s.eps.filter(e => e.autoFr).length, nPend = s.eps.filter(e => e.pending).length;
  view.innerHTML = `<section class="sh">${heroBg(s)}<div class="shade"></div>
    <div class="info"><h1>${esc(s.name)}</h1>
    <div class="meta">${seasons.length > 1 ? seasons.length + ' saisons · ' : ''}${s.eps.length} épisodes · ${fmtDur(s.eps.reduce((a, e) => a + (e.dur || 0), 0)) || ''}${nFr ? ` · ${nFr} sous-titré${nFr > 1 ? 's' : ''} FR${viewer() ? '' : ' (IA)'}` : ''}</div>
    ${s.desc ? `<p class="sdesc">${esc(s.desc)}</p>` : ''}${viewer() ? '' : `<button class="btn sm ghost sdesc-ed" id="sDesc">${s.desc ? '✏️ Modifier la description' : '✨ Ajouter une description (IA)'}</button>`}
    <div class="acts">
      ${n.ep ? `<button class="btn white big" data-play="${n.ep.id}">${ic('play')}${n.resume ? 'Reprendre ' + epCode(n.ep) : n.finished ? 'Revoir' : 'Lecture ' + epCode(n.ep)}</button>` : s.eps.length ? `<button class="btn white big" data-play="${s.eps[0].id}">${ic('play')}Revoir</button>` : `<button class="btn white big" id="sAddEp">${ic('plus')}Ajouter des épisodes</button>`}
      <button class="btn ghost big" id="sPl">${ic('plus')}Playlist</button>
      <button class="btn ghost big" id="sAuto" title="Créer des sous-titres français pour les épisodes qui n'en ont pas">${ic('magic')}${nPend ? 'Sous-titrage en cours…' : 'Sous-titres FR (IA)'}</button>
      <button class="btn ghost big" id="sMore" title="Plus">${ic('more')}</button>
      ${musList(s).length ? `<div id="sMusic" class="smus"></div>` : ''}
    </div></div></section>
    ${s.soon && !viewer() ? '<div class="soonnote">⏳ Cette série est dans « Bientôt disponible » : tout le monde la voit, mais ses épisodes ne sont visibles et lisibles que par toi (compte propriétaire).</div>' : ''}
    <div class="seasons">${seasons.length > 1 ? `<button data-season="all" class="${cur == null ? 'on' : ''}">Toutes</button>` + seasons.map(x => `<button data-season="${x}" class="${x === cur ? 'on' : ''}">Saison ${x}</button>`).join('') : `<b style="font-size:20px">Épisodes</b>`}</div>
    <div class="eps">${eps.map((e, i) => (cur == null && seasons.length > 1 && (i === 0 || eps[i - 1].s !== e.s) ? `<h3 class="seash">Saison ${e.s}</h3>` : '') + epRow(e)).join('') || `<p style="color:#999;padding:10px 0 30px;line-height:1.7">Aucun épisode pour l'instant.<br>Clique sur « Ajouter des épisodes » pour choisir des vidéos sur ton PC (par exemple dans Téléchargements),<br>ou, depuis une autre série, fais un clic droit sur un épisode → « Déplacer vers une autre série ».</p>`}</div><div style="height:60px"></div>`;
  $$('.seasons [data-season]').forEach(b => b.onclick = () => { location.hash = b.dataset.season === 'all' ? `#/s/${s.id}` : `#/s/${s.id}/${b.dataset.season}`; });
  $('#sPl').onclick = ev => pickPlaylist([{ t: 's', id: s.id }], ev.currentTarget);
  $('#sAuto').onclick = ev => autoMenu(s, cur, ev.currentTarget);
  $('#sMore').onclick = ev => seriesMenu(s, ev.currentTarget);
  const sd = $('#sDesc'); if (sd) sd.onclick = () => openDesc(s);
  const ae = $('#sAddEp'); if (ae) ae.onclick = () => addEpisodesTo(s);
  playMusic(s); startSlides();
  const mb = $('#sMusic'); if (mb) { mb.onclick = ev => { const b = ev.target.closest('[data-mus]'); if (b && b.dataset.mus !== 'vol') musAction(s, b.dataset.mus); }; mb.oninput = ev => { if (ev.target.dataset.mus === 'vol') musAction(s, 'vol', +ev.target.value); }; musBtn(s); }
}

/* ---------- images d'une série : plusieurs → elles défilent en fond de la page série (10 s chacune, en boucle) */
const SLIDE = { t: 0, sid: null, i: 0 }; // garde l'image affichée quand la page se redessine (mises à jour régulières)
const imgList = s => (s && Array.isArray(s.images) ? s.images.filter(x => x && x.id) : []);
const imgUrl = (s, im) => u(`/cover/${s.id}.${im.id}.jpg`, '&v=' + im.at);
function heroBg(s) {
  const L = imgList(s);
  if (L.length < 2) return `<div class="bg" style="background-image:url('${cover(s)}')"></div>`;
  const on = SLIDE.sid === s.id ? SLIDE.i % L.length : 0;
  return L.map((im, i) => `<div class="bg sl${i === on ? ' on' : ''}" style="background-image:url('${imgUrl(s, im)}')"></div>`).join('');
}
function startSlides() {
  const sid = route.id, b = $$('.sh .bg.sl');
  if (b.length < 2) { clearInterval(SLIDE.t); SLIDE.t = 0; SLIDE.sid = null; return; }
  if (SLIDE.sid === sid && SLIDE.t) return; // même série : le défilement continue là où il en était
  clearInterval(SLIDE.t); SLIDE.sid = sid; SLIDE.i = 0;
  SLIDE.t = setInterval(() => {
    const els = $$('.sh .bg.sl');
    if (route.name !== 'serie' || route.id !== SLIDE.sid || els.length < 2) { clearInterval(SLIDE.t); SLIDE.t = 0; SLIDE.sid = null; return; }
    SLIDE.i = (SLIDE.i + 1) % els.length; els.forEach((e, k) => e.classList.toggle('on', k === SLIDE.i));
  }, 10000);
}
async function pickImages(s, then) {
  const f = await VK.pickImage(); if (!f || (Array.isArray(f) && !f.length)) return;
  const files = Array.isArray(f) ? f : [f];
  toast(files.length > 1 ? `Préparation de ${files.length} images…` : 'Préparation de l\'image…');
  try {
    const r = await api(`/api/series/${s.id}`, { method: 'POST', body: { imagesAdd: files } }); const bad = r.musicBad || []; delete r.musicBad;
    LIB = r; indexLib(); render(true); then && then();
    const n = files.length - bad.length;
    toast(bad.length ? `${n} image${n > 1 ? 's' : ''} ajoutée${n > 1 ? 's' : ''} · illisible${bad.length > 1 ? 's' : ''} : ${bad.join(', ')}` : `${n > 1 ? n + ' images ajoutées : elles défilent toutes les 10 s sur la page de la série' : 'Image ajoutée'}${s.eps.some(e => e.cloud) ? ', ici et en ligne' : ''}`, !!bad.length);
  } catch (e) { toast(e.message, true); }
}
// propriétaire : images de la série, ordre (la 1re = image du catalogue) par glisser-déposer, retrait
function openImages(s0) {
  const sheet = $('#sheet');
  const draw = () => {
    const s = seriesOf(s0.id); if (!s) return;
    const L = imgList(s);
    sheet.innerHTML = `<h3>Images de « ${esc(s.name)} »</h3>
      <p class="mut">La 1re est l'image de la série dans le catalogue. Sur la page de la série, elles défilent toutes, 10 secondes chacune, en boucle. Glisse-les pour changer l'ordre.</p>
      <div id="imgItems">${L.map((im, i) => `<div class="pli imgi" data-id="${esc(im.id)}"><span class="grip">${ic('grip')}</span><span class="th" style="background-image:url('${imgUrl(s, im)}')"></span><div><b>Image ${i + 1}</b><small>${i ? '' : 'image du catalogue'}</small></div><button class="btn sm ghost" data-idel="${esc(im.id)}" title="Retirer cette image">${ic('x')}</button></div>`).join('') || '<p class="mut">Aucune image : VDIZI prend une image d\'un épisode.</p>'}</div>
      <div class="foot">${VK ? `<button class="btn ghost" id="iAdd">${ic('plus')}Ajouter des images</button>` : '<span class="mut">Ajout d\'images : depuis l\'appli sur ton PC</span>'}<span class="grow"></span><button class="btn" id="iOk">${ic('check')}Fermer</button></div>`;
    $('#iOk').onclick = () => { $('#modal').hidden = true; };
    const ia = $('#iAdd'); if (ia) ia.onclick = () => pickImages(s, draw);
    $$('[data-idel]').forEach(b => b.onclick = async () => {
      if (!confirm('Retirer cette image ?')) return;
      try { LIB = await api(`/api/series/${s.id}`, { method: 'POST', body: { imageDel: b.dataset.idel } }); indexLib(); render(true); draw(); toast('Image retirée'); } catch (e) { toast(e.message, true); }
    });
    if (window.Sortable && L.length > 1) Sortable.create($('#imgItems'), { animation: 150, handle: '.grip', onEnd: async ev => {
      if (ev.oldIndex === ev.newIndex) return;
      const order = $$('#imgItems [data-id]').map(x => x.dataset.id);
      try { LIB = await api(`/api/series/${s.id}`, { method: 'POST', body: { imageOrder: order } }); indexLib(); render(true); draw(); toast('Ordre des images enregistré'); } catch (e) { toast(e.message, true); draw(); }
    } });
  };
  draw(); $('#modal').hidden = false;
}

/* ---------- musique de fond d'une série (joue sur sa page, s'arrête ailleurs ou pendant un épisode) */
// Les musiques se jouent une seule fois, à la suite, dans l'ordre choisi par le propriétaire. Ensuite, plus rien
// sauf si le spectateur clique « Relancer la musique ». Il peut couper à tout moment ; s'il n'a pas coupé,
// la musique reprend exactement où elle en était quand il revient (même après avoir fermé l'appli).
// Où en est chaque spectateur, par série (sur son appareil) : { sig, tid, t, off, done }
const MUS = { a: null, sid: null, tid: null, sig: '', fade: 0, saved: 0 };
const musList = s => { const m = s && s.music; if (!m) return []; if (Array.isArray(m.list)) return m.list.filter(t => t && t.at); return m.at ? [{ id: '', at: m.at }] : []; };
const musSig = L => L.map(t => t.id + ':' + t.at).join(',');
function musState(s) {
  const L = musList(s), sig = musSig(L);
  let all = {}; try { all = JSON.parse(localStorage.getItem('vks-mus') || '{}') || {}; } catch { }
  let st = all[s.id];
  // la liste a changé (musique ajoutée, retirée, déplacée) : on repart du début ; un son coupé le reste
  if (!st || st.sig !== sig) { let off = st ? !!st.off : false; try { if (!st && localStorage.getItem('vks-music-off') === '1') off = true; } catch { } st = { sig, tid: L.length ? L[0].id : '', t: 0, off, done: false, muted: !!(st && st.muted) }; }
  return st;
}
function musSave(sid, st) { try { const all = JSON.parse(localStorage.getItem('vks-mus') || '{}') || {}; all[sid] = st; localStorage.setItem('vks-mus', JSON.stringify(all)); } catch { } }
function fadeTo(a, vol, ms, then) {
  clearInterval(MUS.fade); const v0 = a.volume, t0 = Date.now();
  MUS.fade = setInterval(() => { const k = Math.min(1, (Date.now() - t0) / ms); a.volume = Math.max(0, Math.min(1, v0 + (vol - v0) * k)); if (k >= 1) { clearInterval(MUS.fade); then && then(); } }, 40);
}
const musPlaying = s => !!(MUS.a && s && MUS.sid === s.id && !MUS.a.paused);
// volume choisi par le spectateur (le même pour toutes les séries, sur cet appareil)
const musVol = s => { try { const v = parseFloat(localStorage.getItem('vks-mus-vol')); if (v >= 0 && v <= 1) return v; } catch { } return (s && s.music && s.music.vol) || 0.35; };
// mini lecteur de la page série : morceau en cours, lecture/pause, suivante, son coupé, volume ; « Relancer » quand tout a été joué
function musBtn(s) {
  const b = $('#sMusic'); if (!b || !s || route.id !== s.id) return;
  const L = musList(s), st = musState(s), on = musPlaying(s);
  const i = Math.max(0, L.findIndex(t => t.id === (MUS.sid === s.id && MUS.tid != null ? MUS.tid : st.tid)));
  if (st.done && !on) { b.innerHTML = `<button class="btn ghost big" data-mus="restart" title="Rejouer les musiques depuis la première">${ic('music')}Relancer la musique</button>`; return; }
  const t = L[i] || {}, muted = !!st.muted, vol = musVol(s);
  const name = t.name ? esc(t.name) : 'Musique';
  b.innerHTML = `<div class="mplay" title="Musique de fond">
    <span class="mp-ic">${ic('music')}</span><span class="mp-t"><b>${name}</b><small>${L.length > 1 ? `${i + 1} / ${L.length}` : 'Musique de fond'}</small></span>
    <button class="mp-b" data-mus="toggle" title="${on ? 'Pause' : 'Lecture'}">${ic(on ? 'pause' : 'play')}</button>
    ${L.length > 1 ? `<button class="mp-b" data-mus="next" title="Musique suivante"${i + 1 >= L.length ? ' disabled' : ''}>${ic('next')}</button>` : ''}
    <button class="mp-b" data-mus="mute" title="${muted ? 'Remettre le son' : 'Couper le son'}">${ic(muted || !vol ? 'mute' : 'vol')}</button>
    <input type="range" class="mp-v" data-mus="vol" min="0" max="100" value="${Math.round((muted ? 0 : vol) * 100)}" title="Volume" aria-label="Volume de la musique">
  </div>`;
}
function playMusic(s) {
  const L = musList(s);
  if (!L.length || !player.hidden) { stopMusic(); return musBtn(s); }
  const st = musState(s);
  // pas de son tout seul si le spectateur a mis pause, coupé le son, ou si tout a déjà été joué
  if (st.off || st.done || st.muted) { stopMusic(); musSave(s.id, st); return musBtn(s); }
  let i = L.findIndex(t => t.id === st.tid); if (i < 0) { i = 0; st.tid = L[0].id; st.t = 0; }
  if (MUS.a && MUS.sid === s.id && MUS.sig === st.sig && MUS.tid === st.tid) { if (MUS.a.paused) MUS.a.play().catch(() => { }); MUS.a.muted = false; fadeTo(MUS.a, musVol(s), 600); return musBtn(s); }
  stopMusic(true);
  musTrack(s, L, i, st.t || 0, st.sig);
}
function musTrack(s, L, i, from, sig) {
  const t = L[i];
  const a = new Audio(u(`/music/${s.id}${t.id ? '.' + t.id : ''}.mp3`, '&v=' + t.at)); a.volume = 0; a.preload = 'auto';
  MUS.a = a; MUS.sid = s.id; MUS.tid = t.id; MUS.sig = sig; MUS.saved = Date.now();
  const cur = () => musState(s);
  a.onplay = a.onpause = () => musBtn(s);
  a.ontimeupdate = () => { if (MUS.a === a && Date.now() - MUS.saved > 2500) { MUS.saved = Date.now(); musSave(s.id, { ...cur(), sig, tid: t.id, t: a.currentTime || 0, done: false }); } };
  a.onended = () => {
    if (MUS.a !== a) return;
    if (i + 1 < L.length) { musSave(s.id, { ...cur(), sig, tid: L[i + 1].id, t: 0, off: false, done: false }); MUS.a = null; musTrack(s, L, i + 1, 0, sig); }
    else { musSave(s.id, { ...cur(), sig, tid: L[0].id, t: 0, off: false, done: true }); MUS.a = null; MUS.sid = null; musBtn(s); }
  };
  a.onerror = () => { if (MUS.a === a) { MUS.a = null; MUS.sid = null; musBtn(s); } };
  const go = () => { a.play().then(() => fadeTo(a, musVol(s), from > 0 ? 1200 : 1500)).catch(() => musBtn(s)); };
  if (from > 0.5) a.addEventListener('loadedmetadata', () => { if (from < (a.duration || 0) - 1) a.currentTime = from; go(); }, { once: true });
  else go();
}
function stopMusic(now) {
  const a = MUS.a; if (!a) return;
  // on note où on en est : la musique reprendra là au retour sur la série
  if (MUS.sid && a.currentTime > 0) { let st = null; try { st = (JSON.parse(localStorage.getItem('vks-mus') || '{}') || {})[MUS.sid]; } catch { } if (st && !st.done && st.tid === MUS.tid) musSave(MUS.sid, { ...st, t: a.currentTime }); }
  MUS.a = null; MUS.sid = null;
  if (now) { a.pause(); return; }
  fadeTo(a, 0, 500, () => a.pause());
}
// boutons du mini lecteur
function musAction(s, act, val) {
  const L = musList(s); if (!L.length) return;
  const st = musState(s), on = musPlaying(s), here = MUS.a && MUS.sid === s.id;
  const pos = here ? { tid: MUS.tid, t: MUS.a.currentTime || 0 } : {};
  if (act === 'restart') { musSave(s.id, { sig: st.sig, tid: L[0].id, t: 0, off: false, done: false, muted: false }); return playMusic(s); }
  if (act === 'toggle') {
    if (on) { musSave(s.id, { ...st, ...pos, off: true }); MUS.a.pause(); return musBtn(s); }
    musSave(s.id, { ...st, ...pos, off: false, muted: false, done: false }); return playMusic(s);
  }
  if (act === 'next') {
    const i = L.findIndex(t => t.id === (here ? MUS.tid : st.tid)); if (i + 1 >= L.length) return;
    musSave(s.id, { ...st, tid: L[i + 1].id, t: 0, off: false, done: false, muted: false }); stopMusic(true); return playMusic(s);
  }
  if (act === 'mute') {
    if (st.muted || !musVol(s)) { if (!musVol(s)) try { localStorage.setItem('vks-mus-vol', String((s.music && s.music.vol) || 0.35)); } catch { } musSave(s.id, { ...st, ...pos, muted: false, off: false }); return playMusic(s); }
    musSave(s.id, { ...st, ...pos, muted: true }); if (here) { clearInterval(MUS.fade); MUS.a.pause(); } return musBtn(s);
  }
  if (act === 'vol') {
    const v = Math.max(0, Math.min(1, val / 100)); try { localStorage.setItem('vks-mus-vol', String(v)); } catch { }
    if (here) { clearInterval(MUS.fade); MUS.a.volume = v; }
    if (v > 0 && st.muted) { musSave(s.id, { ...st, ...pos, muted: false, off: false }); playMusic(s); }
  }
}
// propriétaire : choisir une ou plusieurs musiques (elles s'ajoutent à la fin de la liste)
async function pickMusic(s, then) {
  const f = await VK.pickAudio(); if (!f || (Array.isArray(f) && !f.length)) return;
  const files = Array.isArray(f) ? f : [f];
  toast(files.length > 1 ? `Préparation de ${files.length} musiques…` : 'Préparation de la musique…');
  try {
    const r = await api(`/api/series/${s.id}`, { method: 'POST', body: { musicAdd: files } }); const bad = r.musicBad || []; delete r.musicBad;
    LIB = r; indexLib(); stopMusic(true); render(true); then && then();
    const n = files.length - bad.length;
    toast(bad.length ? `${n} musique${n > 1 ? 's' : ''} ajoutée${n > 1 ? 's' : ''} · illisible${bad.length > 1 ? 's' : ''} : ${bad.join(', ')}` : `${n > 1 ? n + ' musiques ajoutées' : 'Musique ajoutée'} : elles se jouent à la suite quand on ouvre « ${s.name} »${s.eps.some(e => e.cloud) ? ', ici et en ligne' : ''}`, !!bad.length);
  }
  catch (e) { toast(e.message, true); }
}
// propriétaire : liste des musiques de la série, ordre par glisser-déposer, retrait
function openMusic(s0) {
  const sheet = $('#sheet');
  const draw = () => {
    const s = seriesOf(s0.id); if (!s) return;
    const L = musList(s);
    const mm = n => n ? `${Math.floor(n / 60)}:${String(n % 60).padStart(2, '0')}` : '';
    sheet.innerHTML = `<h3>Musiques de fond de « ${esc(s.name)} »</h3>
      <p class="mut">Elles se jouent une seule fois, à la suite, dans cet ordre, quand quelqu'un ouvre la série. Glisse-les pour changer l'ordre. Chaque spectateur peut couper ou relancer la musique ; s'il ne l'a pas coupée, elle reprend là où il en était.</p>
      <div id="musItems">${L.map((t, i) => `<div class="pli musi" data-id="${esc(t.id)}"><span class="grip">${ic('grip')}</span><span class="num">${i + 1}</span><div><b>${esc(t.name || 'Musique ' + (i + 1))}</b><small>${mm(t.dur)}</small></div><button class="btn sm ghost" data-mdel="${esc(t.id)}" title="Retirer cette musique">${ic('x')}</button></div>`).join('') || '<p class="mut">Aucune musique pour l\'instant.</p>'}</div>
      <div class="foot">${VK ? `<button class="btn ghost" id="mAdd">${ic('plus')}Ajouter des musiques</button>` : '<span class="mut">Ajout de musiques : depuis l\'appli sur ton PC</span>'}<span class="grow"></span><button class="btn" id="mOk">${ic('check')}Fermer</button></div>`;
    $('#mOk').onclick = () => { $('#modal').hidden = true; };
    const ma = $('#mAdd'); if (ma) ma.onclick = () => pickMusic(s, draw);
    $$('[data-mdel]').forEach(b => b.onclick = async () => {
      const t = L.find(x => x.id === b.dataset.mdel); if (!confirm(`Retirer « ${t ? t.name : 'cette musique'} » ?`)) return;
      try { LIB = await api(`/api/series/${s.id}`, { method: 'POST', body: { musicDel: b.dataset.mdel } }); indexLib(); stopMusic(true); render(true); draw(); toast('Musique retirée'); } catch (e) { toast(e.message, true); }
    });
    if (window.Sortable && L.length > 1) Sortable.create($('#musItems'), { animation: 150, handle: '.grip', onEnd: async ev => {
      if (ev.oldIndex === ev.newIndex) return;
      const order = $$('#musItems [data-id]').map(x => x.dataset.id);
      try { LIB = await api(`/api/series/${s.id}`, { method: 'POST', body: { musicOrder: order } }); indexLib(); stopMusic(true); render(true); draw(); toast('Ordre des musiques enregistré'); } catch (e) { toast(e.message, true); draw(); }
    } });
  };
  draw(); $('#modal').hidden = false;
}
// « Groq whisper-large-v3 » → « Whisper large-v3 (Groq) », « Gemini gemini-2.5-flash » → « Gemini 2.5 Flash »
function aiName(x) {
  const m = String(x).match(/^(\w+) (.+)$/); if (!m) return x;
  const [, who, model] = m;
  if (/gemini/i.test(model)) return 'Gemini ' + model.replace(/^gemini-/i, '').replace(/-preview.*$/, ' (préversion)').replace(/-/g, ' ').replace(/\b(pro|flash|lite)\b/g, w => w[0].toUpperCase() + w.slice(1));
  if (/whisper/i.test(model)) return 'Whisper ' + model.replace(/^whisper-/i, '') + ' (' + who + ')';
  return model + ' (' + who + ')';
}
/* ---------- rapport de sous-titrage (propriétaire) : vérifier d'un coup d'œil qu'il n'y a eu aucun problème */
const durTxt = ms => { const s = Math.round((ms || 0) / 1000); return s < 60 ? `${s} s` : s < 3600 ? `${Math.round(s / 60)} min` : `${Math.floor(s / 3600)} h ${String(Math.round(s % 3600 / 60)).padStart(2, '0')}`; };
const modelName = m => /^gemini-/.test(m) ? aiName('Gemini ' + m) : /gpt-oss|llama/.test(m) ? aiName('Groq ' + m) : m;
function repStatus(r) {
  const t = r && r.tr; if (!t) return null;
  const issues = [];
  if (t.missing) issues.push(`${t.missing} réplique${t.missing > 1 ? 's' : ''} non traduite${t.missing > 1 ? 's' : ''}`);
  if (!t.analysis) issues.push('analyse de l\'épisode non faite (prénoms et genres moins sûrs)');
  return { ok: !issues.length, issues };
}
function repBadge(e) {
  const st = repStatus(e.ai && e.ai.report); if (!st) return '';
  return `<a href="#" class="repb ${st.ok ? 'ok' : 'bad'}" data-rep="${e.id}" title="Voir le rapport du sous-titrage">${st.ok ? '✅' : '⚠️'} Rapport</a> · `;
}
function openReport(id) {
  const e = EPS.get(id), r = e && e.ai && e.ai.report; if (!r) return toast('Pas de rapport pour cet épisode (sous-titré avant cette version)', true);
  const s = seriesOf(e.sid), st = repStatus(r) || { ok: true, issues: [] }, t = r.tr || {}, a = r.asr || {};
  const lines = Object.entries(t.lines || {}).sort((x, y) => y[1] - x[1]);
  const weak = m => /lite|preview|gpt-oss|llama/.test(m);
  const sheet = $('#sheet');
  sheet.innerHTML = `<h3>📋 Rapport — ${esc(s.name)} ${epCode(e)}</h3>
    <div class="keyrow ${st.ok ? 'ok' : 'bad'}"><div class="grow"><b>${st.ok ? '✅ Aucun problème' : '⚠️ À vérifier'}</b><div class="kday">${st.ok ? `${t.total - (t.missing || 0)}/${t.total} répliques traduites, rien ne manque.` : st.issues.map(esc).join(' · ')}</div></div></div>
    <h4>🎧 Écoute (Groq)</h4>
    <p class="mut">${a.reused ? `Écoute déjà faite avant (réutilisée)${a.model ? ' : ' + esc(a.model) : ''}.` : `${esc(a.model || '?')} · ${a.slices || 0} tranche${a.slices > 1 ? 's' : ''} de 10 min${a.resumed ? ` (reprise à la tranche ${a.resumed + 1}/${a.total})` : ''} · compte${(a.accounts || []).length > 1 ? 's' : ''} Groq utilisé${(a.accounts || []).length > 1 ? 's' : ''} : ${(a.accounts || []).map(n => 'n° ' + n).join(', ') || '?'}${a.nKeys ? ` sur ${a.nKeys}` : ''} · pause${a.waitMs ? ` : ${durTxt(a.waitMs)}` : ' : aucune'}`}</p>
    <h4>🧠 Analyse de l'épisode (prénoms, genres, résumé)</h4>
    <p class="mut">${t.analysis ? esc(/^gemini|gpt|llama/.test(t.analysis) ? modelName(t.analysis) : t.analysis) : '⚠️ non faite'}${t.fixed ? ` · ${t.fixed} erreur${t.fixed > 1 ? 's' : ''} d'écoute corrigée${t.fixed > 1 ? 's' : ''}` : ''}</p>
    <h4>🌍 Traduction : qui a traduit quoi</h4>
    ${lines.map(([m, n]) => `<div class="repl"><span class="grow">${weak(m) ? '⚠️ ' : ''}${esc(/^gemini|gpt|llama/.test(m) ? modelName(m) : m)}</span><b>${n}</b> réplique${n > 1 ? 's' : ''} <i style="width:${Math.max(2, Math.round(100 * n / (t.total || 1)))}px"></i></div>`).join('') || '<p class="mut">—</p>'}
    <p class="mut" style="margin-top:8px">${t.req || 0} demande${t.req > 1 ? 's' : ''} envoyée${t.req > 1 ? 's' : ''}${t.fail ? ` dont ${t.fail} refusée${t.fail > 1 ? 's' : ''} ou sans réponse (${Object.entries(t.err || {}).map(([k, v]) => `${v} ${k}`).join(', ')}) — le relais est passé au suivant` : ', aucune refusée'} · attente : ${t.waitMs ? durTxt(t.waitMs) : 'aucune'}</p>
    <p class="mut">Terminé ${whenDone(r.at)} · durée totale : ${durTxt(r.ms)}. ⚠️ = modèle de secours (Lite, préversion ou Groq) : moins fin que les Flash complets.</p>
    <div class="foot"><span class="grow"></span><button class="btn" id="repOk">Fermer</button></div>`;
  $('#modal').hidden = false;
  $('#repOk').onclick = () => { $('#modal').hidden = true; };
}
document.addEventListener('click', ev => { const a = ev.target.closest && ev.target.closest('[data-rep]'); if (!a) return; ev.preventDefault(); ev.stopPropagation(); openReport(a.dataset.rep); }, true);

// modèle en dessous du meilleur (Lite, préversion, turbo, secours Groq) : signalé par ⚠️
const aiWeak = x => /lite|preview|turbo/i.test(x) || /^Groq (?!whisper)/i.test(x);
function aiLabel(a) {
  if (!a) return '';
  const n = x => (aiWeak(x) ? '⚠️ ' : '') + aiName(x);
  return [a.asr && a.asr.length ? 'Écoute : ' + a.asr.map(n).join(', ') : '', a.tr && a.tr.length ? 'Traduction : ' + a.tr.map(n).join(', ') : ''].filter(Boolean).join(' · ');
}
function epRow(e) {
  const p = prog(e.id), pc = p && p.d ? (p.done ? 100 : p.t / p.d * 100) : 0;
  const bd = [], see = viewer();
  if ((e.missing || e.notOnPc) && !see) bd.push(e.cloud ? '<span class="miss">Plus sur ce PC (lu en ligne)</span>' : '<span class="miss">Fichier introuvable</span>');
  if (p && p.done) bd.push(`<span class="ok">${ic('check')}Vu</span>`);
  if (e.autoFr) bd.push(see ? `<span class="fr">${ic('cc')}FR</span>` : `<span class="fr" title="${esc(aiLabel(e.ai) || 'Outils non enregistrés (sous-titré avant cette version)')}">${ic('cc')}FR (IA)</span>`);
  if (e.pending && !see) bd.push(`<span class="run"><span class="spin"></span>Sous-titrage IA…</span>`);
  if (typeof checkBadge === 'function') { const b = checkBadge(e); if (b) bd.push(b); }
  if (e.cloud && !see) bd.push(`<span class="cl">${ic('cloud')}En ligne</span>`);
  else if (e.upq && !see) bd.push(`<span class="run"><span class="spin"></span>Mise en ligne…</span>`);
  return `<div class="ep" tabindex="0" data-play="${e.id}" data-ctx="ep:${e.id}"><span class="n">${e.e}</span>
    <div class="th" style="background-image:url('${thumb(e.id)}')"><span class="play"><span>${ic('play')}</span></span>${pc ? `<span class="pbar"><i style="width:${pc.toFixed(1)}%"></i></span>` : ''}</div>
    <div class="tx"><b>${esc(e.title || 'Épisode ' + e.e)}</b><small>${epCode(e)}${see ? '' : ' · ' + esc(e.file)}</small>${bd.length ? `<div class="bd">${bd.join('')}</div>` : ''}${e.autoFr && !see ? `<small class="aiinfo">${repBadge(e)}${esc(aiLabel(e.ai) || 'Outils IA non enregistrés (sous-titré avant cette version)')}</small>` : ''}</div>
    <div class="acts"><span class="dur">${fmtDur(e.dur)}</span><button class="ibtn" data-epmenu="${e.id}" title="Plus">${ic('more')}</button></div></div>`;
}
function epMenu(e, x, y) {
  const p = prog(e.id);
  const base = [{ h: epLabel(e) },
    { label: p && p.t > 15 && !p.done ? 'Reprendre' : 'Lire', icon: 'play', act: () => play(e.id) },
    { label: 'Lire depuis le début', icon: 'refresh', act: () => play(e.id, { fromStart: true }) },
    { label: 'Ajouter à une playlist…', icon: 'plus', act: () => pickPlaylist([{ t: 'e', id: e.id }], { getBoundingClientRect: () => ({ left: x, bottom: y }) }) }];
  if (viewer()) return menu(x, y, base);
  menu(x, y, [...base,
    { label: 'Déplacer vers une autre série…', icon: 'folder', act: () => moveMenu(e, x, y) },
    e.autoFr ? { label: 'Refaire les sous-titres IA (réécoute)', icon: 'magic', act: async () => { await api(`/api/auto/${e.id}/delete`, { method: 'POST' }); await autoEnqueue([e.id]); } }
      : { label: e.pending ? 'Sous-titrage en cours…' : 'Créer les sous-titres FR (IA)', icon: 'magic', act: () => !e.pending && autoEnqueue([e.id]) },
    ...(e.hasSrc ? [{ label: 'Retraduire seulement (après correction des noms)', icon: 'refresh', act: () => autoEnqueue([e.id], true) }] : []),
    ...(typeof checkEpItems === 'function' ? checkEpItems(e) : []),
    ...(typeof cloudEpItems === 'function' ? cloudEpItems(e) : []),
    { label: p && p.done ? 'Marquer comme non vu' : 'Marquer comme vu', icon: 'eye', act: async () => { LIB = await api(`/api/ep/${e.id}`, { method: 'POST', body: { seen: !(p && p.done) } }); indexLib(); render(true); } },
    { label: 'Renommer l\'épisode', icon: 'edit', act: async () => { const t = await askText('Renommer l\'épisode', e.title, { ok: 'Renommer' }); if (t == null) return; LIB = await api(`/api/ep/${e.id}`, { method: 'POST', body: { title: t } }); indexLib(); render(true); } },
    ...(VK ? [{ label: 'Afficher le fichier', icon: 'folder', act: () => VK.reveal(e.id) }] : []),
    ...(VK && !e.missing ? [{ label: 'Supprimer la vidéo de ce PC', icon: 'trash', act: () => deleteLocal(e) }] : []),
  ]);
}
const gbTxt = n => (n / 1e9).toFixed(1).replace('.', ',') + ' Go';
// supprimer la vidéo d'un épisode de ce PC (l'épisode reste dans la série, lisible en ligne s'il y est)
async function deleteLocal(e) {
  const on = e.cloudOk;
  const msg = on ? `Supprimer de ce PC la vidéo de « ${epLabel(e)} » (${gbTxt(e.size || 0)}) ?\n\nElle est en ligne : l'épisode reste dans la série et se regarde depuis la version en ligne (sous-titres et reprise gardés).\nLa suppression est définitive (pas de corbeille).`
    : `⚠️ « ${epLabel(e)} » N'EST PAS EN LIGNE.\n\nSi tu supprimes sa vidéo de ce PC (${gbTxt(e.size || 0)}), elle sera perdue : plus personne ne pourra la regarder.\nLa suppression est définitive (pas de corbeille).\n\nSupprimer quand même ?`;
  if (!confirm(msg)) return;
  try { const r = await api(`/api/ep/${e.id}/deletefile`, { method: 'POST', body: { force: !on } }); LIB = r.lib; indexLib(); render(true); toast(`Vidéo supprimée : ${gbTxt(r.bytes || 0)} libérés`); }
  catch (er) { toast(er.message, true); }
}
// nettoyer une série : supprimer de ce PC toutes les vidéos déjà en ligne
async function cleanSeries(s) {
  const eps = s.eps.filter(e => !e.missing && e.cloudOk), size = eps.reduce((t, e) => t + (e.size || 0), 0), notOn = s.eps.filter(e => !e.missing && !e.cloudOk).length;
  if (!eps.length) return toast(notOn ? `Aucune vidéo de cette série n'est encore en ligne : rien à supprimer sans risque (${notOn} vidéo${notOn > 1 ? 's' : ''} seulement sur ce PC)` : 'Aucune vidéo de cette série sur ce PC', !!notOn);
  if (!confirm(`Libérer ${gbTxt(size)} : supprimer de ce PC les ${eps.length} vidéo${eps.length > 1 ? 's' : ''} de « ${s.name} » déjà en ligne ?\n\nLes épisodes restent dans la série et se regardent depuis la version en ligne (sous-titres et reprises gardés).${notOn ? `\n${notOn} vidéo${notOn > 1 ? 's' : ''} pas encore en ligne ${notOn > 1 ? 'sont gardées' : 'est gardée'}.` : ''}\nLa suppression est définitive (pas de corbeille).`)) return;
  try { const r = await api(`/api/series/${s.id}/clean`, { method: 'POST', body: {} }); LIB = r.lib; indexLib(); render(true); toast(`${r.n} vidéo${r.n > 1 ? 's' : ''} supprimée${r.n > 1 ? 's' : ''} : ${gbTxt(r.bytes || 0)} libérés${r.skipped ? ` (${r.skipped} en cours de travail, gardée${r.skipped > 1 ? 's' : ''})` : ''}`); }
  catch (er) { toast(er.message, true); }
}
function seriesMenu(s, el) {
  if (viewer()) return;
  const r = el.getBoundingClientRect();
  menu(r.left, r.bottom + 6, [
    { label: `Noms propres (${(s.glossary || []).length})`, icon: 'list', act: () => openGlossary(s) },
    { label: `Saisons… (${new Set(s.eps.map(e => e.s)).size})`, icon: 'list', act: () => openSeasons(s) },
    ...(VK && s.eps.some(e => !e.missing && e.cloudOk) ? [{ label: `🧹 Libérer de la place (${gbTxt(s.eps.filter(e => !e.missing && e.cloudOk).reduce((t, e) => t + (e.size || 0), 0))} déjà en ligne)`, icon: 'trash', act: () => cleanSeries(s) }] : []),
    { label: s.soon ? 'Retirer de « Bientôt disponible » (ouvrir à tous)' : 'Mettre dans « Bientôt disponible »', icon: 'eye', act: async () => {
      try { LIB = await api(`/api/series/${s.id}`, { method: 'POST', body: { soon: !s.soon } }); indexLib(); render(true); toast(s.soon ? `« ${s.name} » est ouverte à tous ✓` : `« ${s.name} » est dans « Bientôt disponible » : tout le monde la voit, ses épisodes restent réservés à ton compte`); } catch (e) { toast(e.message, true); }
    } },
    { label: 'Renommer la série', icon: 'edit', act: async () => { const n = await askText('Renommer la série', s.name, { ok: 'Renommer', placeholder: 'ex : Kara Sevda' }); if (!n || !n.trim()) return; LIB = await api(`/api/series/${s.id}`, { method: 'POST', body: { name: n } }); indexLib(); render(true); } },
    ...(musList(s).length ? [{ label: `Musiques de fond (${musList(s).length}) : ordre, retrait`, icon: 'music', act: () => openMusic(s) }] : []),
    ...(VK ? [{ label: musList(s).length ? 'Ajouter des musiques de fond' : 'Ajouter une ou plusieurs musiques de fond', icon: 'plus', act: () => pickMusic(s) }] : []),
    ...(imgList(s).length ? [{ label: `Images de la série (${imgList(s).length}) : ordre, retrait`, icon: 'image', act: () => openImages(s) }] : []),
    ...(VK ? [{ label: imgList(s).length ? 'Ajouter des images' : 'Ajouter une ou plusieurs images', icon: 'plus', act: () => pickImages(s) }] : []),
    ...(s.cover ? [{ label: 'Image automatique', icon: 'image', act: async () => { LIB = await api(`/api/series/${s.id}`, { method: 'POST', body: { cover: null } }); indexLib(); render(true); } }] : []),
    ...(typeof cloudSeriesItems === 'function' ? cloudSeriesItems(s) : []),
    { label: 'Rechercher de nouveaux épisodes', icon: 'refresh', act: async () => { const before = s.eps.length; LIB = await api(`/api/series/${s.id}`, { method: 'POST', body: { rescan: true } }); indexLib(); const n = seriesOf(s.id).eps.length - before; toast(n > 0 ? `${n} nouvel${n > 1 ? 's' : ''} épisode${n > 1 ? 's' : ''}` : 'Aucun nouvel épisode'); render(true); } },
    ...(VK ? [{ label: 'Ajouter des épisodes à cette série…', icon: 'plus', act: () => addEpisodesTo(s) }] : []),
    '-',
    { label: 'Retirer de VDIZI', icon: 'trash', act: async () => { if (!confirm(`Retirer « ${s.name} » de VDIZI ?\n\nTes fichiers vidéo ne sont PAS supprimés de ton PC.`)) return; LIB = await api(`/api/series/${s.id}`, { method: 'DELETE' }); indexLib(); location.hash = '#/'; render(); toast('Série retirée (fichiers conservés sur ton PC)'); } },
  ]);
}
function autoMenu(s, season, el) {
  if (viewer()) return;
  const r = el.getBoundingClientRect();
  const missing = list => list.filter(e => !e.autoFr && !e.pending && (!e.missing || e.cloud)).map(e => e.id);
  const all = missing(s.eps), inSeason = season == null ? all : missing(s.eps.filter(e => e.s === season));
  menu(r.left, r.bottom + 6, [{ h: 'Sous-titres français par IA' },
    ...(season == null ? [] : [{ label: `Cette saison (${inSeason.length} épisode${inSeason.length > 1 ? 's' : ''})`, icon: 'magic', act: () => inSeason.length ? autoEnqueue(inSeason) : toast('Tous les épisodes de cette saison sont déjà sous-titrés') }]),
    { label: `Toute la série (${all.length} épisode${all.length > 1 ? 's' : ''})`, icon: 'magic', act: () => all.length ? autoEnqueue(all) : toast('Tous les épisodes sont déjà sous-titrés') },
    { label: `🏆 Qualité maximale : meilleur modèle seulement (${inSeason.length > 0 && inSeason.length !== all.length ? 'cette saison' : 'toute la série'})…`, icon: 'magic', act: () => { const ids = inSeason.length ? inSeason : all; ids.length ? openBest(ids) : toast('Tous les épisodes sont déjà sous-titrés'); } },
    { label: 'Voir l\'avancement', icon: 'list', act: () => { location.hash = '#/auto'; } },
    ...(typeof checkSeriesItems === 'function' ? checkSeriesItems(s, season) : []),
    '-', { label: `Noms propres de la série (${(s.glossary || []).length})`, icon: 'edit', act: () => openGlossary(s) },
  ]);
}

/* ---------- playlists */
function renderPlaylists() {
  view.innerHTML = `<div class="page"><div class="ph"><h1>${esc(label('playlists'))}</h1><span class="grow"></span><button class="btn" id="npl">${ic('plus')}Nouvelle playlist</button></div>
    ${LIB.playlists.length ? `<div class="grid">${LIB.playlists.map(playlistCard).join('')}</div>` : '<p style="color:#999;font-size:16px">Crée tes propres listes de lecture : des séries entières ou seulement certains épisodes, de n\'importe quelle série. Elles se lisent à la suite, dans l\'ordre que tu choisis.</p>'}</div>`;
  $('#npl').onclick = () => newPlaylist();
}
function renderPlaylist() {
  const pl = LIB.playlists.find(p => p.id === route.id); if (!pl) { location.hash = '#/playlists'; return; }
  const eps = playlistEps(pl), tot = eps.reduce((a, e) => a + (e.dur || 0), 0);
  const first = eps.find(e => !(prog(e.id) || {}).done) || eps[0];
  view.innerHTML = `<div class="page"><div class="ph"><h1>${esc(pl.name)}</h1><span style="color:#999">${eps.length} épisode${eps.length > 1 ? 's' : ''}${tot ? ' · ' + fmtDur(tot) : ''}</span></div>
    <div style="display:flex;gap:10px;margin-bottom:22px;flex-wrap:wrap">
      ${eps.length ? `<button class="btn white big" id="plPlay">${ic('play')}${first && prog(first.id) ? 'Continuer' : 'Tout lire'}</button><button class="btn ghost big" id="plShuf">${ic('shuffle')}Aléatoire</button>` : ''}
      <button class="btn big" id="plAdd">${ic('plus')}Ajouter des séries ou des épisodes</button><button class="btn ghost big" id="plRen">${ic('edit')}Renommer</button><button class="btn ghost big" id="plDel">${ic('trash')}Supprimer</button></div>
    <div id="plItems">${pl.items.map((it, i) => {
      if (it.t === 'e') { const e = EPS.get(it.id); if (!e) return ''; const s = seriesOf(e.sid); return `<div class="pli" data-i="${i}"><span class="grip">${ic('grip')}</span><div class="th" style="background-image:url('${thumb(e.id)}')"></div><div><b>${esc(s.name)}</b><small>${esc(epLabel(e))} · ${fmtDur(e.dur)}</small></div><div><button class="ibtn" data-pplay="${e.id}" title="Lire">${ic('play')}</button><button class="ibtn" data-prm="${i}" title="Retirer">${ic('x')}</button></div></div>`; }
      const s = seriesOf(it.id); if (!s) return '';
      return `<div class="pli" data-i="${i}"><span class="grip">${ic('grip')}</span><div class="th" style="background-image:url('${cover(s)}')"></div><div><b>${esc(s.name)}</b><small>Série entière · ${s.eps.length} épisodes</small></div><div><button class="ibtn" data-pplay="${s.eps[0] ? s.eps[0].id : ''}" title="Lire">${ic('play')}</button><button class="ibtn" data-prm="${i}" title="Retirer">${ic('x')}</button></div></div>`;
    }).join('') || '<p style="color:#999">Playlist vide : clique sur « Ajouter des séries ou des épisodes ».</p>'}</div></div>`;
  if (eps.length) {
    $('#plPlay').onclick = () => play(first.id, { queue: eps.map(e => e.id), queueName: pl.name });
    $('#plShuf').onclick = () => { const q = eps.map(e => e.id).sort(() => Math.random() - .5); play(q[0], { queue: q, queueName: pl.name + ' (aléatoire)', fromStart: true }); };
  }
  $('#plAdd').onclick = () => playlistPicker(pl);
  $('#plRen').onclick = async () => { const n = await askText('Renommer la playlist', pl.name, { ok: 'Renommer' }); if (n && n.trim()) { pl.name = n.trim(); savePlaylists(); render(true); } };
  $('#plDel').onclick = () => { if (confirm(`Supprimer la playlist « ${pl.name} » ?\n(Les séries et fichiers ne sont pas touchés.)`)) { LIB.playlists = LIB.playlists.filter(x => x !== pl); savePlaylists(); location.hash = '#/playlists'; } };
  $$('[data-prm]').forEach(b => b.onclick = ev => { ev.stopPropagation(); pl.items.splice(+b.dataset.prm, 1); savePlaylists(); render(true); });
  $$('[data-pplay]').forEach(b => b.onclick = ev => { ev.stopPropagation(); play(b.dataset.pplay, { queue: eps.map(e => e.id), queueName: pl.name }); });
  if (window.Sortable && pl.items.length > 1) Sortable.create($('#plItems'), { animation: 150, handle: '.grip', onEnd: ev => { if (ev.oldIndex === ev.newIndex) return; const [m] = pl.items.splice(ev.oldIndex, 1); pl.items.splice(ev.newIndex, 0, m); savePlaylists(); render(true); } });
}
// choisir dans tout le catalogue : une série entière ou un épisode précis
function playlistPicker(pl) {
  const sh = $('#sheet'); sh.dataset.k = 'plpick';
  const has = (t, id) => pl.items.some(x => x.t === t && x.id === id);
  const draw = () => {
    const q = norm($('#ppQ')?.value || ''), box = $('#ppL');
    box.innerHTML = LIB.series.map(s => {
      const eps = s.eps.filter(e => !e.missing || e.cloud), hit = !q || norm(s.name).includes(q), list = q && !hit ? eps.filter(e => norm(epLabel(e)).includes(q)) : eps;
      if (!list.length) return '';
      return `<div class="pp-s"><div class="pp-r"><b>${esc(s.name)}</b><small>${eps.length} épisode${eps.length > 1 ? 's' : ''}</small><button class="btn sm${has('s', s.id) ? ' ghost' : ''}" data-pt="s" data-pid="${s.id}">${has('s', s.id) ? ic('check') + 'Ajoutée' : ic('plus') + 'Toute la série'}</button></div>
        ${list.map(e => `<div class="pp-r ep1"><span>${esc(epLabel(e))}</span><button class="ibtn" data-pt="e" data-pid="${e.id}" title="Ajouter cet épisode">${ic(has('e', e.id) ? 'check' : 'plus')}</button></div>`).join('')}</div>`;
    }).join('') || '<p style="color:#999">Rien trouvé.</p>';
    $$('[data-pt]', box).forEach(b => b.onclick = () => {
      const t = b.dataset.pt, id = b.dataset.pid, i = pl.items.findIndex(x => x.t === t && x.id === id);
      if (i >= 0) pl.items.splice(i, 1); else pl.items.push({ t, id });
      savePlaylists(); draw();
    });
  };
  sh.innerHTML = `<h3>Ajouter à « ${esc(pl.name)} »</h3><input id="ppQ" class="pp-q" placeholder="Chercher une série ou un épisode…" autocomplete="off"><div id="ppL" class="pp-l"></div><div class="foot"><button class="btn" id="ppOk">Terminé</button></div>`;
  $('#ppQ').oninput = draw;
  $('#ppOk').onclick = () => { $('#modal').hidden = true; render(true); };
  draw(); $('#modal').hidden = false; $('#ppQ').focus();
}
async function newPlaylist(items) {
  const n = await askText('Nouvelle playlist', '', { ok: 'Créer', placeholder: 'ex : Soirée séries, À regarder' });
  if (!n || !n.trim()) return null;
  const pl = { id: uid(), name: n.trim(), items: items || [] };
  LIB.playlists.push(pl); savePlaylists();
  if (items) toast(`Ajouté à « ${pl.name} »`); else location.hash = '#/p/' + pl.id;
  render(true);
  return pl;
}
function pickPlaylist(items, el) {
  const r = el.getBoundingClientRect();
  const add = pl => {
    let n = 0;
    for (const it of items) if (!pl.items.some(x => x.t === it.t && x.id === it.id)) { pl.items.push(it); n++; }
    savePlaylists(); toast(n ? `Ajouté à « ${pl.name} »` : `Déjà dans « ${pl.name} »`);
  };
  menu(r.left, r.bottom + 6, [{ h: 'Ajouter à…' }, ...LIB.playlists.map(pl => ({ label: pl.name, icon: 'list', act: () => add(pl) })), '-', { label: 'Nouvelle playlist…', icon: 'plus', act: () => newPlaylist(items) }]);
}

/* ---------- sous-titres automatiques */
function fmtWait(ms) { const m = Math.max(1, Math.round(ms / 60e3)); return m < 60 ? m + ' min' : Math.floor(m / 60) + ' h' + (m % 60 ? ' ' + String(m % 60).padStart(2, '0') : ''); }
async function openBest(ids, retranslate) {
  const sheet = $('#sheet');
  sheet.innerHTML = '<h3>🏆 Qualité maximale</h3><p class="mut">Calcul de la durée et du prix…</p>'; $('#modal').hidden = false;
  let r; try { r = await api('/api/auto/estimate', { method: 'POST', body: { ids } }); } catch (e) { sheet.innerHTML = `<h3>🏆 Qualité maximale</h3><p class="kres bad">❌ ${esc(e.message)}</p><div class="foot"><span class="grow"></span><button class="btn" onclick="document.getElementById('modal').hidden=true">Fermer</button></div>`; return; }
  const n = ids.length, lines = r.eps.reduce((a, e) => a + e.lines, 0), guess = r.eps.some(e => !e.known);
  const day = d => new Date(d).toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' }), hm = d => new Date(d).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  const today = new Date(r.finishAt).toDateString() === new Date().toDateString();
  const when = r.days ? `<b>${day(r.finishAt)} vers ${hm(r.finishAt)}</b> : il manque ${r.req - r.free} demande${r.req - r.free > 1 ? 's' : ''} au quota gratuit d'aujourd'hui, la suite se fait après la remise à zéro de 9 h (${r.days > 1 ? r.days + ' remises à zéro' : 'une seule'})` : `<b>${today ? 'aujourd\'hui' : day(r.finishAt)} vers ${hm(r.finishAt)}</b> (environ ${fmtWait(r.workMs)} de travail)`;
  const usd = v => v.toFixed(2).replace('.', ',') + ' $';
  sheet.innerHTML = `<h3>🏆 Qualité maximale : ${esc(aiName ? aiName('Gemini ' + r.model) : r.model)} seulement</h3>
    <p class="mut">Tout l'épisode est traduit par le meilleur modèle, sans relais vers Flash-Lite ni Groq. S'il atteint sa limite gratuite, l'épisode attend (sa sauvegarde est gardée) et reprend tout seul après la remise à zéro de 9 h. Les autres lancements restent sur le réglage habituel.</p>
    <div class="note" style="line-height:1.7">
      • ${n} épisode${n > 1 ? 's' : ''} · ${guess ? 'environ ' : ''}${lines.toLocaleString('fr-FR')} répliques · environ <b>${r.req} demandes</b> à ${esc(r.model)}<br>
      • Quota gratuit : <b>${r.free}</b> demande${r.free > 1 ? 's' : ''} encore disponible${r.free > 1 ? 's' : ''} aujourd'hui sur ${r.keys} compte${r.keys > 1 ? 's' : ''} Gemini (${r.perDay} par jour en tout)<br>
      • Fin estimée en gratuit : ${when}<br>
      • En payant (facturation activée sur un projet Google) : environ <b>${usd(r.cost)}</b> en tout, soit ${usd(r.cost / n)} par épisode${r.costAfter2026 ? ` (${usd(r.costAfter2026)} après le 31/12/2026 : ${esc(r.priceNote)})` : ''} — sans attente.
      <br><small class="mut">Prix calculé avec ${r.measured ? 'la consommation réelle de tes épisodes' : 'une consommation moyenne'} (~${Math.round(r.avgIn / 1000)} k tokens lus et ${Math.round(r.avgOut / 1000)} k écrits par demande, réflexion comprise). Attention : une fois la facturation activée sur un projet Google, toutes ses demandes sont payantes (plus de quota gratuit sur ce projet).</small>
    </div>
    <div class="foot"><button class="btn ghost" id="bNorm">Lancer normalement</button><span class="grow"></span><button class="btn ghost" id="bNo">Annuler</button><button class="btn" id="bGo">🏆 Lancer en qualité maximale</button></div>`;
  $('#bNo').onclick = () => { $('#modal').hidden = true; };
  $('#bNorm').onclick = () => { $('#modal').hidden = true; autoEnqueue(ids, retranslate); };
  $('#bGo').onclick = () => { $('#modal').hidden = true; autoEnqueue(ids, retranslate, 'best'); };
}
async function autoEnqueue(ids, retranslate, mode) {
  if (viewer()) return;
  try {
    if (!JOBS.keys || !JOBS.keys.groq) { try { JOBS = await api('/api/jobs'); } catch { } }
    if (!JOBS.keys || !JOBS.keys.groq) return openKeys(() => autoEnqueue(ids, retranslate, mode));
    const r = await api('/api/auto', { method: 'POST', body: { ids, retranslate: !!retranslate, mode: mode || '' } });
    JOBS = r.jobs;
    toast(r.added ? (retranslate ? `Retraduction de ${r.added} épisode${r.added > 1 ? 's' : ''}` : `${r.added} épisode${r.added > 1 ? 's' : ''} ajouté${r.added > 1 ? 's' : ''} au sous-titrage IA (~2-3 min par épisode)`) : 'Déjà en cours ou déjà sous-titré', false, { label: 'Voir', fn: () => { location.hash = '#/auto'; } });
    await loadLib(); render(true); pollJobs(true);
  } catch (e) { toast(e.message, true); }
}
let jobT = 0, lastJobSig = '';
async function pollJobs(force) {
  clearTimeout(jobT);
  try {
    const j = await api('/api/jobs'); JOBS = j;
    try { CHECKS = await api('/api/checks'); } catch { }
    const cbusy = !!(CHECKS.cur || CHECKS.queue.length);
    const busy = !!(j.cur || j.queue.length) || cbusy;
    const b = $('#jobBtn'); b.hidden = !busy;
    $('#navAuto').hidden = typeof isGuest === 'function' && isGuest();
    if (busy) {
      const c = j.cur;
      b.innerHTML = c || j.queue.length ? `<span class="spin"></span>${c ? `Sous-titres ${Math.round((c.p || 0) * 100)} %${(j.curs || []).length > 1 ? ` (+${j.curs.length - 1})` : ''}` : 'Sous-titres…'}${j.queue.length ? ` · ${j.queue.length} en attente` : ''}`
        : `<span class="spin"></span>Vérification ${CHECKS.cur ? Math.round((CHECKS.cur.p || 0) * 100) + ' %' : '…'}${CHECKS.queue.length ? ` · ${CHECKS.queue.length} en attente` : ''}`;
    }
    const sig = JSON.stringify([j.done.map(d => d.id + d.ok), j.queue, (j.curs || []).map(x => x.id).join() || (j.cur && j.cur.id), CHECKS.done.map(d => d.id + d.at), CHECKS.queue, CHECKS.cur && CHECKS.cur.id]);
    if (sig !== lastJobSig) {
      if (lastJobSig && typeof checkToast === 'function') checkToast(JSON.parse(lastJobSig)[3] || []);
      if (lastJobSig) { const d = j.done[0]; if (d && !JSON.parse(lastJobSig)[0].includes(d.id + d.ok)) { const e = EPS.get(d.id); toast(d.ok ? `Sous-titres prêts : ${e ? seriesOf(e.sid).name + ' ' + epCode(e) : ''}${d.msg ? ' (' + d.msg + ')' : ''}` : `Sous-titres impossibles : ${d.msg}`, !d.ok); } }
      lastJobSig = sig; await loadLib();
      if (!$('#player').hidden) { refreshPlayerSubs(); } else render(true);
    } else if (route.name === 'auto' && $('#player').hidden) renderAuto(true);
    jobT = setTimeout(pollJobs, busy || force ? 1500 : 8000);
  } catch { jobT = setTimeout(pollJobs, 5000); }
}
$('#jobBtn').onclick = () => { location.hash = '#/auto'; };
// « aujourd'hui 21:14 », « hier 21:14 », « 3 nov. 21:14 »
function whenDone(at) {
  const d = new Date(at), day = x => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime(), n = Math.round((day(new Date()) - day(d)) / 864e5);
  const h = d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  return `${n === 0 ? "aujourd'hui" : n === 1 ? 'hier' : d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })} ${h}`;
}
let ARCH_OPEN = false; // bloc Archives ouvert ou fermé (gardé pendant les rafraîchissements)
let AUTO_PRESS = 0; // dernier appui (souris / doigt) sur la page : on ne la redessine pas en plein clic
document.addEventListener('pointerdown', () => { AUTO_PRESS = Date.now(); }, true);
// Disponibilité des modèles en direct : quand traduire (surtout avec le meilleur modèle) et pour combien d'épisodes
function availHTML(v) {
  const hm = t => new Date(t).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  const until = t => { const m = Math.max(1, Math.round((t - Date.now()) / 60e3)); return m < 60 ? m + ' min' : Math.floor(m / 60) + ' h ' + String(m % 60).padStart(2, '0'); };
  const name = m => typeof aiName === 'function' ? aiName('Gemini ' + m) : m;
  const rows = v.gemini.map(m => {
    const st = m.available ? `<span class="av ok">✅ Disponible</span>` : `<span class="av off">⏸ ${esc((m.accts.find(x => x.why) || {}).why || 'limite du jour atteinte')}</span> · de nouveau disponible à <b>${hm(m.nextFree || v.resetAt)}</b> (dans ${until(m.nextFree || v.resetAt)})`;
    const qty = m.left == null ? '<small class="mut">limite non communiquée par Google</small>' : `<b>${m.left}</b> demande${m.left > 1 ? 's' : ''} restante${m.left > 1 ? 's' : ''} · ≈ <b>${m.episodes}</b> épisode${m.episodes > 1 ? 's' : ''}${m.best ? ' en qualité maximale' : ''}`;
    const acc = m.accts.map(x => `<span class="avk${x.pausedUntil || x.left === 0 ? ' off' : ''}" title="${x.why ? esc(x.why) : ''}">compte ${x.n} : ${x.left === 0 ? 'épuisé' : x.pausedUntil ? 'en pause' : `${x.used}/${x.limit ?? '?'}`}</span>`).join('');
    return `<div class="avrow${m.best ? ' best' : ''}"><div><b>${m.best ? '★ ' : ''}${esc(name(m.model))}</b>${m.best ? ' <small class="mut">(meilleur)</small>' : ''}</div><div>${st}</div><div>${qty}</div><div class="avks">${acc}</div></div>`;
  }).join('');
  const g = v.groq, gh = g.reduce((s, x) => s + x.episodesHour, 0), gd = g.reduce((s, x) => s + x.episodesDay, 0);
  return `<div class="jobcard"><div style="display:flex;align-items:baseline;gap:10px;flex-wrap:wrap"><b class="grow">Disponibilité des modèles (en direct)</b><small class="mut">remise à zéro à <b>${hm(v.resetAt)}</b> (dans ${until(v.resetAt)})</small></div>
    ${rows}
    ${g.length ? `<div class="avrow"><div><b>Écoute (Groq, ${g.length} compte${g.length > 1 ? 's' : ''})</b></div><div>${gh > 0 ? '<span class="av ok">✅ Disponible</span>' : '<span class="av off">⏸ limite de l\'heure atteinte</span>'}</div><div>≈ <b>${Math.round(gh * 10) / 10}</b> épisode${gh >= 2 ? 's' : ''} dans l'heure · ≈ ${gd} aujourd'hui</div><div></div></div>` : ''}
    <small class="mut">Compté par VDIZI (les demandes faites avec tes clés en dehors de VDIZI ne sont pas comptées). 1 épisode ≈ ${14} demandes au modèle de traduction.</small></div>`;
}
let AVAIL_HTML = ''; // dernier affichage (évite un clignotement à chaque rafraîchissement)
function loadAvail() { api('/api/ai/availability').then(v => { if (v && !v.error) { AVAIL_HTML = availHTML(v); const b = $('#availBox'); if (b) b.innerHTML = AVAIL_HTML; } }).catch(() => { }); }
async function renderAuto(soft) {
  const j = JOBS, c = j.cur, keys = j.keys || {};
  let store = null; try { store = await api('/api/storage'); } catch { }

  const name = id => { const e = EPS.get(id); return e ? `${seriesOf(e.sid).name} — ${epLabel(e)}` : id; };
  const html = `<div class="page" style="max-width:900px"><div class="ph"><h1>${esc(label('auto'))}</h1></div>
    ${j.pcOff ? '<div class="jobcard"><b>Ton PC est éteint</b><small>Les travaux se font sur le PC : ouvre VDIZI dessus pour les voir ici.</small></div>' : ''}
    <p style="color:#aaa;margin-top:-8px">L'audio de l'épisode est écouté par l'IA Whisper (Groq), puis Gemini traduit tout l'épisode en français en gardant le contexte et les mêmes noms propres d'un épisode à l'autre. Compte environ 2 à 3 minutes par épisode, même d'une heure. Tu peux continuer à utiliser l'appli pendant ce temps.</p>
    <div class="jobcard" style="display:flex;align-items:center;gap:14px"><div class="grow"><b>Connexion IA</b><small>Écoute (Groq) : ${keys.groq ? '✅ connectée' : '❌ à configurer'} · Traduction (Gemini) : ${keys.gemini ? '✅ connectée' : keys.groq ? '⚠️ non configurée (traduction de secours moins bonne)' : '❌ à configurer'}</small></div><button class="btn sm${keys.groq && keys.gemini ? ' ghost' : ''}" id="goKeys">${keys.groq ? 'Modifier' : 'Configurer (2 min)'}</button></div>
    ${viewer() ? '' : `<div id="availBox">${AVAIL_HTML || '<div class="jobcard"><b>Disponibilité des modèles (en direct)</b><small class="mut"> · chargement…</small></div>'}</div>`}
    <div class="jobcard" style="display:flex;align-items:center;gap:12px;flex-wrap:wrap"><div class="grow"><b>Travaux en même temps</b><small>Plus vite à plusieurs, mais les clés IA saturent plus vite. Deux épisodes d'une même série passent toujours l'un après l'autre (les prénoms appris dans l'un servent au suivant).</small></div><div class="seg" id="parSeg">${[1, 2, 3].map(n => `<button data-par="${n}" class="${(j.parallel || 2) === n ? 'on' : ''}">${n}</button>`).join('')}</div></div>
    ${(j.curs || (c ? [c] : [])).map(c => `<div class="jobcard"><b>${esc(name(c.id))}${c.mode === 'best' ? ' <span class="tag best">🏆 meilleur modèle seulement</span>' : ''}</b>${c.anEnd ? `<div class="antimer" data-anstart="${c.anStart}" data-anend="${c.anEnd}"></div>` : ''}<small>${esc(c.phase || '')}${c.lang ? ` · langue : ${esc(LANGS[c.lang] || c.lang)}` : ''} · ${Math.round((c.p || 0) * 100)} %${c.p > 0.03 ? ` · environ ${fmtDur(Math.max(60, (Date.now() - c.started) / 1000 / c.p * (1 - c.p)))} restantes` : ''}${c.warn ? ` · ${esc(c.warn)}` : ''}</small><div class="pbar"><i style="width:${((c.p || 0) * 100).toFixed(1)}%"></i></div><div style="margin-top:10px"><button class="btn sm danger" data-cancel="${c.id}">Annuler</button></div></div>`).join('') || (!j.queue.length ? '<div class="jobcard"><b>Aucun sous-titrage en cours</b><small>Lance-le depuis la page d\'une série (bouton « Sous-titres FR auto ») ou depuis le lecteur (bouton sous-titres).</small></div>' : '')}
    ${j.queue.length ? `<h3>En attente</h3>${j.queue.map(id => `<div class="jl"><span class="grow">${esc(name(id))}${(j.modes || {})[id] === 'best' ? ' <span class="tag best">🏆 meilleur modèle</span>' : ''}</span><button class="btn sm ghost" data-cancel="${id}">Retirer</button></div>`).join('')}` : ''}
    ${j.done.length ? `<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:26px"><h3 style="margin:0" class="grow">Terminés récemment</h3>${j.done.filter(d => !d.ok).length ? `<button class="btn sm ghost" data-arch="failed">Archiver les échecs (${j.done.filter(d => !d.ok).length})</button>` : ''}<button class="btn sm ghost" data-arch="all">Tout archiver (${j.done.length})</button></div>${j.done.map(d => `<div class="jl jd ${d.ok ? '' : 'bad'}"><span class="ji">${d.ok ? '✅' : '⚠️'}</span><div class="grow"><b>${esc(name(d.id))}</b><div class="e">${esc(d.msg || (d.ok ? 'Sous-titres prêts' : 'Échec'))}</div>${d.at ? `<small class="t">${whenDone(d.at)}</small>` : ''}</div><div class="jb">${d.ok ? `<button class="btn sm ghost" data-play="${d.id}">${ic('play')}Voir</button>` : `<button class="btn sm" data-retry="${d.id}">${ic('refresh')}Réessayer</button>`}${d.ok && EPS.get(d.id) && EPS.get(d.id).ai && EPS.get(d.id).ai.report ? `<button class="btn sm ghost" data-rep="${d.id}">📋 Rapport</button>` : ''}<button class="btn sm ghost" data-arch1="${d.id}" data-at="${d.at || 0}">Archiver</button></div></div>`).join('')}` : ''}
    ${(j.archived || []).length ? `<details class="jarch" style="margin-top:26px"${ARCH_OPEN ? ' open' : ''}><summary style="cursor:pointer"><h3 style="display:inline">Archives (${j.archived.length})</h3></summary>${j.archived.map(d => `<div class="jl jd" style="opacity:.75"><span class="ji">${d.ok ? '✅' : '⚠️'}</span><div class="grow"><b>${esc(d.gone ? 'Épisode supprimé' : name(d.id))}</b><div class="e">${esc(d.msg || (d.ok ? 'Sous-titres prêts' : 'Échec'))}</div>${d.at ? `<small class="t">${whenDone(d.at)}</small>` : ''}</div></div>`).join('')}<div style="margin-top:10px"><button class="btn sm ghost" id="archClear">Vider les archives</button></div></details>` : ''}
    ${typeof checksAutoHTML === 'function' ? checksAutoHTML(name) : ''}
    <h3 style="margin-top:30px">Place utilisée sur ton PC</h3>
    <div class="note">Tes vidéos ne sont jamais copiées. VDIZI garde seulement :<br>
    • les sous-titres créés : ${store ? (store.subs / 1024).toFixed(0) + ' Ko' : '…'} (quelques Ko par épisode)<br>
    • les petites images des épisodes : ${store ? (store.thumbs / 1048576).toFixed(1) + ' Mo' : '…'}<br>
    Aucun module IA n'est installé sur ton PC. Pendant la lecture et le sous-titrage, rien n'est écrit sur ton disque (l'audio est préparé en mémoire puis envoyé à l'IA).</div></div>`;
  if (soft && route.name !== 'auto') return;
  // rafraîchissement automatique : jamais juste après un clic (sinon le bouton est remplacé pendant le clic et
  // le clic est perdu — c'était le cas de « Tout archiver »), ni quand rien n'a changé
  if (!viewer()) loadAvail(); // disponibilité des modèles : remise à jour à chaque passage, sans redessiner la page
  if (soft && (Date.now() - AUTO_PRESS < 1500 || html === renderAuto.last)) return;
  renderAuto.last = html;
  view.innerHTML = html;
  $$('[data-cancel]').forEach(b => b.onclick = async () => { JOBS = await api(`/api/auto/${b.dataset.cancel}`, { method: 'DELETE' }); await loadLib(); renderAuto(); });
  $$('[data-par]').forEach(b => b.onclick = async () => { try { await api('/api/settings', { method: 'PUT', body: { parallelJobs: +b.dataset.par } }); LIB.settings.parallelJobs = +b.dataset.par; JOBS = await api('/api/jobs'); toast(`${b.dataset.par} travail${b.dataset.par > 1 ? 'x' : ''} en même temps`); renderAuto(); } catch (e) { toast(e.message, true); } });
  $('#goKeys').onclick = () => openKeys(() => renderAuto());
  const arch = async body => { try { const r = await api('/api/auto/archive', { method: 'POST', body }); JOBS = { ...JOBS, ...r }; if (r.moved) toast(r.moved > 1 ? r.moved + ' travaux archivés' : 'Travail archivé'); renderAuto(); } catch (e) { toast(e.message, true); } };
  $$('[data-arch]').forEach(b => b.onclick = () => arch({ what: b.dataset.arch }));
  $$('[data-arch1]').forEach(b => b.onclick = () => arch({ id: b.dataset.arch1, at: +b.dataset.at }));
  // échec : on relance ; le travail reprend où il en était (écoute et répliques déjà traduites sont gardées)
  $$('[data-retry]').forEach(b => b.onclick = async () => { const e = EPS.get(b.dataset.retry); await autoEnqueue([b.dataset.retry], !!(e && e.autoFr)); JOBS = await api('/api/jobs'); renderAuto(); });
  const det = $('.jarch'); if (det) det.ontoggle = () => { ARCH_OPEN = det.open; };
  const clr = $('#archClear'); if (clr) clr.onclick = async () => { if (!confirm('Vider les archives ? Elles seront supprimées définitivement.')) return; try { JOBS = { ...JOBS, ...await api('/api/auto/archive/clear', { method: 'POST', body: {} }) }; renderAuto(); } catch (e) { toast(e.message, true); } };
  if (typeof bindChecksAuto === 'function') bindChecksAuto();
}

/* ---------- site : télécharger ou installer VDIZI */
if (window.VK_WEB) $('#navDl').hidden = false;
let installEvt = null;
window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); installEvt = e; if (route.name === 'download') renderDownload(); });
window.addEventListener('appinstalled', () => { installEvt = null; toast('VDIZI est installée ✓'); if (route.name === 'download') renderDownload(); });
function renderDownload() {
  const ua = navigator.userAgent, ios = /iPhone|iPad|iPod/.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1), android = /Android/.test(ua), cros = /CrOS/.test(ua), desk = !ios && !android && !cros;
  const inApp = matchMedia('(display-mode: standalone)').matches || navigator.standalone;
  const card = (title, sub, body, on) => `<div class="dl${on ? ' on' : ''}"><div class="dl-h"><b>${title}</b>${on ? '<span>Ton appareil</span>' : ''}</div><small>${sub}</small>${body}</div>`;
  const step = l => `<ol>${l.map(x => `<li>${x}</li>`).join('')}</ol>`;
  const tv = document.documentElement.classList.contains('tv');
  const install = `<button class="btn" data-pwa>${ic('upload')}Télécharger VDIZI</button>`;
  const cards = [
    { on: tv, html: card('Télévision', 'Samsung, LG, Sony et la plupart des TV connectées', step(['Ouvre le navigateur de ta TV.', `Va sur <b>${esc(location.host)}</b> et ajoute la page à tes favoris.`, 'Pilote tout avec les flèches, OK et retour.']), tv) },
    { on: android && !tv, html: card('Android', 'Téléphone, tablette, box TV', `<a class="btn" id="dlApk" href="https://github.com/Vekahaine/vk-apps/tree/main/android" target="_blank" rel="noopener">${ic('upload')}Télécharger l'appli</a>${step(['Ouvre le fichier téléchargé.', 'Si Android le demande, autorise l\'installation pour cette source.', 'Appuie sur Installer.'])}`, android && !tv) },
    { on: ios, html: card('iPhone et iPad', 'Avec Safari, sans passer par l\'App Store', step(['Ouvre ce site dans <b>Safari</b>.', 'Appuie sur le bouton <b>Partager</b>.', 'Choisis <b>Sur l\'écran d\'accueil</b>, puis <b>Ajouter</b>.']), ios) },
    { on: cros && !tv, html: card('Chromebook', 'S\'ouvre dans sa propre fenêtre, avec son icône', install + step(['Ouvre ce site dans <b>Chrome</b>.', 'Clique sur <b>Télécharger VDIZI</b>, ou sur l\'icône d\'installation dans la barre d\'adresse.', 'VDIZI apparaît avec tes applis.']), cros && !tv) },
    { on: desk && !tv, html: card('Ordinateur', 'Windows, Mac, Linux', install + step(['Ouvre ce site avec <b>Chrome</b> ou <b>Edge</b>.', 'Clique sur <b>Télécharger VDIZI</b>, ou sur l\'icône d\'installation dans la barre d\'adresse.', 'VDIZI s\'ouvre dans sa propre fenêtre.']), desk && !tv) },
  ].sort((a, b) => b.on - a.on).map(c => c.html).join('');
  view.innerHTML = `<div class="page" style="max-width:900px"><div class="ph"><h1>${esc(label('download'))}</h1></div>
    <p style="color:#aaa;margin-top:-8px">${inApp ? 'VDIZI est déjà installée sur cet appareil.' : 'Installe VDIZI pour la retrouver avec son icône, sur tous tes appareils. Ton compte reste le même.'}</p><div class="dls">${cards}</div></div>`;
  $$('[data-pwa]').forEach(p => p.onclick = async () => { const ev = installEvt; if (!ev) return toast(inApp ? 'VDIZI est déjà installée ici' : 'Ouvre ce site dans Chrome ou Edge, puis clique sur l\'icône d\'installation dans la barre d\'adresse'); ev.prompt(); await ev.userChoice.catch(() => { }); installEvt = null; renderDownload(); });
  const a = $('#dlApk'); if (a) fetch('https://raw.githubusercontent.com/Vekahaine/vk-apps/main/latest.json?t=' + Date.now(), { cache: 'no-store' }).then(r => r.json()).then(j => { if (j.vkseries_android) a.href = 'https://github.com/Vekahaine/vk-apps/raw/main/' + j.vkseries_android.apk; }).catch(() => { });
}

/* ---------- clics globaux */
document.addEventListener('click', e => {
  const pl = e.target.closest('[data-play]');
  if (pl && !e.target.closest('[data-epmenu],[data-prm],[data-pplay],.p-menu')) { e.preventDefault(); return play(pl.dataset.play); }
  const em = e.target.closest('[data-epmenu]'); if (em) { e.stopPropagation(); const r = em.getBoundingClientRect(); return epMenu(EPS.get(em.dataset.epmenu), r.left - 200, r.bottom + 4); }
  if (e.target.closest('[data-add]')) return addFlow('folders');
});
document.addEventListener('contextmenu', e => {
  const c = e.target.closest('[data-ctx],[data-play]'); if (!c || e.target.closest('#player')) return;
  const id = (c.dataset.ctx || '').startsWith('ep:') ? c.dataset.ctx.slice(3) : c.dataset.play;
  const ep = EPS.get(id); if (!ep) return; e.preventDefault(); epMenu(ep, e.clientX, e.clientY);
});
const ctx = $('#ctx');
function menu(x, y, items) {
  ctx.innerHTML = items.map((it, i) => it === '-' ? '<hr>' : it.h ? `<div class="h">${esc(it.h)}</div>` : `<button data-i="${i}">${ic(it.icon || 'play')}<span>${esc(it.label)}</span></button>`).join('');
  ctx.hidden = false;
  const r = ctx.getBoundingClientRect();
  ctx.style.left = clamp(x, 8, innerWidth - r.width - 8) + 'px'; ctx.style.top = clamp(y, 8, innerHeight - r.height - 8) + 'px';
  ctx.onclick = ev => { const b = ev.target.closest('button'); if (!b) return; ctx.hidden = true; items[+b.dataset.i].act(); };
}
document.addEventListener('pointerdown', e => { if (!ctx.hidden && !ctx.contains(e.target)) ctx.hidden = true; }, true);

/* ---------- ajout de séries */
$('#btnAdd').innerHTML = `${ic('plus')}<span>Ajouter</span>`;
$('#btnAdd').onclick = ev => {
  const r = ev.currentTarget.getBoundingClientRect();
  menu(r.left - 120, r.bottom + 6, [
    { label: 'Un dossier de série…', icon: 'folder', act: () => addFlow('folders') },
    { label: 'Des fichiers vidéo…', icon: 'upload', act: () => addFlow('files') },
    '-',
    { label: 'Nouvelle série vide…', icon: 'plus', act: () => newSeries() },
  ]);
};
async function addFlow(kind) {
  if (viewer()) return;
  let paths = null;
  if (VK) paths = kind === 'files' ? await VK.pickFiles() : await VK.pickFolders();
  else { const p = await askText('Chemin du dossier ou du fichier', '', { placeholder: 'plusieurs chemins : séparés par « | »', ok: 'Ajouter' }); paths = p ? p.split('|').map(x => x.trim()).filter(Boolean) : null; }
  if (paths && paths.length) addPaths(paths);
}
async function addPaths(paths) {
  toast('Recherche des épisodes…');
  try {
    const r = await api('/api/add', { method: 'POST', body: { paths } });
    LIB = r.lib; indexLib();
    if (!r.added.length) return toast('Aucune vidéo trouvée à cet endroit', true);
    const s = seriesOf(r.added[0]);
    toast(r.added.length > 1 ? `${r.added.length} séries ajoutées` : `« ${s.name} » ajoutée : ${s.eps.length} épisode${s.eps.length > 1 ? 's' : ''}`);
    location.hash = r.added.length === 1 ? '#/s/' + s.id : '#/series'; render();
  } catch (e) { toast(e.message, true); }
}
// glisser-déposer
let dragN = 0;
window.addEventListener('dragenter', e => { if ([...(e.dataTransfer?.types || [])].includes('Files')) { dragN++; $('#drop').hidden = false; } });
window.addEventListener('dragleave', () => { if (--dragN <= 0) { dragN = 0; $('#drop').hidden = true; } });
window.addEventListener('dragover', e => e.preventDefault());
window.addEventListener('drop', e => {
  e.preventDefault(); dragN = 0; $('#drop').hidden = true; if (viewer()) return;
  const files = [...(e.dataTransfer?.files || [])];
  const paths = files.map(f => VK ? VK.pathOf(f) : f.path).filter(Boolean);
  if (paths.length) addPaths(paths); else toast('Glisser-déposer disponible dans l\'appli VDIZI', true);
});
$('.d-ic').innerHTML = ic('upload');

/* ---------- recherche, réglages */
$('.s-ic').innerHTML = ic('search');
let qT = 0; $('#q').addEventListener('input', () => { clearTimeout(qT); qT = setTimeout(() => render(), 120); });
$('#q').addEventListener('keydown', e => { if (e.key === 'Escape') { e.target.value = ''; render(); e.target.blur(); } });
$('#btnSet').innerHTML = ic('cog');
$('#btnSet').onclick = () => openSettings();
function openSettings() {
  const st = LIB.settings;
  const sheet = $('#sheet');
  sheet.innerHTML = `<h3>Réglages</h3><p class="mut">S'appliquent à toutes tes séries.</p>
    <div class="tg"><div><b>Épisode suivant automatique</b><small>Enchaîne quand l'épisode se termine</small></div><button class="sw${st.autoNext !== false ? ' on' : ''}" data-k="autoNext"></button></div>
    <div class="tg"><div><b>Sous-titres par défaut</b><small>Quand l'épisode n'est pas en français</small></div><div class="seg" data-seg="subLang"><button data-v="auto">Français si dispo</button><button data-v="off">Désactivés</button></div></div>
    <div class="tg"><div><b>Taille des sous-titres</b><small>Aussi réglable pendant la lecture</small></div><div class="seg" data-seg="subSize"><button data-v="0.8">Petite</button><button data-v="1">Moyenne</button><button data-v="1.3">Grande</button></div></div>
    <div class="tg adm"><div><b>Écoute rapide si Groq est saturé</b><small>Désactivé = qualité maximale : l'appli attend que Groq se libère (limite gratuite : ~2 h d'audio par heure). Activé = continue tout de suite avec un modèle un peu moins précis.</small></div><button class="sw${st.asrTurbo === true ? ' on' : ''}" id="swTurbo"></button></div>
    ${typeof checkSettingsHTML === 'function' ? checkSettingsHTML(st) : ''}
    <div class="tg adm"><div><b>Connexion IA</b><small>Clés gratuites Groq (écoute) et Gemini (traduction)</small></div><button class="btn sm ghost" id="goKeys2">Configurer</button></div>
    <div class="tg adm"><div><b>Sous-titres automatiques</b><small>Avancement, file d'attente, place utilisée</small></div><button class="btn sm ghost" id="goAuto">Ouvrir</button></div>
    <div class="tg adm" id="updRow"><div><b>Version <span id="setVer"></span></b><small id="updTxt">Les mises à jour se font automatiquement</small></div><button class="btn sm" id="updNow">${ic('refresh')}Mettre à jour</button></div>
    <p class="mut" id="verAll" style="text-align:center;font-size:12px;margin:16px 0 0"></p>
    <div class="foot"><button class="btn" id="setOk">Fermer</button></div>`;
  showVer();
  if (typeof fillUpdRow === 'function') fillUpdRow();
  $$('[data-seg]', sheet).forEach(s => $$('button', s).forEach(b => { b.classList.toggle('on', String(st[s.dataset.seg] ?? (s.dataset.seg === 'subSize' ? 1 : 'auto')) === b.dataset.v); b.onclick = () => { st[s.dataset.seg] = s.dataset.seg === 'subSize' ? +b.dataset.v : b.dataset.v; saveSettings(); openSettings(); }; }));
  $$('.sw[data-k]', sheet).forEach(b => b.onclick = () => { st[b.dataset.k] = st[b.dataset.k] === false; saveSettings(); openSettings(); });
  $('#swTurbo').onclick = () => { st.asrTurbo = st.asrTurbo !== true; saveSettings(); openSettings(); };
  $$('.sw[data-ck]', sheet).forEach(b => b.onclick = () => { const k = b.dataset.ck, def = b.dataset.def === '1'; st[k] = !(st[k] ?? def); saveSettings(); openSettings(); });
  $('#goAuto').onclick = () => { $('#modal').hidden = true; location.hash = '#/auto'; };
  $('#goKeys2').onclick = () => openKeys();
  $('#setOk').onclick = () => { $('#modal').hidden = true; };
  $('#modal').hidden = false;
}
$('#modal').addEventListener('pointerdown', e => { if (e.target.id === 'modal') $('#modal').hidden = true; });

/* =====================================================================
   Lecteur
   ===================================================================== */
const player = $('#player'), video = $('#video');
const P = { id: null, info: null, mode: 'direct', base: 0, aud: 0, subKey: 'off', cues: [], subDelay: 0, queue: null, queueName: '', saveT: 0, nextShown: false, hideT: 0 };
const curTime = () => P.mode === 'direct' ? video.currentTime : P.base + (P.jump ? P.jump : video.currentTime);
const hevcOK = () => { try { return MediaSource.isTypeSupported('video/mp4; codecs="hvc1.1.6.L120.90"') || video.canPlayType('video/mp4; codecs="hvc1"') !== ''; } catch { return false; } };

$('#pBack').innerHTML = ic('back'); $('#pBk').innerHTML = ic('bk'); $('#pFw').innerHTML = ic('fw');
$('#pNextBtn').innerHTML = ic('next'); $('#pEps').innerHTML = ic('eps'); $('#pCC').innerHTML = ic('cc');

async function play(id, o = {}) {
  const e = EPS.get(id); if (!e) return;
  ctx.hidden = true;
  // visiteur sans compte : on demande de se connecter avant de lancer l'épisode
  if (window.VK_REMOTE && VK_REMOTE.anon()) {
    if (!await VK_REMOTE.login('Connecte-toi ou crée un compte gratuit pour regarder cet épisode.')) return;
    await loadLib(); render(true); if (typeof pollCloud === 'function') pollCloud();
  }
  // plus sur ce PC mais en ligne : lu dans l'appli depuis la copie en ligne (le serveur du PC s'en charge)
  stopMusic(true);
  if (P.id && P.id !== id) saveProgress();
  P.id = id; P.queue = o.queue || P.queue && P.queue.includes(id) && P.queue || null; P.queueName = o.queue ? o.queueName : P.queue ? P.queueName : '';
  P.nextShown = false; $('#pNext').hidden = true; $('#pMenu').hidden = true;
  const s = seriesOf(e.sid);
  $('#pSeries').textContent = s.name; $('#pEp').textContent = epLabel(e) + (P.queueName ? ` · ${P.queueName}` : '');
  player.hidden = false; document.body.classList.add('playing'); player.focus();
  if (!document.fullscreenElement && o.full !== false) player.requestFullscreen?.().catch(() => { });
  spin(true); msg(null);
  try { P.info = await api(`/api/play/${id}?hevc=${hevcOK() ? 1 : 0}`); }
  catch (err) { spin(false); return msg('Lecture impossible', err.message); }
  P.aud = P.info.defAudio || 0;
  P.mode = P.info.direct && P.aud === 0 ? 'direct' : 'stream';
  const p = prog(id);
  const start = o.at != null ? Math.max(0, o.at - 2) : o.fromStart ? 0 : p && !p.done && p.t > 15 ? p.t - 3 : 0;
  if (start > 0 && o.at == null) toast(`Reprise à ${fmt(start)}`, false, { label: 'Depuis le début', fn: () => seekTo(0) });
  chooseSubs();
  if (window.VkCast && VkCast.active()) { castNow(start); return; } // déjà en diffusion : l'épisode part sur la TV
  await loadAt(start);
}
/* ---------- diffusion sur un autre écran (appli téléphone : Chromecast / Google TV / TV connectée) */
function castMedia(start) {
  const e = EPS.get(P.id), s = seriesOf(e.sid), abs = x => new URL(x, location.href).href;
  return { url: abs(u(`/media/${P.id}`)), type: 'video/mp4', title: `${s.name} · ${epCode(e)}`, subtitle: e.title || '', image: /^https?:/.test(abs(thumb(P.id))) ? abs(thumb(P.id)) : undefined, start: start || 0,
    subs: (P.info.subs || []).filter(x => !x.image).map(x => ({ url: abs(u(`/sub/${P.id}/${x.key}.vtt`)), name: x.label || x.key, lang: x.lang || 'fr', on: x.key === P.subKey })).sort((a, b) => b.on - a.on) };
}
let castSaved = 0;
const castHooks = {
  onStart: () => { video.pause(); player.classList.add('casting'); spin(false); },
  onTime: (t, d) => { if (!P.id || !d || Date.now() - castSaved < 20000) return; castSaved = Date.now(); LIB.progress[P.id] = { t, d, at: Date.now(), done: t > d - Math.min(120, d * 0.05) }; api('/api/progress', { method: 'POST', body: { id: P.id, t, d } }).catch(() => { }); },
  onEnded: () => { if (P.id) api('/api/progress', { method: 'POST', body: { id: P.id, t: P.info.duration || 1, d: P.info.duration || 1 } }).catch(() => { }); const n = nextEp(); if (n && LIB.settings.autoNext !== false) play(n.id); },
  onStop: t => { player.classList.remove('casting'); if (P.id) loadAt(t > 5 ? t : curTime()); },
};
function castNow(start) { castHooks.onStart(); video.removeAttribute('src'); video.load(); VkCast.load(castMedia(start), castHooks); updateUI(); }
$('#pCast').onclick = () => {
  if (!P.id || !window.VkCast) return;
  if (!VkCast.native()) { if (video.remote) video.remote.prompt().catch(e => { if (e && e.name !== 'AbortError') toast('Diffusion impossible depuis ce navigateur', true); }); return; } // site : Chrome s'en charge
  if (VkCast.active()) castNow(curTime()); else VkCast.pick(() => castMedia(curTime()), castHooks);
};
if (window.VkCast && VkCast.native() && window.VK_REMOTE) { $('#pCast').hidden = false; $('#pCast').innerHTML = VkCast.icon; }
else if (window.VkCast && window.VK_WEB && video.remote && video.remote.watchAvailability) { $('#pCast').innerHTML = VkCast.icon; video.remote.watchAvailability(a => { $('#pCast').hidden = !a; }).catch(() => { }); }
async function loadAt(t) {
  spin(true); msg(null);
  P.jump = 0; video.playbackRate = 1; video.style.opacity = '';
  if (P.mode === 'direct') {
    video.src = u(`/media/${P.id}`);
    video.addEventListener('loadedmetadata', () => { if (t) video.currentTime = t; }, { once: true });
  } else {
    let st = t;
    if (t > 0) { try { st = (await api(`/api/seek/${P.id}?t=${t.toFixed(2)}&v=${P.info.vmode}`)).start; } catch { } }
    P.base = st;
    // la conversion démarre sur l'image clé précédente : on avance ensuite au moment exact demandé
    P.jump = t - st > 0.5 ? t - st : 0;
    video.src = u(`/stream/${P.id}?t=${st.toFixed(3)}&a=${P.aud}&v=${P.info.vmode}`);
  }
  video.play().catch(() => { });
  updateUI();
}
async function seekTo(t) {
  t = clamp(t, 0, Math.max(0, (P.info?.duration || 0) - 1));
  if (P.mode === 'direct') { video.currentTime = t; return; }
  const wasPaused = video.paused;
  await loadAt(t);
  if (wasPaused) video.pause();
}
video.addEventListener('error', () => {
  if (!P.id) return;
  if (P.mode === 'direct') { P.mode = 'stream'; return loadAt(video.currentTime || 0); } // format finalement non lisible : conversion à la volée
  if (P.info && P.info.vmode === 'copy-hevc') { P.info.vmode = 'encode'; return loadAt(curTime()); }
  if (P.info && P.info.vmode === 'copy') { P.info.vmode = 'encode'; return loadAt(curTime()); }
  spin(false); msg('Lecture impossible', 'Ce fichier semble endommagé ou dans un format non pris en charge.');
});
video.addEventListener('waiting', () => spin(true));
// avance rapide invisible jusqu'au moment exact (le flux converti n'est pas « déplaçable »)
const tryJump = () => {
  if (!P.jump) return;
  if (video.currentTime >= P.jump - 0.05) { P.jump = 0; video.playbackRate = 1; video.muted = P.wasMuted; video.style.opacity = ''; spin(false); return; }
  if (video.playbackRate !== 16) { P.wasMuted = video.muted; video.muted = true; video.playbackRate = 16; video.style.opacity = '0'; spin(true); }
};
video.addEventListener('timeupdate', tryJump); video.addEventListener('playing', tryJump);
video.addEventListener('playing', () => { spin(false); msg(null); });
video.addEventListener('canplay', () => spin(false));
video.addEventListener('play', updateUI); video.addEventListener('pause', () => { updateUI(); saveProgress(); poke(); });
video.addEventListener('ended', () => { saveProgress(true); onEnded(); });
function spin(on) { $('#pSpin').hidden = !on; }
function msg(t, s) { const m = $('#pMsg'); if (!t) { m.hidden = true; return; } m.hidden = false; m.innerHTML = `<b>${esc(t)}</b><span>${esc(s || '')}</span><button class="btn" onclick="closePlayer()">Retour</button>`; }

function saveProgress(ended) {
  if (!P.id || !P.info) return;
  const t = ended ? P.info.duration : curTime();
  if (!t) return;
  LIB.progress[P.id] = { t, d: P.info.duration, at: Date.now(), done: ended || t > P.info.duration - Math.min(120, P.info.duration * 0.05) };
  api('/api/progress', { method: 'POST', body: { id: P.id, t, d: P.info.duration } }).catch(() => { });
}
setInterval(() => { if (P.id && !video.paused) saveProgress(); }, 10000);

function nextEp() {
  if (!P.id || !EPS.get(P.id)) return null;
  if (P.queue) { const i = P.queue.indexOf(P.id); return i >= 0 && P.queue[i + 1] ? EPS.get(P.queue[i + 1]) : null; }
  const e = EPS.get(P.id), s = seriesOf(e.sid), i = s.eps.findIndex(x => x.id === e.id);
  return s.eps.slice(i + 1).find(x => !x.missing) || null;
}
let cdT = 0;
function showNext(auto) {
  const n = nextEp(); if (!n) return;
  P.nextShown = true;
  const s = seriesOf(n.sid), box = $('#pNext');
  let left = 10;
  box.innerHTML = `<div class="th" style="background-image:url('${thumb(n.id)}')">${auto ? `<span class="cd" id="cd">${left}</span>` : ''}</div><div class="bx"><small>${P.queue ? 'Suivant dans la playlist' : 'Épisode suivant'}</small><b>${esc(s.name)} — ${esc(epLabel(n))}</b><div class="r"><button class="btn white sm" id="nGo">${ic('play')}Lire maintenant</button><button class="btn ghost sm" id="nNo">Fermer</button></div></div>`;
  box.hidden = false;
  $('#nGo').onclick = () => { clearInterval(cdT); play(n.id); };
  $('#nNo').onclick = () => { clearInterval(cdT); box.hidden = true; };
  clearInterval(cdT);
  if (auto) cdT = setInterval(() => { left--; const c = $('#cd'); if (c) c.textContent = left; if (left <= 0) { clearInterval(cdT); play(n.id); } }, 1000);
}
function onEnded() {
  const n = nextEp();
  if (n && LIB.settings.autoNext !== false) showNext(true);
  else if (!n) { toast(P.queue ? 'Fin de la playlist' : 'Fin de la série 🎉'); setTimeout(closePlayer, 1500); }
}
function closePlayer() {
  saveProgress(); clearInterval(cdT);
  video.pause(); video.removeAttribute('src'); video.load();
  player.hidden = true; document.body.classList.remove('playing'); P.id = null;
  if (document.fullscreenElement) document.exitFullscreen().catch(() => { });
  loadLib().then(() => { render(true); const after = window.vkAfterPlayer; window.vkAfterPlayer = null; if (after) after(); });
}
window.closePlayer = closePlayer;

/* ---------- sous-titres (affichés par l'appli : toujours synchronisés, même en conversion) */
function parseVtt(txt) {
  const out = [], toS = t => { const p = t.trim().split(':').map(Number); return p.length === 3 ? p[0] * 3600 + p[1] * 60 + p[2] : p[0] * 60 + p[1]; };
  for (const block of txt.replace(/\r/g, '').split(/\n\n+/)) {
    const lines = block.split('\n'); const i = lines.findIndex(l => l.includes('-->')); if (i < 0) continue;
    const [a, b] = lines[i].split('-->'); const text = lines.slice(i + 1).join('\n').replace(/<\/?(?:i|b|u|c|v|ruby|rt|lang)[^>]*>/g, '').replace(/\{\\[^}]*\}/g, '').trim();
    if (text) out.push({ s: toS(a), e: toS(b.trim().split(' ')[0]), text });
  }
  return out;
}
function chooseSubs() {
  const subs = (P.info.subs || []).filter(s => !s.image), e = EPS.get(P.id);
  const remembered = (LIB.settings.subBySeries || {})[e.sid];
  const audioLang = (P.info.audios[P.aud] || {}).lang || '';
  let key = 'off';
  if (remembered && (remembered === 'off' || subs.some(s => s.key === remembered))) key = remembered;
  else if (remembered && remembered.startsWith('lang:')) { const l = remembered.slice(5); const f = subs.find(s => (s.lang || '').startsWith(l)); key = f ? f.key : 'off'; }
  else if (LIB.settings.subLang !== 'off' && !/^(fr|fre|fra)$/.test(audioLang)) {
    const fr = subs.find(s => s.key === 'auto-fr') || subs.find(s => /^(fr|fre|fra)/.test(s.lang || '') && !s.forced) || subs.find(s => /^(fr|fre|fra)/.test(s.lang || ''));
    key = fr ? fr.key : 'off';
  } else { const forced = subs.find(s => s.forced && /^(fr|fre|fra)/.test(s.lang || '')); if (forced) key = forced.key; }
  setSub(key, false);
}
async function setSub(key, remember = true) {
  P.subKey = key; P.cues = []; $('#subs').innerHTML = '';
  $('#pCC').classList.toggle('on', key !== 'off');
  if (remember) { const e = EPS.get(P.id); LIB.settings.subBySeries = LIB.settings.subBySeries || {}; const s = (P.info.subs || []).find(x => x.key === key); LIB.settings.subBySeries[e.sid] = key === 'off' ? 'off' : key.startsWith('auto') ? key : 'lang:' + ((s && s.lang) || '').slice(0, 2); saveSettings(); }
  if (key === 'off') return;
  try {
    const r = await fetch(u(`/sub/${P.id}/${key}.vtt`));
    if (!r.ok) throw 0;
    P.cues = parseVtt(await r.text());
    if (!P.cues.length) throw 0;
  } catch { toast('Sous-titres illisibles', true); P.subKey = 'off'; $('#pCC').classList.remove('on'); }
}
async function refreshPlayerSubs() {
  if (!P.id) return;
  try { const fresh = await api(`/api/play/${P.id}?hevc=${hevcOK() ? 1 : 0}`); const had = (P.info.subs || []).some(s => s.key === 'auto-fr'); P.info.subs = fresh.subs; if (!had && fresh.subs.some(s => s.key === 'auto-fr')) { toast('Sous-titres français prêts', false, { label: 'Activer', fn: () => setSub('auto-fr') }); } if (!$('#pMenu').hidden) openCC(); } catch { }
}
let lastSub = '';
function drawSubs() {
  if (!P.id) return;
  const t = curTime() - P.subDelay;
  let html = '';
  if (P.cues.length && P.subKey !== 'off') {
    const act = [];
    for (const c of P.cues) { if (c.s > t) break; if (c.e >= t) act.push(c.text); }
    html = act.map(x => `<span>${esc(x)}</span>`).join('<br>');
  }
  if (html !== lastSub) { $('#subs').innerHTML = html; lastSub = html; }
}

/* ---------- barre de contrôle */
function updateUI() {
  const d = P.info?.duration || video.duration || 0, t = curTime();
  $('#pPlay').innerHTML = ic(video.paused ? 'play' : 'pause');
  $('#pTime').textContent = `${fmt(t)} / ${fmt(d)}`;
  $('#skFill').style.width = d ? (t / d * 100) + '%' : '0';
  $('#skKnob').style.left = d ? (t / d * 100) + '%' : '0';
  let be = 0; const b = video.buffered; if (b.length) be = (P.mode === 'direct' ? 0 : P.base) + b.end(b.length - 1);
  $('#skBuf').style.width = d ? (Math.min(1, be / d) * 100) + '%' : '0';
  $('#pMute').innerHTML = ic(video.muted || video.volume === 0 ? 'mute' : 'vol');
  $('#pVol').value = video.muted ? 0 : video.volume;
  $('#pFull').innerHTML = ic(document.fullscreenElement ? 'unfull' : 'full');
  $('#pNextBtn').hidden = !nextEp();
  $('.subs').style.setProperty('--subsz', LIB.settings.subSize || 1);
}
(function loop() { if (P.id) { drawSubs(); updateUI(); const d = P.info?.duration || 0; if (d > 120 && !P.nextShown && curTime() > d - 25 && nextEp() && !video.paused) showNext(false); } requestAnimationFrame(loop); })();
$('#pPlay').onclick = () => video.paused ? video.play() : video.pause();
$('#pBk').onclick = () => seekTo(curTime() - 10);
$('#pFw').onclick = () => seekTo(curTime() + 10);
$('#pMute').onclick = () => { video.muted = !video.muted; };
$('#pVol').oninput = e => { video.volume = +e.target.value; video.muted = !+e.target.value; try { localStorage.setItem('vks.vol', e.target.value); } catch { } };
try { const v = localStorage.getItem('vks.vol'); if (v != null) video.volume = +v; } catch { }
$('#pFull').onclick = () => document.fullscreenElement ? document.exitFullscreen() : player.requestFullscreen();
$('#pBack').onclick = closePlayer;
$('#pNextBtn').onclick = () => { const n = nextEp(); if (n) play(n.id); };
video.addEventListener('click', () => video.paused ? video.play() : video.pause());
video.addEventListener('dblclick', () => $('#pFull').click());
const seek = $('#seek');
const seekFrac = e => { const r = seek.getBoundingClientRect(); return clamp((e.clientX - r.left) / r.width, 0, 1); };
let seeking = false;
seek.addEventListener('pointerdown', e => { seeking = true; seek.setPointerCapture(e.pointerId); });
seek.addEventListener('pointermove', e => { const f = seekFrac(e), d = P.info?.duration || 0; $('#skTip').style.left = (f * 100) + '%'; $('#skTip').textContent = fmt(f * d); if (seeking) { $('#skFill').style.width = (f * 100) + '%'; $('#skKnob').style.left = (f * 100) + '%'; } });
seek.addEventListener('pointerup', e => { if (!seeking) return; seeking = false; seekTo(seekFrac(e) * (P.info?.duration || 0)); });
function poke() { player.classList.remove('idle', 'hidecur'); clearTimeout(P.hideT); P.hideT = setTimeout(() => { if (!video.paused && $('#pMenu').hidden) player.classList.add('idle', 'hidecur'); }, 2800); }
player.addEventListener('mousemove', poke);
document.addEventListener('fullscreenchange', updateUI);

// précision montrée une seule fois par appareil (le turc n'a qu'un pronom pour « il » et « elle »)
function pronounNote() {
  try { if (localStorage.getItem('vks-note-pronoms')) return; localStorage.setItem('vks-note-pronoms', '1'); } catch { }
  toast('Sous-titres créés par IA : les pronoms il/elle, et plus rarement je/tu, peuvent être confondus.');
}
function openCC() {
  const m = $('#pMenu'), subs = P.info.subs || [], e = EPS.get(P.id);
  const it = (on, label, attrs, extra = '', dis) => `<button class="pm-i${dis ? ' dis' : ''}" ${attrs}><span class="ck">${on ? ic('check') : ''}</span>${esc(label)}${extra}</button>`;
  const autoOk = subs.some(s => s.key === 'auto-fr');
  m.innerHTML = `<div class="pm-h">Sous-titres</div>
    ${it(P.subKey === 'off', 'Désactivés', 'data-sub="off"')}
    ${subs.map(s => it(P.subKey === s.key, s.label, `data-sub="${s.key}"`, s.image ? '<small>image, non lisible</small>' : s.kind === 'auto' ? '<small>auto</small>' : '', s.image)).join('')}
    ${subs.some(s => s.kind === 'auto' || /^auto-/.test(s.key)) ? '<div class="pm-note">Sous-titres créés par IA : les pronoms <b>il/elle</b>, et plus rarement <b>je/tu</b>, peuvent être confondus.</div>' : ''}
    ${!autoOk && !viewer() ? (e.pending ? `<button class="pm-i act dis"><span class="ck"><span class="spin" style="width:15px;height:15px;border-width:2px"></span></span>Sous-titres français en préparation (~2-3 min)…</button>` : `<button class="pm-i act" id="ccAuto"><span class="ck">${ic('magic')}</span>Créer les sous-titres français (IA)</button>`) : ''}
    ${P.subKey !== 'off' ? `<div class="pm-row"><span>Décalage ${P.subDelay > 0 ? '+' : ''}${P.subDelay.toFixed(1)} s</span><button data-dl="-0.5">−</button><button data-dl="0">0</button><button data-dl="0.5">+</button></div>
    <div class="pm-row"><span>Taille</span>${[[0.8, 'S'], [1, 'M'], [1.3, 'L'], [1.6, 'XL']].map(([v, l]) => `<button data-sz="${v}" class="${(LIB.settings.subSize || 1) === v ? 'on' : ''}">${l}</button>`).join('')}</div>` : ''}
    ${P.info.audios.length > 1 ? `<div class="pm-h">Audio</div>${P.info.audios.map(a => it(P.aud === a.i, a.label, `data-aud="${a.i}"`)).join('')}` : ''}`;
  m.hidden = false;
  m.onclick = async ev => {
    const b = ev.target.closest('button'); if (!b || b.classList.contains('dis')) return;
    if (b.dataset.sub) { await setSub(b.dataset.sub); openCC(); if (/^auto-/.test(b.dataset.sub)) pronounNote(); }
    else if (b.id === 'ccAuto') { await autoEnqueue([P.id]); if (JOBS.keys && JOBS.keys.groq) toast('Les sous-titres apparaîtront ici dans 2-3 minutes (tu peux continuer à regarder)'); openCC(); }
    else if (b.dataset.dl) { P.subDelay = +b.dataset.dl === 0 ? 0 : P.subDelay + +b.dataset.dl; openCC(); }
    else if (b.dataset.sz) { LIB.settings.subSize = +b.dataset.sz; saveSettings(); openCC(); }
    else if (b.dataset.aud) { const t = curTime(); P.aud = +b.dataset.aud; P.mode = 'stream'; await loadAt(t); openCC(); }
  };
}
function openEps() {
  const m = $('#pMenu'), e = EPS.get(P.id);
  const list = P.queue ? P.queue.map(id => EPS.get(id)).filter(Boolean) : seriesOf(e.sid).eps;
  m.innerHTML = `<div class="pm-h">${P.queue ? esc(P.queueName) : 'Épisodes'}</div><div class="pm-eps">${list.map(x => `<button class="pm-ep${x.id === P.id ? ' on' : ''}" data-ep="${x.id}"><span class="th" style="background-image:url('${thumb(x.id)}')"></span><span><b>${esc(epLabel(x))}</b><small>${P.queue ? esc(seriesOf(x.sid).name) + ' · ' : ''}${fmtDur(x.dur)}${(prog(x.id) || {}).done ? ' · vu' : ''}</small></span></button>`).join('')}</div>`;
  m.hidden = false;
  m.onclick = ev => { const b = ev.target.closest('[data-ep]'); if (b) play(b.dataset.ep); };
  $('.pm-ep.on', m)?.scrollIntoView({ block: 'center' });
}
$('#pCC').onclick = () => { const m = $('#pMenu'); if (!m.hidden && m.querySelector('[data-sub]')) m.hidden = true; else openCC(); };
$('#pEps').onclick = () => { const m = $('#pMenu'); if (!m.hidden && m.querySelector('.pm-eps')) m.hidden = true; else openEps(); };
player.addEventListener('pointerdown', e => { const m = $('#pMenu'); if (!m.hidden && !m.contains(e.target) && !e.target.closest('#pCC,#pEps')) m.hidden = true; });

document.addEventListener('keydown', e => {
  if (player.hidden) {
    if (e.key === 'Escape' && !$('#modal').hidden) $('#modal').hidden = true;
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'f') { e.preventDefault(); $('#q').focus(); }
    return;
  }
  const k = e.key; poke();
  if (k === ' ' || k.toLowerCase() === 'k') { e.preventDefault(); video.paused ? video.play() : video.pause(); }
  else if (k === 'ArrowLeft') { e.preventDefault(); seekTo(curTime() - (e.shiftKey ? 60 : 10)); }
  else if (k === 'ArrowRight') { e.preventDefault(); seekTo(curTime() + (e.shiftKey ? 60 : 10)); }
  else if (k === 'ArrowUp') { e.preventDefault(); video.volume = clamp(video.volume + 0.05, 0, 1); video.muted = false; }
  else if (k === 'ArrowDown') { e.preventDefault(); video.volume = clamp(video.volume - 0.05, 0, 1); }
  else if (k.toLowerCase() === 'f') $('#pFull').click();
  else if (k.toLowerCase() === 'm') video.muted = !video.muted;
  else if (k.toLowerCase() === 'n') $('#pNextBtn').click();
  else if (k.toLowerCase() === 's') { const keys = ['off', ...(P.info?.subs || []).filter(s => !s.image).map(s => s.key)]; setSub(keys[(keys.indexOf(P.subKey) + 1) % keys.length]); const s = (P.info.subs || []).find(x => x.key === P.subKey); toast('Sous-titres : ' + (s ? s.label : 'désactivés')); }
  else if (k === 'Escape') { if (!$('#pMenu').hidden) $('#pMenu').hidden = true; else if (!document.fullscreenElement) closePlayer(); }
  else if (k === 'Backspace') closePlayer();
});
window.addEventListener('beforeunload', saveProgress);

/* ---------- démarrage */
applySite(SITE);
api('/api/cloud/site').then(s => { if (s && typeof s === 'object' && !s.error) { applySite(s); render(true); } }).catch(() => { });
(async () => {
  try { await loadLib(); } catch (e) { view.innerHTML = `<div class="empty"><h1>VDIZI ne répond pas</h1><p>${esc(e.message)}</p></div>`; return; }
  render(); pollJobs();
})();

/* =====================================================================
   Connexion IA (clés gratuites) et noms propres
   ===================================================================== */
const LANGS = { tr: 'turc', en: 'anglais', es: 'espagnol', ko: 'coréen', ja: 'japonais', ar: 'arabe', de: 'allemand', it: 'italien', pt: 'portugais', ru: 'russe', fr: 'français', zh: 'chinois', hi: 'hindi', az: 'azéri', fa: 'persan' };
async function openKeys(then) {
  let cur = {}; try { cur = await api('/api/keys'); } catch { }
  const sheet = $('#sheet');
  sheet.innerHTML = `<h3>Connexion IA — gratuite</h3>
  <p class="mut">Pour des sous-titres de qualité, VDIZI utilise deux IA en ligne gratuites. Chacune demande une « clé » personnelle : un compte gratuit, sans carte bancaire. C'est à faire une seule fois.</p>
  <div class="kstep"><div class="kn">1</div><div class="grow"><b>Groq — écoute des dialogues</b> <span class="kreq">obligatoire</span>
    <ol><li>Ouvre <a href="https://console.groq.com/keys" target="_blank">console.groq.com/keys</a> et connecte-toi (bouton Google, le plus simple).</li><li>Clique <b>« Create API Key »</b>, donne un nom (ex : VDIZI), puis <b>copie la clé</b> (elle commence par <code>gsk_</code>).</li><li>Colle-la ici :</li></ol>
    <label class="fld"><input id="kGroq" placeholder="${cur.groq ? 'Déjà enregistrée : ' + esc(cur.groq) + ' (laisse vide pour la garder)' : 'gsk_…'}" autocomplete="off" spellcheck="false"></label><span class="kres" id="rGroq"></span>
    <div style="margin-top:12px"><b>Comptes de relais</b> <span class="kreq rec">si Groq sature</span>
      <p class="mut" style="font-size:12.5px;margin:4px 0 6px">Quand un compte Groq atteint sa limite gratuite, VDIZI passe tout de suite au suivant, sans attendre. ⚠️ Chaque clé doit venir d'un <b>compte Groq différent</b> (une autre adresse Google) : deux clés du même compte partagent la même limite.</p>
      ${(cur.groqMore || []).map((m, i) => `<div style="display:flex;align-items:center;gap:8px;margin:4px 0"><span class="grow">Compte ${i + 2} : <code>${esc(m)}</code> <span class="kres" data-rm-res="${i}"></span></span><button class="btn sm ghost" data-rm-groq="${i}">Retirer</button></div>`).join('')}
      <label class="fld"><input id="kGroqMore" placeholder="Ajouter une clé d'un autre compte Groq : gsk_…" autocomplete="off" spellcheck="false"></label><span class="kres" id="rGroqMore"></span></div></div></div>
  <div class="kstep"><div class="kn">2</div><div class="grow"><b>Google Gemini — traduction intelligente</b> <span class="kreq rec">recommandé</span>
    <ol><li>Ouvre <a href="https://aistudio.google.com/apikey" target="_blank">aistudio.google.com/apikey</a> avec ton compte Google.</li><li>Clique <b>« Créer une clé API »</b> (accepte les conditions si demandé), puis <b>copie la clé</b> (elle commence par <code>AIza</code>).</li><li>Colle-la ici :</li></ol>
    <label class="fld"><input id="kGem" placeholder="${cur.gemini ? 'Déjà enregistrée : ' + esc(cur.gemini) + ' (laisse vide pour la garder)' : 'AIza…'}" autocomplete="off" spellcheck="false"></label><span class="kres" id="rGem"></span>
    <div style="margin-top:12px"><b>Comptes de relais</b> <span class="kreq rec">pour ne jamais attendre</span>
      <p class="mut" style="font-size:12.5px;margin:4px 0 6px">Quand un compte Gemini est saturé, VDIZI passe tout de suite au suivant, toujours sur le meilleur modèle Gemini : la qualité ne baisse jamais. Si tous les comptes sont saturés, VDIZI attend et affiche l'heure de reprise. Plus il y a de comptes, moins il y a d'attente. ⚠️ Chaque clé doit venir d'un <b>compte Google différent</b> : deux clés du même compte partagent la même limite.</p>
      ${(cur.geminiMore || []).map((m, i) => `<div style="display:flex;align-items:center;gap:8px;margin:4px 0"><span class="grow">Compte ${i + 2} : <code>${esc(m)}</code> <span class="kres" data-rm-gres="${i}"></span></span><button class="btn sm ghost" data-rm-gem="${i}">Retirer</button></div>`).join('')}
      <label class="fld"><input id="kGemMore" placeholder="Ajouter une clé d'un autre compte Google : AIza…" autocomplete="off" spellcheck="false"></label><span class="kres" id="rGemMore"></span></div></div></div>
  <p class="mut" style="font-size:12.5px;margin:4px 0 0">Les clés restent sur ton PC. Seuls l'audio des dialogues et leur texte sont envoyés aux IA, jamais tes vidéos. Avec les offres gratuites, Google et Groq peuvent utiliser ces données pour améliorer leurs services. Limites gratuites : environ 10 à 15 épisodes par jour.</p>
  <div class="foot"><button class="btn ghost" id="kCancel">Plus tard</button><button class="btn" id="kSave">Vérifier et enregistrer</button></div>`;
  $('#modal').hidden = false;
  setTimeout(() => $('#kGroq').focus(), 50);
  $('#kCancel').onclick = () => { $('#modal').hidden = true; };
  sheet.querySelectorAll('[data-rm-groq]').forEach(x => x.onclick = async () => {
    if (!confirm('Retirer ce compte Groq de relais ?')) return;
    try { await api('/api/keys', { method: 'POST', body: { delGroq: +x.dataset.rmGroq } }); toast('Compte retiré'); openKeys(then); } catch (e) { toast(e.message, true); }
  });
  sheet.querySelectorAll('[data-rm-gem]').forEach(x => x.onclick = async () => {
    if (!confirm('Retirer ce compte Gemini de relais ?')) return;
    try { await api('/api/keys', { method: 'POST', body: { delGemini: +x.dataset.rmGem } }); toast('Compte retiré'); openKeys(then); } catch (e) { toast(e.message, true); }
  });
  $('#kSave').onclick = async () => {
    const b = $('#kSave'); b.disabled = true; b.textContent = 'Vérification…';
    const body = {}; const g = $('#kGroq').value.trim(), m = $('#kGem').value.trim(), gm = $('#kGroqMore').value.trim(), em = $('#kGemMore').value.trim();
    if (g) body.groq = g; if (m) body.gemini = m; if (gm) body.addGroq = gm; if (em) body.addGemini = em;
    try {
      const r = await api('/api/keys', { method: 'POST', body });
      const show = (el, v, has) => { if (!el) return; el.textContent = v === 'ok' ? '✅ Clé valide' : v ? '❌ ' + v : has ? '' : ''; el.className = 'kres ' + (v === 'ok' ? 'ok' : v ? 'bad' : ''); };
      show($('#rGroq'), r.test.groq); show($('#rGem'), r.test.gemini);
      const more = r.test.groqMore || [];
      more.forEach((v, i) => show(sheet.querySelector(`[data-rm-res="${i}"]`), v));
      const gmore = r.test.geminiMore || [];
      gmore.forEach((v, i) => show(sheet.querySelector(`[data-rm-gres="${i}"]`), v));
      const moreOk = !more.some(v => v !== 'ok') && !gmore.some(v => v !== 'ok');
      if (gm) show($('#rGroqMore'), more[more.length - 1]);
      if (em) show($('#rGemMore'), gmore[gmore.length - 1]);
      JOBS.keys = r.keys;
      const okG = r.keys.groq && (r.test.groq === 'ok' || r.test.groq == null);
      if ((gm || em) && moreOk) { toast(`Compte de relais ajouté ✅ (${r.keys.groqCount} Groq · ${r.keys.geminiCount} Gemini)`); setTimeout(() => openKeys(then), 900); }
      else if (okG && moreOk && (!r.test.gemini || r.test.gemini === 'ok')) {
        toast(r.keys.gemini ? 'IA connectée ✅ — sous-titres de qualité activés' : 'Écoute connectée ✅ — ajoute aussi Gemini pour une meilleure traduction');
        setTimeout(() => { $('#modal').hidden = true; then && then(); }, 900);
      }
    } catch (e) { toast(e.message, true); }
    b.disabled = false; b.textContent = 'Vérifier et enregistrer';
  };
}
function openGlossary(s) {
  let g = (s.glossary || []).map(x => ({ ...x, variants: [...(x.variants || [])] }));
  const sheet = $('#sheet');
  const typeOpt = v => ['personnage', 'lieu', 'organisation', 'autre'].map(t => `<option ${t === v ? 'selected' : ''}>${t}</option>`).join('');
  const sorted = () => g.map((x, i) => [x, i]).sort((a, b) => (a[0].type === 'personnage' ? 0 : 1) - (b[0].type === 'personnage' ? 0 : 1) || (b[0].seen || 1) - (a[0].seen || 1));
  const draw = () => {
    sheet.innerHTML = `<h3>Noms propres — ${esc(s.name)}</h3>
    <p class="mut">Cette liste se remplit toute seule avec les noms entendus. Elle sert seulement à bien les écrire et à accorder il/elle : aucun titre ni nom de famille n'est ajouté aux sous-titres. Si un prénom est mal entendu (ex : « İhsan » au lieu de « Birsen »), écris-le dans « Mal entendu comme ».</p>
    <div style="display:flex;gap:8px;margin-bottom:10px;flex-wrap:wrap"><button class="btn sm ghost" id="glAdd">${ic('plus')}Ajouter un nom</button></div>
    <div class="gl">${g.length ? `<div class="glh"><span>Nom</span><span>Mal entendu comme</span><span>Genre</span><span></span></div>` : ''}
    ${sorted().map(([x, i]) => `<div class="glr" data-i="${i}"><input data-f="src" value="${esc(x.src)}" title="${esc(x.note || '')}"><input data-f="variants" value="${esc((x.variants || []).join(', '))}" placeholder="ex : İhsan, e Cevit"><select data-f="gender"><option value="?" ${x.gender === '?' ? 'selected' : ''}>?</option><option value="m" ${x.gender === 'm' ? 'selected' : ''}>il</option><option value="f" ${x.gender === 'f' ? 'selected' : ''}>elle</option></select><button class="ibtn" data-del="${i}" title="Supprimer">${ic('x')}</button></div>`).join('') || '<p style="color:#888">Encore vide : la liste se remplira au premier sous-titrage IA.</p>'}</div>
    <div class="foot"><button class="btn ghost" id="glCancel">Annuler</button><button class="btn" id="glSave">Enregistrer</button></div>`;
    $$('.glr', sheet).forEach(r => $$('[data-f]', r).forEach(inp => inp.oninput = inp.onchange = () => { const x = g[+r.dataset.i]; x[inp.dataset.f] = inp.dataset.f === 'variants' ? inp.value.split(',').map(v => v.trim()).filter(Boolean) : inp.value; x.locked = true; }));
    $$('[data-del]', sheet).forEach(b => b.onclick = () => { g.splice(+b.dataset.del, 1); draw(); });
    $('#glAdd').onclick = () => { g.unshift({ src: '', fr: '', type: 'personnage', gender: '?', variants: [], locked: true }); draw(); $('.glr input[data-f=src]', sheet).focus(); };
    $('#glCancel').onclick = () => { $('#modal').hidden = true; };
    $('#glSave').onclick = async () => {
      for (const x of g) if (x.src && !x.fr) x.fr = x.src;
      LIB = await api(`/api/series/${s.id}`, { method: 'POST', body: { glossary: g.filter(x => String(x.src).trim()) } }); indexLib();
      $('#modal').hidden = true; render(true);
      const done = seriesOf(s.id).eps.filter(e => e.hasSrc).map(e => e.id);
      if (done.length) toast('Noms enregistrés', false, { label: `Retraduire ${done.length} épisode${done.length > 1 ? 's' : ''}`, fn: () => autoEnqueue(done, true) });
      else toast('Noms enregistrés');
    };
  };
  draw(); $('#modal').hidden = false;
}

/* minuteur de l'étape « Analyse de l'épisode » (Travaux) : temps restant prévu, mis à jour chaque seconde */
setInterval(() => {
  for (const el of document.querySelectorAll('.antimer')) {
    const end = +el.dataset.anend, st = +el.dataset.anstart, now = Date.now(), left = end - now, tot = Math.max(1, end - st);
    const mmss = ms => { const s = Math.round(Math.abs(ms) / 1000); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
    const pct = Math.min(100, Math.max(0, (now - st) / tot * 100));
    el.innerHTML = left > 0 ? `⏱ Analyse des personnages : il reste environ <b>${mmss(left)}</b> (prévu ${mmss(tot)})<div class="pbar sm"><i style="width:${pct.toFixed(1)}%"></i></div>` : `⏱ Analyse des personnages : un peu plus longue que prévu (<b>+${mmss(left)}</b>), elle continue…<div class="pbar sm"><i style="width:100%"></i></div>`;
  }
}, 1000);

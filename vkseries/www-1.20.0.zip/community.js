'use strict';
/* =====================================================================
   Onglet Communauté : un compte connecté suggère une série,
   le propriétaire la reçoit (badge + message) sur l'appli et sur le site.
   ===================================================================== */
let SUGG = { items: [], seen: 0 }, suggToast = 0;
const isAnon = () => !!(window.VK_REMOTE && VK_REMOTE.anon());
const cloudReady = () => window.VK_REMOTE ? !VK_REMOTE.anon() : !!(typeof CLOUD !== 'undefined' && CLOUD && CLOUD.connected);
const suggNew = () => viewer() ? 0 : (SUGG.items || []).filter(x => x.at > (SUGG.seen || 0)).length;
function suggBadge() {
  const n = suggNew(), a = $('#navCom'); if (!a) return;
  a.innerHTML = `Communauté${n ? ` <span class="nb">${n}</span>` : ''}`;
}
async function renderCommunity() {
  const box = t => { view.innerHTML = `<div class="page" style="max-width:760px"><div class="ph"><h1>Communauté</h1></div>${t}</div>`; };
  if (isAnon()) {
    box(`<p style="color:#aaa">Une série te manque ? Connecte-toi pour la proposer.</p><button class="btn" id="comLogin">Se connecter ou créer un compte</button>`);
    $('#comLogin').onclick = async () => { if (await VK_REMOTE.login('Connecte-toi ou crée un compte gratuit pour proposer une série.')) location.reload(); };
    return;
  }
  if (!cloudReady()) return box('<p style="color:#aaa">Connecte d\'abord VDIZI à ton compte en ligne (bouton « En ligne ») pour voir les suggestions.</p>');
  box('<div class="spin"></div>');
  try { SUGG = await api('/api/cloud/suggestions'); } catch (e) { return box(`<p style="color:#ff8a8a">${esc(e.message)}</p>`); }
  const owner = !viewer(), when = at => new Date(at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });
  const fresh = SUGG.seen || 0;
  box(`<p style="color:#aaa;margin-top:-8px">${owner ? 'Les séries proposées par tes spectateurs.' : 'Une série te manque ? Propose-la ici.'}</p>
    ${owner ? '' : `<form id="comF" class="com-f"><input id="comT" maxlength="100" placeholder="Nom de la série" autocomplete="off"><textarea id="comN" maxlength="300" rows="2" placeholder="Un détail ? (facultatif)"></textarea><button class="btn">Suggérer cette série</button></form>`}
    <h3 style="margin-top:22px">Suggestions</h3>
    ${(SUGG.items || []).map(x => `<div class="com-i${owner && x.at > fresh ? ' new' : ''}"><div class="grow"><b>${esc(x.title)}</b>${x.status === 'done' ? '<span class="com-ok">Ajoutée</span>' : ''}<small>${when(x.at)}${owner && x.email ? ' · ' + esc(x.email) : ''}${x.mine ? ' · ta suggestion' : ''}</small>${x.note && (owner || x.mine) ? `<p>${esc(x.note)}</p>` : ''}</div>${owner ? `<button class="btn sm ghost" data-sdone="${esc(x.id)}">${x.status === 'done' ? 'Annuler' : "C'est ajouté"}</button><button class="btn sm ghost" data-srm="${esc(x.id)}">Supprimer</button>` : ''}</div>`).join('') || '<p style="color:#999">Aucune suggestion pour le moment.</p>'}`);
  const f = $('#comF');
  if (f) f.onsubmit = async ev => {
    ev.preventDefault(); const title = $('#comT').value.trim(); if (title.length < 2) return $('#comT').focus();
    const b = $('button', f); b.disabled = true;
    try { SUGG = await api('/api/cloud/suggestions', { method: 'POST', body: { title, note: $('#comN').value.trim() } }); toast('Merci, ta suggestion est envoyée ✓'); renderCommunity(); }
    catch (e) { toast(e.message, true); b.disabled = false; }
  };
  const act = async (id, body) => { try { SUGG = await api('/api/cloud/suggestions/' + id, { method: 'POST', body }); renderCommunity(); } catch (e) { toast(e.message, true); } };
  $$('[data-sdone]').forEach(b => b.onclick = () => { const x = SUGG.items.find(y => y.id === b.dataset.sdone); act(x.id, { status: x.status === 'done' ? 'new' : 'done' }); });
  $$('[data-srm]').forEach(b => b.onclick = () => { if (confirm('Supprimer cette suggestion ?')) act(b.dataset.srm, { remove: true }); });
  if (owner && suggNew()) { try { const r = await api('/api/cloud/suggestions/seen', { method: 'POST', body: {} }); SUGG.seen = r.seen; } catch { } suggBadge(); suggToast = 0; }
}
// propriétaire : prévenu dès qu'une suggestion arrive
async function pollSuggest() {
  if (!viewer() && cloudReady() && route.name !== 'community') {
    try {
      SUGG = await api('/api/cloud/suggestions'); suggBadge();
      const n = suggNew();
      if (n > suggToast) { suggToast = n; toast(`${n} nouvelle${n > 1 ? 's' : ''} suggestion${n > 1 ? 's' : ''} de série`, false, { label: 'Voir', fn: () => { location.hash = '#/community'; } }); }
    } catch { }
  }
  setTimeout(pollSuggest, 60000);
}
setTimeout(pollSuggest, 3500);

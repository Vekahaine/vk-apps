'use strict';
/* =====================================================================
   VkSéries — vérification des sous-titres IA (réservée au propriétaire)
   ===================================================================== */
ICONS.shield = '<path d="M12 3 5 6v5c0 4.5 3 8.2 7 10 4-1.8 7-5.5 7-10V6z"/><path d="m9 12 2 2 4-4"/>';
const isGuest = () => typeof CLOUD !== 'undefined' && CLOUD && CLOUD.guest;
const SEV = { 3: 'Grave', 2: 'À revoir', 1: 'Détail' };
const mmss = s => { s = Math.max(0, Math.round(s || 0)); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60; return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(x).padStart(2, '0'); };

function checkBadge(e) {
  if (isGuest()) return '';
  if (e.checking || (CHECKS.cur && CHECKS.cur.id === e.id)) return `<span class="run"><span class="spin"></span>Vérification…</span>`;
  const c = e.check; if (!c || !e.autoFr) return '';
  if (!c.n) return `<span class="ok ckb" data-check="${e.id}" title="Sous-titres vérifiés${c.ai ? ' (contrôle + relecture IA)' : ' (contrôle technique)'}">${ic('shield')}Vérifié</span>`;
  const lvl = c.grave ? 'bad' : c.warn ? 'warn' : 'info';
  return `<span class="ck ${lvl} ckb" data-check="${e.id}" title="Cliquer pour voir le détail">${ic('shield')}${c.n} à revoir${c.grave ? ` · ${c.grave} grave${c.grave > 1 ? 's' : ''}` : ''}</span>`;
}
function checkEpItems(e) {
  if (isGuest() || !e.autoFr || !e.hasSrc) return [];
  return [
    ...(e.check ? [{ label: `Voir la vérification des sous-titres (${e.check.n ? e.check.n + ' à revoir' : 'tout est bon'})`, icon: 'shield', act: () => openCheck(e.id) }] : []),
    { label: e.check ? 'Revérifier les sous-titres' : 'Vérifier les sous-titres', icon: 'shield', act: () => checkEnqueue([e.id]) },
  ];
}
function checkSeriesItems(s, season) {
  if (isGuest()) return [];
  const ok = list => list.filter(e => e.autoFr && e.hasSrc).map(e => e.id);
  const inSeason = ok(s.eps.filter(e => e.s === season)), all = ok(s.eps);
  const notYet = all.filter(id => !EPS.get(id).check);
  return ['-', { h: 'Vérification des sous-titres' },
    { label: `Vérifier cette saison (${inSeason.length})`, icon: 'shield', act: () => inSeason.length ? checkEnqueue(inSeason) : toast('Aucun épisode sous-titré dans cette saison') },
    { label: `Vérifier toute la série (${all.length})`, icon: 'shield', act: () => all.length ? checkEnqueue(all) : toast('Aucun épisode sous-titré') },
    ...(notYet.length && notYet.length < all.length ? [{ label: `Seulement les non vérifiés (${notYet.length})`, icon: 'shield', act: () => checkEnqueue(notYet) }] : []),
    { label: `Retraduire toute la série sans réécoute (${all.length}) · Gemini seulement`, icon: 'refresh', act: () => { if (!all.length) return toast('Aucun épisode sous-titré'); if (!confirm(`Retraduire les ${all.length} épisodes de « ${s.name} » ?\n\nL'audio n'est PAS réécouté (aucun Groq) : seul Gemini refait la traduction. Chaque épisode est ensuite revérifié.`)) return; autoEnqueue(all, true); } },
  ];
}
async function checkEnqueue(ids, withAi) {
  const st = LIB.settings || {};
  try {
    const r = await api('/api/check', { method: 'POST', body: { ids, ai: withAi ?? st.checkAi !== false } });
    CHECKS = r.checks;
    toast(r.added ? `Vérification de ${r.added} épisode${r.added > 1 ? 's' : ''} lancée` : 'Déjà en cours', false, { label: 'Voir', fn: () => { location.hash = '#/auto'; } });
    await loadLib(); render(true); pollJobs(true);
  } catch (e) { toast(e.message, true); }
}
// fin d'une vérification → message
function checkToast(prev) {
  const d = CHECKS.done[0]; if (!d || prev.includes(d.id + d.at)) return;
  const e = EPS.get(d.id), name = e ? `${seriesOf(e.sid).name} ${epCode(e)}` : '';
  if (!d.ok) return toast(`Vérification impossible ${name} : ${d.msg}`, true);
  const n = d.sum ? d.sum.n : 0;
  toast(n ? `${name} : ${n} point${n > 1 ? 's' : ''} à revoir dans les sous-titres${d.sum.grave ? ` (${d.sum.grave} grave${d.sum.grave > 1 ? 's' : ''})` : ''}` : `${name} : sous-titres vérifiés, rien à signaler ✓`, false, n ? { label: 'Voir', fn: () => openCheck(d.id) } : null);
}

/* ---------- réglages */
function checkSettingsHTML(st) {
  if (isGuest()) return '';
  const sw = (k, def, title, txt) => `<div class="tg"><div><b>${title}</b><small>${txt}</small></div><button class="sw${(st[k] ?? def) ? ' on' : ''}" data-ck="${k}" data-def="${def ? 1 : 0}"></button></div>`;
  return sw('autoCheck', true, 'Vérifier les sous-titres automatiquement', "Dès qu'un épisode est sous-titré, l'appli cherche les erreurs : lignes non traduites, phrases inventées, prénoms mal écrits, passages sans sous-titres, fin coupée…")
    + sw('checkAi', true, 'Avec relecture par l\'IA', "Gemini relit toute la traduction : contresens, il/elle, tu/vous, phrases incompréhensibles. Utilise ta clé Gemini gratuite (~1 min par épisode).")
    + sw('checkAutoFix', false, 'Corriger automatiquement', "Applique tout de suite les corrections proposées. Désactivé : tu les vois d'abord et tu choisis.");
}

/* ---------- page « Sous-titres automatiques » : bloc vérifications */
function checksAutoHTML(name) {
  if (isGuest()) return '';
  const c = CHECKS.cur, q = CHECKS.queue || [], d = CHECKS.done || [];
  if (!c && !q.length && !d.length) return `<h3 style="margin-top:26px">Vérification des sous-titres</h3><p class="note">Sur la page d'une série : <b>Sous-titres FR (IA) → Vérifier toute la série</b>, ou clic droit sur un épisode → <b>Vérifier les sous-titres</b>. ${LIB.settings.autoCheck !== false ? 'Les nouveaux épisodes sont vérifiés automatiquement.' : ''}</p>`;
  return `<h3 style="margin-top:26px">Vérification des sous-titres</h3>
    ${c ? `<div class="jobcard"><b>${esc(name(c.id))}</b><small>${esc(c.phase || '')} · ${Math.round((c.p || 0) * 100)} %</small><div class="pbar"><i style="width:${((c.p || 0) * 100).toFixed(1)}%"></i></div><div style="margin-top:10px"><button class="btn sm danger" data-ckcancel="${c.id}">Annuler</button></div></div>` : ''}
    ${q.length ? `<div class="jl"><span class="grow">${q.length} épisode${q.length > 1 ? 's' : ''} en attente de vérification</span></div>` : ''}
    ${d.map(x => `<div class="jl"><span>${!x.ok ? '⚠️' : x.sum && x.sum.n ? (x.sum.grave ? '🔴' : '🟠') : '✅'}</span><span class="grow">${esc(name(x.id))}</span><span class="e">${esc(!x.ok ? x.msg : x.sum && x.sum.n ? `${x.sum.n} à revoir` + (x.msg ? ' · ' + x.msg : '') : 'rien à signaler' + (x.msg ? ' · ' + x.msg : ''))}</span>${x.ok ? `<button class="btn sm ghost" data-ckopen="${x.id}">${ic('shield')}Détail</button>` : ''}</div>`).join('')}`;
}
function bindChecksAuto() {
  $$('[data-ckcancel]').forEach(b => b.onclick = async () => { CHECKS = await api(`/api/check/${b.dataset.ckcancel}`, { method: 'DELETE' }); renderAuto(); });
  $$('[data-ckopen]').forEach(b => b.onclick = () => openCheck(b.dataset.ckopen));
}
document.addEventListener('click', ev => {
  const b = ev.target.closest('[data-check]'); if (!b) return;
  ev.preventDefault(); ev.stopPropagation(); openCheck(b.dataset.check);
}, true);

/* ---------- rapport détaillé d'un épisode */
// back : { k, top } = revenir sur ce point de la liste après avoir regardé le moment dans le lecteur
async function openCheck(id, back) {
  const e = EPS.get(id); if (!e) return;
  const sh = $('#sheet'); sh.dataset.k = 'check';
  sh.innerHTML = '<div class="spin"></div>'; $('#modal').hidden = false;
  let r; try { r = await api(`/api/check/${id}`); } catch (er) { sh.innerHTML = `<p>${esc(er.message)}</p>`; return; }
  const draw = () => {
    const s = seriesOf(e.sid), issues = r.issues || [], fixable = issues.filter(x => x.fix);
    const cnt = { 3: 0, 2: 0, 1: 0 }; for (const x of issues) cnt[x.sev]++;
    sh.innerHTML = `<h3>${ic('shield')} Vérification des sous-titres</h3>
      <p class="mut">${esc(s.name)} — ${esc(epLabel(e))}<br>${r.none ? "Pas encore vérifié." : `Vérifié le ${new Date(r.at).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' })} · ${r.ai ? 'contrôle technique + relecture IA' : 'contrôle technique seulement'}${r.fixed ? ` · ${r.fixed} correction${r.fixed > 1 ? 's' : ''} déjà appliquée${r.fixed > 1 ? 's' : ''}` : ''}`}</p>
      ${r.none ? '' : !issues.length ? `<div class="ck-ok">${ic('check')}<b>Rien à signaler</b><small>Les sous-titres de cet épisode semblent bons.</small></div>`
        : `<div class="ck-sum">${cnt[3] ? `<span class="ck bad">${cnt[3]} grave${cnt[3] > 1 ? 's' : ''}</span>` : ''}${cnt[2] ? `<span class="ck warn">${cnt[2]} à revoir</span>` : ''}${cnt[1] ? `<span class="ck info">${cnt[1]} détail${cnt[1] > 1 ? 's' : ''}</span>` : ''}</div>
      <div class="ck-list">${issues.map(x => `<div class="ck-it s${x.sev}" data-k="${x.k}">
        <div class="ck-h"><button class="btn sm ghost ck-t" data-at="${x.t || 0}" title="Regarder ce moment">${ic('play')}${mmss(x.t)}</button><span class="ck ${x.sev === 3 ? 'bad' : x.sev === 2 ? 'warn' : 'info'}">${SEV[x.sev]} · ${esc(x.type)}</span>${x.by === 'ia' ? '<span class="ck-by">relecture IA</span>' : ''}</div>
        <p>${esc(x.msg)}</p>
        ${x.src ? `<div class="ck-l"><small>Original</small><span>${esc(x.src)}</span></div>` : ''}
        ${x.i >= 0 && x.fr !== undefined ? `<div class="ck-l"><small>Actuel</small><span>${esc(x.fr || '(vide)')}</span></div>` : ''}
        ${x.userNote ? `<div class="ck-l"><small>Ta remarque</small><span>${esc(x.userNote)}</span></div>` : ''}
        ${x.fix ? `<div class="ck-l fix"><small>${x.fix.kind === 'del' ? 'Correction' : 'Proposé'}</small><span>${x.fix.kind === 'del' ? 'supprimer cette ligne' : esc(x.fix.text)}</span></div>` : ''}
        <div class="ck-a">${x.fix ? `<button class="btn sm" data-fix="${x.k}">${ic('check')}Appliquer</button>` : ''}${x.i >= 0 ? `<button class="btn sm ghost" data-ask="${x.k}">${ic('edit')}Corriger moi-même</button>` : ''}<button class="btn sm ghost" data-ok="${x.k}" title="Cette ligne est bonne : elle ne sera plus jamais signalée">Pas d'erreur</button><button class="btn sm ghost" data-ign="${x.k}" title="Cacher pour cette fois">Ignorer</button></div>
        ${x.i >= 0 ? `<div class="ck-ask" hidden><textarea rows="2" maxlength="600" placeholder="Explique ce qui ne va pas (ex : c'est une femme qui parle), ou écris directement la bonne phrase"></textarea><div class="ck-a"><button class="btn sm" data-askai="${x.k}">${ic('magic')}L'IA corrige d'après mon explication</button><button class="btn sm ghost" data-askset="${x.k}">Mettre ce texte tel quel</button></div></div>` : ''}</div>`).join('')}</div>`}
      <div class="foot"><button class="btn ghost" id="ckAgain">${ic('refresh')}${r.none ? 'Vérifier' : 'Revérifier'}</button><span class="grow"></span>${fixable.length > 1 ? `<button class="btn" id="ckAll">${ic('check')}Tout corriger (${fixable.length})</button>` : ''}<button class="btn ${fixable.length > 1 ? 'ghost' : ''}" id="ckClose">Fermer</button></div>`;
    $('#ckClose').onclick = () => { $('#modal').hidden = true; };
    $('#ckAgain').onclick = () => { $('#modal').hidden = true; checkEnqueue([id]); };
    $$('[data-at]', sh).forEach(b => b.onclick = () => {
      const it = b.closest('.ck-it'), ret = { k: it ? +it.dataset.k : -1, top: sh.scrollTop };
      window.vkAfterPlayer = () => openCheck(id, ret); // en quittant le lecteur : retour sur ce même point
      $('#modal').hidden = true; play(id, { at: +b.dataset.at });
    });
    const act = async (kind, body, from) => {
      const at = from ? $$('.ck-it', sh).indexOf(from.closest('.ck-it')) : -1, top = sh.scrollTop;
      try {
        r = await api(`/api/check/${id}/${kind}`, { method: 'POST', body }); await loadLib(); render(true); draw();
        // on reste au même endroit : le point suivant prend la place de celui qu'on vient de traiter
        const left = $$('.ck-it', sh), next = at >= 0 && left[Math.min(at, left.length - 1)];
        if (next) showItem(next); else sh.scrollTop = top;
        if (kind === 'fix' || (kind === 'ask' && body.text)) toast(`Sous-titres corrigés ✓${e.cloud ? ' (renvoyés en ligne)' : ''}`);
        else if (kind === 'ask') toast('Nouvelle proposition : vérifie-la puis clique sur Appliquer');
        else if (kind === 'ok') toast("Noté : cette ligne ne sera plus signalée");
      }
      catch (er) { toast(er.message, true); }
    };
    $$('[data-fix]', sh).forEach(b => b.onclick = () => act('fix', { ks: [+b.dataset.fix] }, b));
    $$('[data-ign]', sh).forEach(b => b.onclick = () => act('ignore', { ks: [+b.dataset.ign] }, b));
    $$('[data-ok]', sh).forEach(b => b.onclick = () => act('ok', { ks: [+b.dataset.ok] }, b));
    $$('[data-ask]', sh).forEach(b => b.onclick = () => { const f = $('.ck-ask', b.closest('.ck-it')); f.hidden = !f.hidden; if (!f.hidden) $('textarea', f).focus(); });
    const send = async (b, make) => {
      const f = b.closest('.ck-ask'), v = $('textarea', f).value.trim(); if (!v) return $('textarea', f).focus();
      const html = b.innerHTML, btns = $$('button', f);
      btns.forEach(x => { x.disabled = true; }); if (make === 'note') b.innerHTML = '<span class="spin" style="width:15px;height:15px;border-width:2px"></span>L\'IA réfléchit…';
      await act('ask', { k: +(b.dataset.askai || b.dataset.askset), [make]: v }, b);
      if (b.isConnected) { btns.forEach(x => { x.disabled = false; }); b.innerHTML = html; } // erreur : le texte reste là
    };
    $$('[data-askai]', sh).forEach(b => b.onclick = () => send(b, 'note'));
    $$('[data-askset]', sh).forEach(b => b.onclick = () => send(b, 'text'));
    const all = $('#ckAll'); if (all) all.onclick = () => act('fix', { all: true });
  };
  const showItem = it => { it.scrollIntoView({ block: 'center' }); it.classList.add('ck-here'); setTimeout(() => it.classList.remove('ck-here'), 2200); };
  draw();
  if (back) { const it = sh.querySelector(`.ck-it[data-k="${back.k}"]`); if (it) showItem(it); else sh.scrollTop = back.top || 0; }
}

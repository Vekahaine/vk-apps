'use strict';
/* =====================================================================
   Page Administration (propriétaire) : ce qu'on peut changer soi-même,
   sans toucher au code. Enregistré sur le serveur en ligne : visible
   tout de suite par tout le monde, sur le site et dans les applis.
   ===================================================================== */
const ADMIN_TABS = [['home', 'Accueil'], ['series', 'Catalogue'], ['playlists', 'Playlists'], ['auto', 'Travaux'], ['community', 'Communauté'], ['download', 'Télécharger VDIZI']];

async function renderAdmin() {
  if (viewer()) { location.hash = '#/'; return; }
  const connected = window.VK_REMOTE || (typeof CLOUD !== 'undefined' && CLOUD && CLOUD.connected);
  const eps = LIB.series.reduce((n, s) => n + s.eps.length, 0), online = LIB.series.reduce((n, s) => n + s.eps.filter(e => e.cloud).length, 0);
  view.innerHTML = `<div class="page" style="max-width:820px"><div class="ph"><h1>Administration</h1></div>
    ${connected ? '' : '<div class="jobcard"><b>Connecte d\'abord VDIZI à ton compte en ligne</b><small>Bouton « En ligne » en haut : les réglages sont enregistrés sur ton serveur.</small></div>'}
    <div class="adm-st"><div><b>${LIB.series.length}</b><small>séries</small></div><div><b>${eps}</b><small>épisodes</small></div><div><b>${online}</b><small>en ligne</small></div><div><b id="admUsers">…</b><small>comptes</small></div><div><b id="admGo">…</b><small>stockage utilisé</small></div></div>

    <h3>Noms des onglets</h3>
    <div class="adm-g">${ADMIN_TABS.map(([k, d]) => `<label>${esc(d)}<input data-lab="${k}" maxlength="24" value="${esc((SITE.labels || {})[k] || '')}" placeholder="${esc(d)}"></label>`).join('')}</div>

    <h3>Message pour tes spectateurs</h3>
    <p class="note">Affiché en haut de l'accueil, pour tout le monde. Laisse vide pour ne rien afficher.</p>
    <textarea id="admMsg" class="adm-t" maxlength="300" rows="2" placeholder="ex : Nouvel épisode de Deha ce soir !">${esc(SITE.announce || '')}</textarea>

    <h3>Calendrier des sorties</h3>
    <p class="note">Annonce les épisodes ou séries à venir : ils apparaissent dans « À venir » sur l'accueil et disparaissent tout seuls une fois la date passée.</p>
    <div id="admCal"></div>
    <button class="btn sm ghost" id="admCalAdd" style="margin-top:8px">${ic('plus')}Ajouter une sortie</button>

    <h3>Couleur principale</h3>
    <div class="adm-c"><input type="color" id="admCol" value="${esc(SITE.accent || '#E11D2E')}"><button class="btn sm ghost" id="admColR">Couleur d'origine</button></div>

    <div class="foot"><button class="btn" id="admSave">${ic('check')}Enregistrer</button></div>

    <h3 style="margin-top:30px">Comptes et inscriptions</h3>
    <div class="cl-guest" id="clGuest"><b>Accès invité</b><small>…</small></div>

    <h3 style="margin-top:30px">Séries et suggestions</h3>
    <p class="note">Sur la page d'une série, le bouton ⋯ permet de la renommer et de changer son image. Ouvre <a href="#/community">${esc(label('community'))}</a> pour traiter les suggestions.</p></div>`;
  const calRow = (x = {}) => {
    const d = document.createElement('div'); d.className = 'adm-cal';
    d.innerHTML = `<input type="date" data-c="date" value="${esc(x.date || '')}"><input data-c="title" maxlength="100" placeholder="Série ou épisode" value="${esc(x.title || '')}"><input data-c="note" maxlength="200" placeholder="Détail (facultatif)" value="${esc(x.note || '')}"><button class="ibtn" title="Retirer">${ic('x')}</button>`;
    $('button', d).onclick = () => d.remove();
    $('#admCal').appendChild(d); return d;
  };
  (SITE.calendar || []).forEach(calRow);
  $('#admCalAdd').onclick = () => $('[data-c=date]', calRow()).focus();
  $('#admColR').onclick = () => { $('#admCol').value = '#E11D2E'; };
  $('#admSave').onclick = async () => {
    const labels = {}; $$('[data-lab]').forEach(i => { const v = i.value.trim(); if (v) labels[i.dataset.lab] = v; });
    const accent = $('#admCol').value.toUpperCase();
    const rows = $$('.adm-cal'), calendar = rows.map(r => ({ date: $('[data-c=date]', r).value, title: $('[data-c=title]', r).value.trim(), note: $('[data-c=note]', r).value.trim() })).filter(x => x.date || x.title);
    if (calendar.some(x => !x.date || !x.title)) return toast('Calendrier : chaque sortie a besoin d\'une date et d\'un nom', true);
    try {
      const s = await api('/api/cloud/site', { method: 'POST', body: { labels, announce: $('#admMsg').value.trim(), accent: accent === '#E11D2E' ? '' : accent, calendar } });
      applySite(s); render(true); toast('Enregistré : visible tout de suite par tout le monde ✓');
    } catch (e) { toast(e.message, true); }
  };
  if (!connected) return;
  if (typeof fillGuest === 'function') fillGuest();
  try { const g = await api('/api/cloud/guest'); const n = $('#admUsers'); if (n) n.textContent = (g.users || []).length; } catch { }
  try { const u = await api('/api/cloud/usage'); const n = $('#admGo'); if (n && u.bytes !== undefined) n.textContent = (u.bytes / 1e9).toFixed(1).replace('.', ',') + ' Go'; } catch { }
}

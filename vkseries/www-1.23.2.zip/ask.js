'use strict';
/* Petite fenêtre de saisie (remplace prompt(), qui n'existe pas dans l'appli PC ni sur Android).
   askText('Nom de la série', 'valeur actuelle') → Promise<string|null> */
function askText(title, value = '', { placeholder = '', ok = 'Valider', multiline = false } = {}) {
  return new Promise(resolve => {
    const wrap = document.createElement('div');
    wrap.className = 'askw';
    wrap.innerHTML = `<form class="askb"><h3></h3>${multiline ? '<textarea rows="4"></textarea>' : '<input type="text" autocomplete="off" spellcheck="false">'}<div class="askf"><button type="button" class="ask-no">Annuler</button><button type="submit" class="ask-ok"></button></div></form>`;
    wrap.querySelector('h3').textContent = title;
    wrap.querySelector('.ask-ok').textContent = ok;
    const inp = wrap.querySelector('input,textarea');
    inp.value = value == null ? '' : String(value); inp.placeholder = placeholder;
    const done = v => { wrap.remove(); document.removeEventListener('keydown', key, true); resolve(v); };
    const key = e => { if (e.key === 'Escape' || e.key === 'GoBack') { e.preventDefault(); e.stopPropagation(); done(null); } else e.stopPropagation(); };
    document.addEventListener('keydown', key, true);
    wrap.querySelector('form').onsubmit = e => { e.preventDefault(); done(inp.value); };
    wrap.querySelector('.ask-no').onclick = () => done(null);
    wrap.addEventListener('mousedown', e => { if (e.target === wrap) done(null); });
    document.body.appendChild(wrap);
    setTimeout(() => { inp.focus(); inp.select(); }, 20);
  });
}
// pour copier un texte quand le presse-papiers est bloqué
function showText(title, text) { return askText(title, text, { ok: 'OK' }); }

'use strict';
/* =====================================================================
   VDIZI — compte en ligne : mettre ses séries en ligne et les regarder partout
   ===================================================================== */
ICONS.cloud = '<path d="M7 18a4.5 4.5 0 0 1-.6-8.96A6 6 0 0 1 18 9.5a4 4 0 0 1-.5 8.5z"/>';
ICONS.cloudup = '<path d="M7 18a4.5 4.5 0 0 1-.6-8.96A6 6 0 0 1 18 9.5a4 4 0 0 1-.5 8.5z"/><path d="M12 15v-5M9.5 12.5 12 10l2.5 2.5"/>';
ICONS.ext = '<path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>';
let CLOUD = { connected: false };
let cloudT = 0, cloudSig = '';
const gb = b => (b / 1e9).toFixed(b > 1e10 ? 0 : 1).replace('.', ',') + ' Go';

async function pollCloud() {
  clearTimeout(cloudT);
  try {
    CLOUD = await api('/api/cloud');
    const busy = !!(CLOUD.cur || (CLOUD.queue || []).length);
    const b = $('#cloudBtn');
    b.innerHTML = busy ? `<span class="spin"></span>En ligne ${CLOUD.cur ? Math.round((CLOUD.cur.p || 0) * 100) + ' %' : '…'}${CLOUD.queue.length ? ` · ${CLOUD.queue.length} en attente` : ''}` : `${ic('cloud')}<span>En ligne</span>`;
    if (CLOUD.anon) b.innerHTML = `${ic('cloud')}<span>Se connecter</span>`;
    b.classList.toggle('on', !!CLOUD.connected);
    const sig = JSON.stringify([(CLOUD.done || []).map(d => d.id + d.ok), CLOUD.queue, CLOUD.cur && CLOUD.cur.id, CLOUD.connected]);
    if (sig !== cloudSig) {
      if (cloudSig) {
        const d = (CLOUD.done || [])[0], prev = JSON.parse(cloudSig)[0];
        if (d && !prev.includes(d.id + d.ok) && d.kind !== 'subs') { const e = EPS.get(d.id); toast(d.ok ? `En ligne ✓ ${e ? seriesOf(e.sid).name + ' ' + epCode(e) : ''}` : `Mise en ligne impossible : ${d.msg}`, !d.ok); }
        await loadLib(); if ($('#player').hidden) render(true);
      }
      cloudSig = sig;
    }
    // on ne rafraîchit que si c'est bien l'écran « En ligne » qui est affiché (pas les noms propres, les réglages…)
    if (!$('#modal').hidden && $('#sheet [data-cloudsheet]')) renderCloud(true);
    cloudT = setTimeout(pollCloud, busy ? 2000 : 15000);
  } catch { cloudT = setTimeout(pollCloud, 6000); }
}
$('#cloudBtn').onclick = () => openCloud();

function openCloud() {
  if (CLOUD.anon) { VK_REMOTE.login('Connecte-toi ou crée un compte gratuit.').then(ok => { if (ok) location.reload(); }); return; }
  $('#sheet').dataset.k = 'cloud'; renderCloud(); $('#modal').hidden = false; }
async function renderCloud(soft) {
  const c = CLOUD, sh = $('#sheet');
  if (soft && sh.querySelector('input:focus')) return;
  if (!c.connected) {
    if (soft) return;
    sh.innerHTML = `<h3 data-cloudsheet>${ic('cloud')} Mes séries en ligne</h3>
      <p class="mut">Mets tes épisodes en ligne (avec leurs sous-titres) pour les regarder sur ton téléphone, ta box TV ou n'importe quel PC, même quand ce PC est éteint. Et ensuite tu peux supprimer les fichiers de ton PC.</p>
      <form id="clf" class="cl-form"><label>Nom du compte<input id="clAcc" placeholder="ex : volkan" autocapitalize="off" spellcheck="false"></label><label>Mot de passe<input id="clPw" type="password"></label><div class="err" id="clErr"></div>
      <div class="foot" style="justify-content:space-between"><button type="button" class="btn ghost" id="clNew">${ic('plus')}Créer mon compte</button><span class="grow"></span><button type="button" class="btn ghost" id="clClose">Fermer</button><button class="btn" type="submit" id="clGo">Se connecter</button></div></form>`;
    $('#clClose').onclick = () => { $('#modal').hidden = true; };
    $('#clNew').onclick = cloudSetup;
    $('#clf').onsubmit = async e => {
      e.preventDefault(); $('#clErr').textContent = ''; $('#clGo').disabled = true;
      try { CLOUD = await api('/api/cloud/login', { method: 'POST', body: { account: $('#clAcc').value.trim(), password: $('#clPw').value } }); toast('Connecté ✓'); renderCloud(); pollCloud(); }
      catch (er) { $('#clErr').textContent = er.message; $('#clGo').disabled = false; }
    };
    setTimeout(() => $('#clAcc')?.focus(), 30);
    return;
  }
  if (c.guest) {
    sh.innerHTML = `<h3 data-cloudsheet>${ic('cloud')} Mes séries en ligne</h3>
      <p>Connecté au compte <b>« ${esc(c.account)} »</b> en <b>invité</b> : tu peux regarder les séries mises en ligne, sur cet appareil ou n'importe où.</p>
      <div class="foot"><button class="btn ghost" id="clOut">Se déconnecter</button><span class="grow"></span><button class="btn ghost" id="clWeb">${ic('ext')}Regarder les séries en ligne</button><button class="btn" id="clClose">Fermer</button></div>`;
    $('#clClose').onclick = () => { $('#modal').hidden = true; };
    $('#clWeb').onclick = () => window.open(c.web, '_blank');
    $('#clOut').onclick = async () => { CLOUD = await api('/api/cloud/logout', { method: 'POST' }); renderCloud(); pollCloud(); };
    return;
  }
  // rafraîchissement automatique : on garde tels quels les blocs déjà remplis (formulaires, usage)
  const keep = soft ? ['clStore', 'clGuest', 'clUse'].map(id => document.getElementById(id)).filter(Boolean) : [];
  const cur = c.cur, ups = [...EPS.values()].filter(e => e.cloud);
  const fails = (c.done || []).filter(d => !d.ok).slice(0, 3);
  sh.innerHTML = `<h3 data-cloudsheet>${ic('cloud')} Mes séries en ligne</h3>
    <p class="mut">Compte <b>« ${esc(c.account)} »</b> · ${ups.length} épisode${ups.length > 1 ? 's' : ''} en ligne<span id="clUse"></span>${c.error ? ` · <span style="color:#ff6b6b">${esc(c.error)}</span>` : ''}</p>
    ${!c.storage ? `<div class="cl-warn" id="clStore">…</div>` : `<div class="cl-guest" id="clStore"><b>Stockage des vidéos</b><small>…</small></div>`}
    ${cur ? `<div class="cl-cur"><div class="cl-h"><b>${esc(cur.name)} ${cur.ep ? epCode(cur.ep) : ''}</b><button class="btn sm ghost" id="clCancel">Annuler</button></div><small>${esc(cur.phase)}${cur.size ? ` · ${gb(cur.sent || 0)} / ${gb(cur.size)}` : ''}</small><div class="pbar big"><i style="width:${((cur.p || 0) * 100).toFixed(1)}%"></i></div></div>` : ''}
    ${(c.queue || []).length ? `<p class="mut">${c.queue.length} épisode${c.queue.length > 1 ? 's' : ''} en attente. Garde VDIZI ouvert pendant l'envoi.</p>` : ''}
    ${fails.map(d => { const e = EPS.get(d.id); return `<p class="cl-fail">${e ? esc(seriesOf(e.sid).name + ' ' + epCode(e)) + ' : ' : ''}${esc(d.msg || '')}</p>`; }).join('')}
    ${!cur && !ups.length && c.storage ? `<p>Pour mettre une série en ligne : ouvre-la, puis <b>⋯ → Mettre la série en ligne</b>. Ou sur un épisode : clic droit → <b>Mettre en ligne</b>.</p>` : ''}
    <p class="mut" style="margin-top:14px">Pour regarder ailleurs (téléphone, box TV, autre PC) : va sur <b>${esc((c.site || c.url || '').replace(/^https?:\/\//, ''))}</b> dans n'importe quel navigateur.</p>
    ${c.storage ? `<div class="cl-guest" id="clGuest"><b>Accès invité</b><small>…</small></div>` : ''}
    <div class="foot"><button class="btn ghost" id="clOut">Se déconnecter</button><span class="grow"></span>${c.storage ? `<button class="btn ghost" id="clWeb">${ic('ext')}Ouvrir mes séries en ligne</button>` : ''}<button class="btn" id="clClose">Fermer</button></div>`;
  for (const o of keep) { const n = document.getElementById(o.id); if (n) n.replaceWith(o); }
  $('#clClose').onclick = () => { $('#modal').hidden = true; };
  $('#clOut').onclick = async () => { if (!confirm('Se déconnecter du compte sur ce PC ?\n\nTes épisodes déjà en ligne y restent.')) return; CLOUD = await api('/api/cloud/logout', { method: 'POST' }); renderCloud(); pollCloud(); };
  const w = $('#clWeb'); if (w) w.onclick = () => window.open(c.web, '_blank');
  const x = $('#clCancel'); if (x) x.onclick = async () => { await api('/api/cloud/cancel', { method: 'POST', body: { id: cur.id } }); pollCloud(); };
  if (!keep.some(o => o.id === 'clStore')) fillStorage(!c.storage);
  if (c.storage && !keep.some(o => o.id === 'clGuest')) fillGuest();
  if (c.storage && !keep.some(o => o.id === 'clUse')) api('/api/cloud/usage').then(u => { const el = $('#clUse'); if (el) el.textContent = ` · ${gb(u.bytes)} utilisés sur ${gb(u.limit)}`; }).catch(() => { });
}

/* stockage des vidéos : bucket S3 (ex. Railway) ou disque en ligne WebDAV (ex. Hetzner Storage Box) */
async function fillStorage(open) {
  const box = $('#clStore'); if (!box) return;
  let st = {}; try { st = await api('/api/cloud/storage'); } catch { }
  const form = (type = st.kind === 'dav' ? 'dav' : 's3', msg = '') => {
    const same = st.kind === type;
    const keep = same ? 'inchangé si vide' : '';
    box.innerHTML = `<b>${CLOUD.storage ? 'Changer de stockage' : 'Branche ton stockage en ligne pour mettre tes séries en ligne'}</b>
      <div class="cl-tabs"><button type="button" class="btn sm ${type === 's3' ? '' : 'ghost'}" data-t="s3">Railway (bucket)</button><button type="button" class="btn sm ${type === 'dav' ? '' : 'ghost'}" data-t="dav">Disque WebDAV (Hetzner…)</button></div>
      ${type === 's3' ? `<small>Sur Railway : ouvre ton projet → <b>Create</b> → <b>Bucket</b>. Ouvre le bucket → onglet <b>Credentials</b>, et recopie ici les valeurs. Elles restent cachées dans ton serveur : personne d'autre ne les voit.</small>
      <form id="clsf" class="cl-form"><label>Endpoint<input id="csEp" placeholder="https://t3.storageapi.dev" value="${same ? esc('https://' + st.host) : ''}" autocapitalize="off" spellcheck="false"></label>
      <label>Nom du bucket (Bucket name)<input id="csBucket" value="${same ? esc(st.bucket) : ''}" autocapitalize="off" spellcheck="false"></label>
      <label>Access Key ID<input id="csKey" placeholder="${keep}" autocomplete="off" spellcheck="false"></label>
      <label>Secret Access Key<input id="csSecret" type="password" placeholder="${keep}" autocomplete="off"></label>
      <label>Région<input id="csRegion" value="${esc(same && st.region || 'auto')}" autocapitalize="off" spellcheck="false"></label>
      <label>Limite de sécurité (Go)<input id="csGo" type="number" min="1" value="${same && st.go || 250}"><small class="mut" style="font-weight:400">Railway : 0,015 $ par Go et par mois → 250 Go ≈ 3,75 $/mois. Ton serveur refusera tout envoi au-delà.</small></label>`
      : `<small>Ex. Hetzner Storage Box : active <b>WebDAV</b> et <b>« Accessible de l'extérieur »</b>, puis recopie ici l'adresse, l'identifiant et le mot de passe. Ils restent cachés dans ton serveur.</small>
      <form id="clsf" class="cl-form"><label>Adresse<input id="csUrl" placeholder="u123456.your-storagebox.de" value="${same ? esc(st.host) : ''}" autocapitalize="off" spellcheck="false"></label>
      <label>Identifiant<input id="csUser" placeholder="u123456" value="${same ? esc(st.user) : ''}" autocapitalize="off" spellcheck="false"></label>
      <label>Mot de passe<input id="csPass" type="password" placeholder="${keep}"></label>
      <label>Taille payée (Go)<input id="csGo" type="number" min="1" value="${same && st.go || 1000}"></label>`}
      <div class="err" id="csErr">${esc(msg)}</div>
      <div class="foot">${CLOUD.storage ? '<button type="button" class="btn ghost" id="csBack">Annuler</button>' : ''}<span class="grow"></span><button class="btn" type="submit" id="csGo2">${ic('cloud')}Brancher le stockage</button></div></form>`;
    box.querySelectorAll('[data-t]').forEach(b => b.onclick = () => form(b.dataset.t));
    const back = $('#csBack'); if (back) back.onclick = () => fillStorage(false);
    $('#clsf').onsubmit = async e => {
      e.preventDefault(); $('#csErr').textContent = 'Vérification du stockage… (jusqu\'à 1 minute)'; $('#csGo2').disabled = true;
      const v = id => ($('#' + id) || {}).value || '';
      const body = type === 's3' ? { type, endpoint: v('csEp').trim(), bucket: v('csBucket').trim(), key: v('csKey').trim(), secret: v('csSecret').trim(), region: v('csRegion').trim(), go: +v('csGo') || 250 }
        : { type, url: v('csUrl').trim(), user: v('csUser').trim(), pass: v('csPass'), go: +v('csGo') || 1000 };
      try { CLOUD = await api('/api/cloud/storage', { method: 'POST', body }); toast('Stockage des vidéos branché ✓'); renderCloud(); }
      catch (er) { $('#csErr').textContent = er.message; $('#csGo2').disabled = false; }
    };
  };
  if (open || st.old) {
    if (st.old) { box.className = 'cl-warn'; box.innerHTML = 'Ton serveur doit être mis à jour : ouvre VDIZI sur le PC où tu as créé le compte.'; return; }
    box.className = CLOUD.storage ? 'cl-guest' : 'cl-warn'; return form();
  }
  box.className = 'cl-guest';
  const what = st.kind === 's3' ? `✓ Bucket <b>${esc(st.bucket)}</b> (${esc(st.host)}) · limite de sécurité : ${st.go} Go`
    : st.kind === 'dav' ? `✓ Disque en ligne <b>${esc(st.host)}</b> (${esc(st.user)}) · limite de sécurité : 95 % de ${st.go} Go` : st.kind === 'r2' ? '✓ Cloudflare R2' : '—';
  box.innerHTML = `<b>Stockage des vidéos</b><small>${what} · <a href="#" id="csEdit">Modifier</a></small>`;
  $('#csEdit').onclick = e => { e.preventDefault(); box.className = 'cl-guest'; form(); };
}

/* mot de passe invité : regarder les séries, rien d'autre */
async function fillGuest(msg) {
  const box = $('#clGuest'); if (!box) return;
  let g = { enabled: false };
  try { g = await api('/api/cloud/guest'); } catch (e) { box.innerHTML = `<b>Accès invité</b><small style="color:#ff8a8a">${esc(e.message)}</small>`; return; }
  box.innerHTML = `<b>Accès invité</b>
    <small>${g.enabled ? '✓ Activé. ' : ''}Donne ce mot de passe aux personnes avec qui tu partages tes séries : elles pourront <b>seulement regarder</b> (rien ajouter, modifier ou supprimer).${g.enabled ? ' Changer le mot de passe déconnecte les invités actuels.' : ''}</small>
    <form id="clgf" class="cl-ginl"><input id="clGpw" type="text" placeholder="${g.enabled ? 'nouveau mot de passe invité' : 'mot de passe invité'}" autocomplete="off" spellcheck="false"><button class="btn sm" type="submit">${g.enabled ? 'Changer' : 'Activer'}</button>${g.enabled ? '<button class="btn sm ghost" type="button" id="clGoff">Désactiver</button>' : ''}</form>
    <small class="cl-gmsg" id="clGmsg">${esc(msg || '')}</small>
    <div class="cl-users"><b>Comptes spectateurs (${(g.users || []).length})</b>
      <small>Chacun peut créer son compte sur le site avec un e-mail et un mot de passe, pour regarder seulement. Ton PC n'a pas besoin d'être allumé.</small>
      <label class="cl-sw"><input type="checkbox" id="clSignup" ${g.signup !== false ? 'checked' : ''}> Inscriptions ouvertes</label>
      ${(g.users || []).map(u => `<div class="cl-user"><span>${esc(u.email || u.id)}</span><small>${u.at ? new Date(u.at).toLocaleDateString('fr-FR') : ''}</small><button class="btn sm ghost" data-rmu="${esc(u.id)}">Supprimer</button></div>`).join('')}</div>`;
  $('#clSignup').onchange = async e => { try { await api('/api/cloud/guest', { method: 'POST', body: { signup: e.target.checked } }); fillGuest(e.target.checked ? 'Inscriptions ouvertes' : 'Inscriptions fermées'); } catch (er) { $('#clGmsg').textContent = er.message; } };
  $$('[data-rmu]', box).forEach(b => b.onclick = async () => { if (!confirm('Supprimer ce compte ?\n\nLa personne sera déconnectée tout de suite.')) return; try { await api('/api/cloud/guest', { method: 'POST', body: { removeUser: b.dataset.rmu } }); fillGuest('Compte supprimé'); } catch (er) { $('#clGmsg').textContent = er.message; } });
  $('#clgf').onsubmit = async e => {
    e.preventDefault(); const pw = $('#clGpw').value.trim(); if (pw.length < 4) { $('#clGmsg').textContent = '4 caractères minimum'; return; }
    $('#clGmsg').textContent = 'Un instant…';
    try { await api('/api/cloud/guest', { method: 'POST', body: { password: pw } }); fillGuest(`✓ Mot de passe invité : « ${pw} » — à donner avec le nom du compte « ${CLOUD.account} »`); }
    catch (er) { $('#clGmsg').textContent = er.message; }
  };
  const off = $('#clGoff'); if (off) off.onclick = async () => { if (!confirm('Désactiver l\'accès invité ?\n\nLes invités seront déconnectés tout de suite.')) return; try { await api('/api/cloud/guest', { method: 'POST', body: { off: true } }); fillGuest('Accès invité désactivé'); } catch (er) { $('#clGmsg').textContent = er.message; } };
}

function cloudSetup() {
  const sh = $('#sheet');
  sh.innerHTML = `<h3>${ic('cloud')} Créer mon compte en ligne</h3>
    <p class="mut">Un petit serveur rien qu'à toi, gratuit, chez Cloudflare. À faire une seule fois.</p>
    <ol class="cl-ol">
      <li><b>Crée un compte Cloudflare</b> et confirme ton e-mail. <a href="https://dash.cloudflare.com/sign-up" target="_blank">Ouvrir</a></li>
      <li><b>Crée un jeton</b> : Profil → Jetons d'API → Créer un jeton → modèle <b>« Edit Cloudflare Workers »</b> → Utiliser le modèle → Ressources du compte : ton compte · Ressources de zone : Toutes les zones → Continuer → Créer le jeton → copie-le. <a href="https://dash.cloudflare.com/profile/api-tokens" target="_blank">Ouvrir les jetons</a></li>
    </ol>
    <form id="cls" class="cl-form"><label>Jeton Cloudflare<input id="clTok" autocomplete="off" spellcheck="false"></label><label>Nom du compte<input id="clName" placeholder="ex : volkan" autocapitalize="off" spellcheck="false"></label><label>Mot de passe<input id="clP1" type="password"></label><label>Mot de passe (encore)<input id="clP2" type="password"></label><div class="err" id="clErr"></div>
    <div class="foot"><button type="button" class="btn ghost" id="clBack">Retour</button><span class="grow"></span><button class="btn" type="submit" id="clGo">${ic('cloud')}Créer mon compte</button></div></form>
    <div class="cl-prog" id="clProg" hidden><span class="spin"></span><span id="clStep">…</span></div>`;
  $('#clBack').onclick = () => renderCloud();
  $('#cls').onsubmit = async e => {
    e.preventDefault(); $('#clErr').textContent = '';
    const p1 = $('#clP1').value;
    if (!$('#clTok').value.trim()) return $('#clErr').textContent = 'Colle le jeton Cloudflare (étape 3)';
    if (p1.length < 4) return $('#clErr').textContent = 'Mot de passe : 4 caractères minimum';
    if (p1 !== $('#clP2').value) return $('#clErr').textContent = 'Les deux mots de passe sont différents';
    try { await api('/api/cloud/setup', { method: 'POST', body: { cfToken: $('#clTok').value.trim(), name: $('#clName').value.trim(), password: p1 } }); } catch (er) { return $('#clErr').textContent = er.message; }
    $('#cls').hidden = true; $('#clProg').hidden = false;
    const poll = async () => {
      const c = await api('/api/cloud').catch(() => ({})), s = c.setup || {};
      if (s.error) { $('#clProg').hidden = true; $('#cls').hidden = false; $('#clErr').textContent = s.error; return; }
      if (s.done) { CLOUD = c; toast(`Compte « ${s.account} » créé ✓`); renderCloud(); pollCloud(); return; }
      $('#clStep').textContent = (s.step || 'Installation') + '…'; setTimeout(poll, 900);
    };
    poll();
  };
}

/* ---------- menus */
async function cloudUpload(ids) {
  if (!CLOUD.connected) return openCloud();
  if (!CLOUD.storage) { openCloud(); return toast("Active d'abord le stockage des vidéos", true); }
  try { const r = await api('/api/cloud/upload', { method: 'POST', body: { ids } }); toast(r.added ? `${r.added} épisode${r.added > 1 ? 's' : ''} en cours de mise en ligne · garde VDIZI ouvert` : 'Déjà en ligne'); CLOUD = r.cloud; pollCloud(); await loadLib(); render(true); }
  catch (e) { toast(e.message, true); }
}
async function cloudRemove(ids, label) {
  if (!confirm(`Retirer ${label} d'internet ?\n\nLes fichiers sur ton PC ne sont pas touchés.`)) return;
  try { await api('/api/cloud/remove', { method: 'POST', body: { ids } }); toast("Retiré d'internet"); await loadLib(); render(true); pollCloud(); }
  catch (e) { toast(e.message, true); }
}
function cloudEpItems(e) {
  if (CLOUD.guest) return [];
  if (e.upq) return [{ label: 'Mise en ligne en cours… (annuler)', icon: 'cloudup', act: async () => { await api('/api/cloud/cancel', { method: 'POST', body: { id: e.id } }); await loadLib(); render(true); pollCloud(); } }];
  if (e.cloud) return [{ label: "Retirer d'internet", icon: 'cloud', act: () => cloudRemove([e.id], 'cet épisode') }];
  return e.missing ? [] : [{ label: 'Mettre en ligne', icon: 'cloudup', act: () => cloudUpload([e.id]) }];
}
function cloudSeriesItems(s) {
  if (CLOUD.guest) return [];
  const todo = s.eps.filter(e => !e.cloud && !e.upq && !e.missing).map(e => e.id), on = s.eps.filter(e => e.cloud).map(e => e.id);
  const out = [];
  if (todo.length) out.push({ label: `Mettre la série en ligne (${todo.length} épisode${todo.length > 1 ? 's' : ''})`, icon: 'cloudup', act: () => cloudUpload(todo) });
  if (on.length) out.push({ label: `Retirer la série d'internet (${on.length})`, icon: 'cloud', act: () => cloudRemove(on, `les ${on.length} épisodes en ligne de « ${s.name} »`) });
  return out;
}
// épisode dont le fichier n'est plus sur ce PC mais qui est en ligne : on le lit en ligne
function playOnline(e) { if (window.VK_REMOTE || !CLOUD.web) return false; window.open(CLOUD.web + '&p=' + e.id, '_blank'); return true; }

pollCloud();

/* ---------- mises à jour automatiques : bandeau « nouvelle version prête » */
let UPD_HIDE = false;
async function updLoad() {
  let s; try { s = await api('/api/update'); } catch { return; }
  if (s.current) { const v = $('#appVer'); if (v) { v.textContent = 'v' + s.current; v.title = s.status === 'uptodate' ? 'À jour' : s.status === 'downloading' ? 'Téléchargement de la mise à jour…' : ''; } }
  let b = $('#upd');
  if (!b) { b = document.createElement('div'); b.id = 'upd'; b.className = 'upd'; document.body.appendChild(b); }
  b.hidden = UPD_HIDE || s.status !== 'ready';
  if (b.hidden) return;
  b.innerHTML = `${ic('refresh')}<span><b>VDIZI ${esc(s.version)}</b> est prête${s.notes ? ' · ' + esc(s.notes) : ''}</span><button class="btn sm" id="updGo">Redémarrer maintenant</button><button class="btn sm ghost" id="updLater">Plus tard</button>`;
  $('#updGo').onclick = async () => {
    try { await api('/api/update/apply', { method: 'POST' }); document.body.insertAdjacentHTML('beforeend', '<div style="position:fixed;inset:0;z-index:2000;display:grid;place-content:center;color:#aaa;font:16px system-ui;background:#0a0a0a">Mise à jour de VDIZI… elle va se rouvrir toute seule.</div>'); }
    catch (e) { toast(e.message, true); }
  };
  $('#updLater').onclick = () => { UPD_HIDE = true; b.hidden = true; toast("La mise à jour s'installera au prochain lancement de VDIZI"); };
}
updLoad(); setTimeout(updLoad, 25000); setInterval(updLoad, 60e3);

/* bouton « Mettre à jour » (Réglages) : vérifie, télécharge et installe d'un coup */
async function fillUpdRow(msg) {
  let s = {}; try { s = await api('/api/update'); } catch { }
  const v = $('#setVer'), t = $('#updTxt'), b = $('#updNow'); if (!b) return;
  if (v) v.textContent = s.current || '';
  if (t) t.innerHTML = msg || ({ uptodate: '✓ Tu as la dernière version', downloading: `Téléchargement de la ${esc(s.version || '')}…`, ready: `La version ${esc(s.version)} est prête à être installée`, error: `Dernière vérification impossible (${esc(s.error || '')})`, manual: `La version ${esc(s.version || '')} demande un nouveau fichier d'installation : demande-le à Claude` }[s.status] || 'Les mises à jour se font automatiquement');
  b.onclick = async () => {
    b.disabled = true; b.innerHTML = '<span class="spin" style="width:14px;height:14px;border-width:2px"></span>Recherche…';
    if (t) t.textContent = 'Recherche d\'une nouvelle version…';
    let r = {}; try { r = await api('/api/update/check', { method: 'POST' }); } catch (e) { r = { status: 'error', error: e.message }; }
    if (r.status === 'ready') {
      if (t) t.textContent = `Installation de la version ${r.version}… VDIZI va se rouvrir tout seul.`;
      try { const a = await api('/api/update/apply', { method: 'POST' }); if (!a.ok) throw new Error('Ferme VDIZI puis rouvre-le depuis le raccourci du Bureau : la mise à jour s\'installera à l\'ouverture'); document.body.insertAdjacentHTML('beforeend', '<div style="position:fixed;inset:0;z-index:2000;display:grid;place-content:center;color:#aaa;font:16px system-ui;background:#0a0a0a">Mise à jour de VDIZI… elle va se rouvrir toute seule.</div>'); }
      catch (e) { toast(e.message, true); fillUpdRow(); b.disabled = false; b.innerHTML = `${ic('refresh')}Mettre à jour`; }
      return;
    }
    b.disabled = false; b.innerHTML = `${ic('refresh')}Mettre à jour`;
    fillUpdRow(r.status === 'off' ? 'Les mises à jour automatiques marchent sur l\'appli PC installée' : '');
  };
}
{ const v = $('#appVer'); if (v) { v.style.cursor = 'pointer'; v.title = 'Version : clique pour mettre à jour'; v.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); openSettings(); }); } }

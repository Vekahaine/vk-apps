'use strict';
/* =====================================================================
   Page Administration (propriétaire) : ce qu'on peut changer soi-même,
   sans toucher au code. Enregistré sur le serveur en ligne : visible
   tout de suite par tout le monde, sur le site et dans les applis.
   ===================================================================== */
const ADMIN_TABS = [['home', 'Accueil'], ['series', 'Catalogue'], ['playlists', 'Playlists'], ['auto', 'Travaux'], ['community', 'Communauté'], ['download', 'Télécharger VDIZI']];

async function renderAdmin() {
  if (viewer()) { location.hash = '#/'; return; }
  const connected = window.VK_REMOTE || (typeof CLOUD !== 'undefined' && CLOUD && CLOUD.connected);
  const eps = LIB.series.reduce((n, s) => n + s.eps.length, 0), online = LIB.series.reduce((n, s) => n + s.eps.filter(e => e.cloud).length, 0);
  view.innerHTML = `<div class="page" style="max-width:820px"><div class="ph"><h1>Administration</h1></div>
    ${connected ? '' : '<div class="jobcard"><b>Connecte d\'abord VDIZI à ton compte en ligne</b><small>Bouton « En ligne » en haut : les réglages sont enregistrés sur ton serveur.</small></div>'}
    <div class="adm-st"><div><b>${LIB.series.length}</b><small>séries</small></div><div><b>${eps}</b><small>épisodes</small></div><div><b>${online}</b><small>en ligne</small></div><div><b id="admUsers">…</b><small>comptes</small></div><div><b id="admGo">…</b><small>stockage utilisé</small></div></div>

    <h3>Noms des onglets</h3>
    <div class="adm-g">${ADMIN_TABS.map(([k, d]) => `<label>${esc(d)}<input data-lab="${k}" maxlength="24" value="${esc((SITE.labels || {})[k] || '')}" placeholder="${esc(d)}"></label>`).join('')}</div>

    <h3>Message pour tes spectateurs</h3>
    <p class="note">Affiché en haut de l'accueil, pour tout le monde. Laisse vide pour ne rien afficher.</p>
    <textarea id="admMsg" class="adm-t" maxlength="300" rows="2" placeholder="ex : Nouvel épisode de Deha ce soir !">${esc(SITE.announce || '')}</textarea>

    <h3>Calendrier des sorties</h3>
    <p class="note">Annonce les épisodes ou séries à venir : ils apparaissent dans « À venir » sur l'accueil et disparaissent tout seuls une fois la date passée.</p>
    <div id="admCal"></div>
    <button class="btn sm ghost" id="admCalAdd" style="margin-top:8px">${ic('plus')}Ajouter une sortie</button>

    <h3>Couleur principale</h3>
    <div class="adm-c"><input type="color" id="admCol" value="${esc(SITE.accent || '#E11D2E')}"><button class="btn sm ghost" id="admColR">Couleur d'origine</button></div>

    <div class="foot"><button class="btn" id="admSave">${ic('check')}Enregistrer</button></div>

    <h3 style="margin-top:30px">Clés IA (sous-titres)</h3>
    <div id="admKeys"><p class="note">Chargement…</p></div>

    <h3 style="margin-top:30px">Séries protégées par mot de passe</h3>
    <p class="note">Une série protégée reste visible dans le catalogue (nom et image, avec un cadenas), mais ses épisodes ne s'ouvrent qu'avec le mot de passe que tu choisis. Toi, tu as toujours accès à tout.</p>
    <div id="admLocks"></div>

    <h3 style="margin-top:30px">Mon mot de passe (propriétaire)</h3>
    <div id="admPw"></div>

    <h3 style="margin-top:30px">Comptes et inscriptions</h3>
    <div class="cl-guest" id="clGuest"><b>Accès invité</b><small>…</small></div>

    <h3 style="margin-top:30px">Séries et suggestions</h3>
    <p class="note">Sur la page d'une série, le bouton ⋯ permet de la renommer et de changer son image. Ouvre <a href="#/community">${esc(label('community'))}</a> pour traiter les suggestions.</p></div>`;
  const calRow = (x = {}) => {
    const d = document.createElement('div'); d.className = 'adm-cal';
    d.innerHTML = `<input type="date" data-c="date" value="${esc(x.date || '')}"><input data-c="title" maxlength="100" placeholder="Série ou épisode" value="${esc(x.title || '')}"><input data-c="note" maxlength="200" placeholder="Détail (facultatif)" value="${esc(x.note || '')}"><button class="ibtn" title="Retirer">${ic('x')}</button>`;
    $('button', d).onclick = () => d.remove();
    $('#admCal').appendChild(d); return d;
  };
  (SITE.calendar || []).forEach(calRow);
  $('#admCalAdd').onclick = () => $('[data-c=date]', calRow()).focus();
  $('#admColR').onclick = () => { $('#admCol').value = '#E11D2E'; };
  $('#admSave').onclick = async () => {
    const labels = {}; $$('[data-lab]').forEach(i => { const v = i.value.trim(); if (v) labels[i.dataset.lab] = v; });
    const accent = $('#admCol').value.toUpperCase();
    const rows = $$('.adm-cal'), calendar = rows.map(r => ({ date: $('[data-c=date]', r).value, title: $('[data-c=title]', r).value.trim(), note: $('[data-c=note]', r).value.trim() })).filter(x => x.date || x.title);
    if (calendar.some(x => !x.date || !x.title)) return toast('Calendrier : chaque sortie a besoin d\'une date et d\'un nom', true);
    try {
      const s = await api('/api/cloud/site', { method: 'POST', body: { labels, announce: $('#admMsg').value.trim(), accent: accent === '#E11D2E' ? '' : accent, calendar } });
      applySite(s); render(true); toast('Enregistré : visible tout de suite par tout le monde ✓');
    } catch (e) { toast(e.message, true); }
  };
  admKeysInit(); // les clés sont sur le PC : pas besoin du compte en ligne
  if (!connected) { $('#admLocks').innerHTML = $('#admPw').innerHTML = '<p class="note">Connecte d\'abord VDIZI à ton compte en ligne.</p>'; return; }
  admLocksInit(); admPwInit();
  if (typeof fillGuest === 'function') fillGuest();
  try { const g = await api('/api/cloud/guest'); const n = $('#admUsers'); if (n) n.textContent = (g.users || []).length; } catch { }
  try { const u = await api('/api/cloud/usage'); const n = $('#admGo'); if (n && u.bytes !== undefined) n.textContent = (u.bytes / 1e9).toFixed(1).replace('.', ',') + ' Go'; } catch { }
}

/* =====================================================================
   Clés IA (sous-titres) : liste, état en direct, ajout et retrait — propriétaire seulement
   ===================================================================== */
const KEY_LINKS = {
  groq: { name: 'Groq', role: 'écoute des dialogues', console: 'https://console.groq.com/keys', how: 'Ouvre console.groq.com/keys, connecte-toi avec une adresse Google, clique « Create API Key », puis copie la clé (gsk_…).' },
  gemini: { name: 'Gemini', role: 'traduction', console: 'https://aistudio.google.com/apikey', how: 'Ouvre aistudio.google.com/apikey avec une adresse Google, clique « Créer une clé API », puis copie la clé.' },
};
let KEYS_T = 0, KEYS_TEST = {}; // résultats des tests (par id de clé)
const hhmm = t => new Date(t).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
function keyState(k) {
  const L = k.live || {}, t = KEYS_TEST[k.id];
  if (t && t.state === 'refused') return ['bad', '❌ Refusée', t.message || 'clé invalide ou supprimée : retire-la'];
  if (t && t.state === 'testing') return ['run', '⏳ Test en cours…', ''];
  if (L.busyUntil) return ['warn', `⏸️ Saturée jusqu'à ${hhmm(L.busyUntil)}`, L.lastErrCode === 'quota' ? 'limite gratuite du jour atteinte' : 'trop de demandes : le relais passe aux autres clés'];
  if (t && t.state === 'quota') return ['warn', '⛔ Limite du jour atteinte', t.message || ''];
  if (t && t.state === 'busy') return ['warn', '⏸️ Saturée en ce moment', t.message || ''];
  if (t && (t.state === 'net' || t.state === 'error')) return ['warn', '⚠️ Ne répond pas', t.message || ''];
  if (L.inflight) return ['run', '🔄 En cours d\'utilisation', ''];
  if (t && t.state === 'ok') return ['ok', '✅ Fonctionne', t.ms ? `répond en ${(t.ms / 1000).toFixed(1).replace('.', ',')} s` : 'clé valide'];
  return ['ok', '✅ Prête', ''];
}
function keysHTML(d) {
  const by = kind => d.keys.filter(k => k.kind === kind);
  const block = kind => {
    const ks = by(kind), L = KEY_LINKS[kind], okN = ks.filter(k => keyState(k)[0] === 'ok' || keyState(k)[0] === 'run').length;
    const tip = kind === 'gemini' && ks.length < 3 ? `<p class="note">💡 Ajoute ${3 - ks.length} clé${3 - ks.length > 1 ? 's' : ''} Gemini de plus (chacune d'une <b>autre adresse Google</b>) : quand une clé sature, la suivante prend le relais toute seule, sans attente.</p>`
      : kind === 'groq' && ks.length < 2 ? `<p class="note">💡 Une 2ᵉ clé Groq (d'une <b>autre adresse Google</b>) évite d'attendre quand l'écoute sature.</p>` : '';
    return `<div class="keyblk"><div class="keyhd"><b>${L.name}</b> <small>— ${L.role} · ${ks.length} clé${ks.length > 1 ? 's' : ''} · ${okN}/${ks.length} disponible${okN > 1 ? 's' : ''}</small><a class="btn sm ghost" href="${L.console}" target="_blank" rel="noopener">${ic('ext')}Créer / gérer mes clés ${L.name}</a></div>
      ${ks.length ? ks.map(k => { const [cls, st, sub] = keyState(k), Lv = k.live || {}; return `<div class="keyrow ${cls}" data-kid="${k.id}">
        <div class="grow"><b>${k.main ? 'Principale' : 'Relais ' + k.n}</b> <code>${esc(k.mask)}</code>${k.label ? ` <span class="klab">${esc(k.label)}</span>` : ''}
          <div class="kst">${st}${sub ? ` <small>· ${esc(sub)}</small>` : ''}</div>
          <small class="kday">Aujourd'hui : ${Lv.ok || 0} réussite${Lv.ok > 1 ? 's' : ''} · ${Lv.fail || 0} erreur${Lv.fail > 1 ? 's' : ''}${Lv.lastOk ? ' · dernier succès ' + hhmm(Lv.lastOk) : ''}${Lv.lastErr ? ` · dernière erreur ${hhmm(Lv.lastErrAt)} : ${esc(Lv.lastErr.slice(0, 90))}` : ''}</small></div>
        <div class="kbtn"><button class="btn sm ghost" data-kt="${k.id}" title="Une toute petite vraie demande (≈ 1 requête du quota gratuit)">Tester</button><button class="btn sm ghost" data-kl="${k.id}">Nommer</button>${k.main ? '' : `<button class="btn sm ghost" data-km="${k.id}">Mettre en 1er</button>`}<button class="btn sm ghost" data-kr="${k.id}">Retirer</button></div></div>`; }).join('')
      : `<div class="keyrow bad"><div class="grow"><b>Aucune clé</b><div class="kst">${kind === 'groq' ? 'Obligatoire pour sous-titrer' : 'Recommandé pour une traduction de qualité'}</div></div></div>`}
      ${tip}<p class="note" style="margin-top:4px">Nouvelle clé : ${L.how}</p></div>`;
  };
  return `<p class="note">Tes clés restent sur ton PC. L'état se met à jour tout seul toutes les 3 secondes pendant que cette page est ouverte.</p>
    ${block('groq')}${block('gemini')}
    <div class="keyadd"><b>Ajouter une clé</b><small>Colle une clé Groq (gsk_…) ou Gemini (AIza… / AQ.…) : VDIZI la reconnaît, la teste et l'ajoute aux relais tout seul.</small>
      <div class="kform"><input id="kNew" placeholder="Colle la clé ici" autocomplete="off" spellcheck="false"><input id="kNewLab" placeholder="Nom (facultatif) : ex. compte Google de Sara" maxlength="60"><button class="btn" id="kAdd">${ic('plus')}Ajouter</button></div>
      <span class="kres" id="kAddRes"></span></div>`;
}
async function admKeysInit() {
  const box = $('#admKeys'); if (!box) return;
  clearTimeout(KEYS_T);
  let d; try { d = await api('/api/keys/list'); if (!d || !Array.isArray(d.keys)) throw new Error(d && d.error || 'PC éteint'); }
  catch (e) { box.innerHTML = `<div class="jobcard"><b>Clés IA indisponibles</b><small>${esc(/éteint|PC/i.test(e.message) ? 'Ton PC est éteint : les clés sont sur le PC. Ouvre VDIZI dessus pour les voir ici.' : e.message)}</small></div>`; return; }
  const draw = dd => {
    const focus = document.activeElement && document.activeElement.id, nv = ($('#kNew') || {}).value || '', nl = ($('#kNewLab') || {}).value || '';
    box.innerHTML = keysHTML(dd);
    if ($('#kNew')) { $('#kNew').value = nv; $('#kNewLab').value = nl; } if (focus && $('#' + focus)) $('#' + focus).focus();
    bind();
  };
  const act = async (url, body, msg) => { try { const r = await api(url, { method: 'POST', body }); d = r; draw(d); if (msg) toast(msg); } catch (e) { toast(e.message, true); } };
  const test = async (id, deep) => { KEYS_TEST[id] = { state: 'testing' }; draw(d); try { KEYS_TEST[id] = await api('/api/keys/test', { method: 'POST', body: { id, deep } }); } catch (e) { KEYS_TEST[id] = { state: 'net', message: e.message }; } draw(d); };
  function bind() {
    $$('[data-kt]', box).forEach(b => b.onclick = () => test(b.dataset.kt, true));
    $$('[data-kr]', box).forEach(b => b.onclick = () => { if (confirm('Retirer cette clé de VDIZI ? (elle reste valable chez Groq/Google : tu peux la supprimer là-bas avec le bouton « Créer / gérer »)')) act('/api/keys/remove', { id: b.dataset.kr }, 'Clé retirée'); });
    $$('[data-km]', box).forEach(b => b.onclick = () => act('/api/keys/main', { id: b.dataset.km }, 'Clé mise en premier'));
    $$('[data-kl]', box).forEach(b => b.onclick = () => { const k = d.keys.find(x => x.id === b.dataset.kl); const v = prompt('Nom de cette clé (ex : compte Google de Sara) :', k ? k.label : ''); if (v !== null) act('/api/keys/label', { id: b.dataset.kl, label: v }); });
    const add = $('#kAdd'); if (add) add.onclick = async () => {
      const key = $('#kNew').value.trim(); if (!key) return $('#kNew').focus();
      add.disabled = true; $('#kAddRes').textContent = 'Vérification de la clé…'; $('#kAddRes').className = 'kres';
      try { const r = await api('/api/keys/add', { method: 'POST', body: { key, label: $('#kNewLab').value.trim() } }); $('#kNew').value = ''; $('#kNewLab').value = ''; d = r; draw(d); toast(`Clé ${r.added === 'groq' ? 'Groq' : 'Gemini'} ajoutée ✅ : elle prend le relais automatiquement`); }
      catch (e) { $('#kAddRes').textContent = '❌ ' + e.message; $('#kAddRes').className = 'kres bad'; }
      add.disabled = false;
    };
  }
  draw(d);
  // vérification rapide de chaque clé à l'ouverture (gratuite : ne consomme pas de quota)
  d.keys.forEach(async k => { if (KEYS_TEST[k.id] && KEYS_TEST[k.id].state !== 'testing') return; try { const t = await api('/api/keys/test', { method: 'POST', body: { id: k.id } }); KEYS_TEST[k.id] = t; draw(d); } catch { } });
  // état en direct
  const tick = async () => { if (route.name !== 'admin' || !$('#admKeys')) return; try { const nd = await api('/api/keys/list'); if (nd && nd.keys) { d = nd; draw(d); } } catch { } KEYS_T = setTimeout(tick, 3000); };
  KEYS_T = setTimeout(tick, 3000);
}

/* =====================================================================
   Séries protégées par mot de passe — propriétaire seulement
   ===================================================================== */
let LOCKED = new Set();
async function loadLocks() { try { const r = await api('/api/cloud/locks'); LOCKED = new Set(r.locked || []); } catch { } return LOCKED; }
async function admLocksInit() {
  const box = $('#admLocks'); if (!box) return;
  await loadLocks();
  const draw = () => {
    box.innerHTML = LIB.series.map(s => { const on = LOCKED.has(s.id); return `<div class="keyrow ${on ? 'warn' : ''}"><div class="grow"><b>${on ? '🔒 ' : ''}${esc(s.name)}</b><div class="kst">${on ? 'Protégée : les spectateurs doivent entrer le mot de passe' : 'Ouverte à tous les comptes'}</div></div>
      <div class="kbtn"><button class="btn sm ${on ? 'ghost' : ''}" data-lk="${s.id}">${on ? 'Changer le mot de passe' : 'Protéger'}</button>${on ? `<button class="btn sm ghost" data-lo="${s.id}">Retirer la protection</button>` : ''}</div></div>`; }).join('') || '<p class="note">Aucune série.</p>';
    $$('[data-lk]', box).forEach(b => b.onclick = async () => {
      const s = seriesOf(b.dataset.lk), pw = prompt(`Mot de passe pour « ${s.name} » (4 caractères minimum).\nLes comptes qui ne sont pas toi devront l'entrer pour voir la série et ses épisodes.${LOCKED.has(s.id) ? '\nChanger le mot de passe retire l\'accès à ceux qui avaient l\'ancien.' : ''}`);
      if (pw === null) return; if (pw.length < 4) return toast('Mot de passe trop court (4 caractères minimum)', true);
      try { const r = await api('/api/cloud/locks', { method: 'POST', body: { sid: s.id, password: pw } }); LOCKED = new Set(r.locked || []); draw(); render(true); toast(`🔒 « ${s.name} » est protégée par mot de passe`); } catch (e) { toast(e.message, true); }
    });
    $$('[data-lo]', box).forEach(b => b.onclick = async () => {
      const s = seriesOf(b.dataset.lo); if (!confirm(`Retirer le mot de passe de « ${s.name} » ? Elle sera visible par tous les comptes.`)) return;
      try { const r = await api('/api/cloud/locks', { method: 'POST', body: { sid: s.id, off: true } }); LOCKED = new Set(r.locked || []); draw(); render(true); toast(`« ${s.name} » est de nouveau ouverte à tous`); } catch (e) { toast(e.message, true); }
    });
  };
  draw();
}

/* =====================================================================
   Mot de passe du propriétaire — propriétaire seulement
   ===================================================================== */
function admPwInit() {
  const box = $('#admPw'); if (!box) return;
  box.innerHTML = `<div class="kform col"><input type="password" id="pwOld" placeholder="Mot de passe actuel" autocomplete="current-password">
    <input type="password" id="pwNew" placeholder="Nouveau mot de passe (6 caractères minimum)" autocomplete="new-password">
    <input type="password" id="pwNew2" placeholder="Nouveau mot de passe, encore une fois" autocomplete="new-password">
    <label class="chk"><input type="checkbox" id="pwOut"> Déconnecter tous mes autres appareils (ils devront se reconnecter avec le nouveau mot de passe)</label>
    <button class="btn" id="pwGo">${ic('check')}Changer mon mot de passe</button><span class="kres" id="pwRes"></span></div>`;
  $('#pwGo').onclick = async () => {
    const o = $('#pwOld').value, n = $('#pwNew').value, n2 = $('#pwNew2').value, res = $('#pwRes');
    if (!o) return $('#pwOld').focus();
    if (n.length < 6) { res.textContent = '❌ Nouveau mot de passe trop court (6 caractères minimum)'; res.className = 'kres bad'; return; }
    if (n !== n2) { res.textContent = '❌ Les deux nouveaux mots de passe ne sont pas pareils'; res.className = 'kres bad'; return; }
    $('#pwGo').disabled = true;
    try { const r = await api('/api/cloud/password', { method: 'POST', body: { old: o, password: n, logoutAll: $('#pwOut').checked } }); $$('input[type=password]', box).forEach(i => { i.value = ''; }); res.textContent = '✅ Mot de passe changé' + (r.loggedOut ? ' : tes autres appareils devront se reconnecter' : ''); res.className = 'kres ok'; toast('Mot de passe changé ✓'); }
    catch (e) { res.textContent = '❌ ' + e.message; res.className = 'kres bad'; }
    $('#pwGo').disabled = false;
  };
}

'use strict';
/* =====================================================================
   VDIZI sur TV : tout se pilote à la télécommande (flèches, OK, retour).
   Actif seulement sur une TV (ou avec ?tv dans l'adresse, pour tester).
   Le reste de l'interface est le même que partout ailleurs.
   ===================================================================== */
(function () {
  const ua = navigator.userAgent;
  const onTv = new URLSearchParams(location.search).has('tv')
    || /Tizen|Web0S|webOS|SmartTV|SMART-TV|SmartHub|HbbTV|NetCast|BRAVIA|AFT[A-Z]|GoogleTV|Android TV|CrKey/i.test(ua)
    || (window.Android && Android.isTv && Android.isTv());
  if (!onTv) return;
  const html = document.documentElement;
  html.classList.add('tv');
  const fit = () => { const w = window.innerWidth; html.style.zoom = w >= 1600 ? 1.4 : w >= 1200 ? 1.15 : 1; };
  fit(); window.addEventListener('resize', fit);

  const BACK = new Set(['Escape', 'GoBack', 'BrowserBack', 'XF86Back', 'Back']), BACK_CODE = new Set([10009, 461, 8]);
  const DIR = { ArrowLeft: 'l', ArrowRight: 'r', ArrowUp: 'u', ArrowDown: 'd', Left: 'l', Right: 'r', Up: 'u', Down: 'd' };
  const CODE = { 37: 'l', 38: 'u', 39: 'r', 40: 'd' };
  const FOCUS = 'a[href],button:not([disabled]),input,select,textarea,[tabindex="0"]';
  const id = x => document.getElementById(x);
  const open = x => { const e = id(x); return !!e && !e.hidden; };
  const shown = el => {
    if (!el.getClientRects().length) return false;
    const s = getComputedStyle(el); return s.visibility !== 'hidden' && s.display !== 'none';
  };
  // la zone qui a la main : ce qui est par-dessus tout le reste
  const zone = () => id('vkrLogin') || (open('ctx') && id('ctx')) || (open('modal') && id('modal')) || (open('pMenu') && id('pMenu')) || (open('player') && id('player')) || id('app');
  const items = z => [...z.querySelectorAll(FOCUS)].filter(shown);
  let home = null; // dernier élément choisi sur la page, pour y revenir en fermant un menu
  const go = el => { if (!el) return; el.focus({ preventScroll: true }); el.scrollIntoView({ block: 'center', inline: 'center' }); if (id('app').contains(el)) home = el; };
  const backHome = () => { if (home && home.isConnected) go(home); };
  const first = z => {
    if (z === id('app')) return z.querySelector('#view [data-play]') || z.querySelector('#view a.card') || items(z)[0];
    return items(z)[0];
  };

  function move(dir, z) {
    const cur = document.activeElement, list = items(z);
    if (!cur || !z.contains(cur) || cur === z || !list.includes(cur)) return go(z === id('app') && home && home.isConnected ? home : first(z));
    const r = cur.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    let best = null, score = Infinity;
    for (const el of list) {
      if (el === cur) continue;
      // le bouton ⋯ d'un épisode n'est accessible que depuis son épisode, vers la droite
      const row = el.closest('.ep');
      if (row && row !== el && !(row === cur && dir === 'r')) continue;
      if (el.contains(cur) && dir !== 'l') continue;
      const q = el.getBoundingClientRect(), dx = q.left + q.width / 2 - cx, dy = q.top + q.height / 2 - cy;
      if (!(dir === 'l' ? dx < -4 : dir === 'r' ? dx > 4 : dir === 'u' ? dy < -4 : dy > 4)) continue;
      if ((dir === 'l' || dir === 'r') && (q.bottom <= r.top || q.top >= r.bottom)) continue; // gauche/droite : même rangée seulement
      const s = dir === 'l' || dir === 'r' ? Math.abs(dx) + Math.abs(dy) * 3 : Math.abs(dy) + Math.abs(dx) * 3;
      if (s < score) { score = s; best = el; }
    }
    if (best) go(best);
  }

  function back(e) {
    const stop = () => { e.preventDefault(); e.stopPropagation(); };
    if (document.querySelector('.ask')) return; // la petite fenêtre de saisie gère sa touche elle-même
    if (id('vkrLogin')) { const l = id('vkrLater'); if (l) { stop(); l.click(); } return; }
    if (open('ctx')) { stop(); id('ctx').hidden = true; backHome(); return; }
    if (open('modal')) { stop(); id('modal').hidden = true; backHome(); return; }
    if (open('pMenu')) { stop(); id('pMenu').hidden = true; id('pCC').focus(); return; }
    if (open('player')) {
      stop();
      if (id('player').contains(document.activeElement) && document.activeElement !== id('player')) { document.activeElement.blur(); id('player').focus(); return; }
      window.closePlayer(); return;
    }
    if (location.hash && !/^#\/?$/.test(location.hash)) { stop(); history.back(); }
  }

  window.addEventListener('keydown', e => {
    if (document.querySelector('.ask')) return;
    const k = e.key, dir = DIR[k] || CODE[e.keyCode], cur = document.activeElement;
    if (BACK.has(k) || (BACK_CODE.has(e.keyCode) && !/INPUT|TEXTAREA/.test(cur.tagName))) return back(e);
    const player = open('player') ? id('player') : null, menu = open('pMenu');
    const onControl = player && player.contains(cur) && cur !== player;
    if (k === 'Enter' || e.keyCode === 13) {
      if (player && !menu && !onControl) { e.preventDefault(); e.stopPropagation(); const v = id('video'); v.paused ? v.play() : v.pause(); if (window.poke) poke(); return; }
      if (/INPUT|TEXTAREA|SELECT/.test(cur.tagName) && cur.type !== 'checkbox') return; // ouvre le clavier de la TV
      if (cur && cur !== document.body && cur.matches(FOCUS)) { e.preventDefault(); e.stopPropagation(); cur.click(); }
      return;
    }
    if (e.keyCode === 415 || e.keyCode === 10252 || e.keyCode === 19) { if (player) { e.preventDefault(); const v = id('video'); (e.keyCode === 19 || (e.keyCode === 10252 && !v.paused)) ? v.pause() : v.play(); } return; }
    if (e.keyCode === 413) { if (player) { e.preventDefault(); window.closePlayer(); } return; }
    if (!dir) return;
    if (/INPUT|TEXTAREA/.test(cur.tagName) && (dir === 'l' || dir === 'r') && cur.value) return; // déplace le curseur dans le texte
    if (player && !menu) {
      if (!onControl) {
        if (dir === 'l' || dir === 'r') return; // reculer / avancer de 10 s : déjà géré par le lecteur
        e.preventDefault(); e.stopPropagation(); if (window.poke) poke(); go(id('pPlay')); return; // les boutons apparaissent
      }
      if (window.poke) poke();
    }
    e.preventDefault(); e.stopPropagation();
    move(dir, zone());
  }, true);

  // nouvelle page : on se place sur le premier élément pour que la télécommande marche tout de suite
  let t = 0;
  new MutationObserver(() => { clearTimeout(t); t = setTimeout(() => {
    const a = document.activeElement;
    if (zone() === id('app') && (!a || a === document.body || !a.isConnected)) go(first(id('app')));
  }, 80); }).observe(id('view'), { childList: true });
})();

/* =====================================================================
   VkCast — « Diffuser sur un écran » (Chromecast / Google TV / TV DLNA), commun à VkTV et VkSéries.
   Source unique : vkcloud/cast-ui.js (insérée dans web.html à l'installation du serveur,
   copiée dans fluxtv-app/app/cast-ui.js pour VkTV).
   Fonctionne dans les applis Android (window.Android.cast…). Ailleurs : VkCast.native() = false.
   ===================================================================== */
(function () {
  if (window.VkCast) return;
  const N = () => { try { return !!(window.Android && Android.castAvailable && Android.castAvailable()); } catch { return false; } };
  const css = `
#vkcSheet{position:fixed;inset:0;z-index:9998;background:rgba(0,0,0,.6);display:flex;align-items:flex-end;justify-content:center;font-family:inherit}
#vkcSheet .s{width:min(520px,100%);background:#181818;border-radius:18px 18px 0 0;padding:20px 18px 22px;color:#f2f2f2;box-shadow:0 -10px 40px rgba(0,0,0,.6);max-height:80vh;overflow:auto}
#vkcSheet h3{margin:0 0 4px;font-size:19px;display:flex;align-items:center;gap:10px}
#vkcSheet p{margin:0 0 14px;color:#9a9a9a;font-size:13.5px;line-height:1.45}
#vkcSheet .d{display:flex;align-items:center;gap:12px;width:100%;padding:13px 14px;margin:0 0 8px;border-radius:12px;background:#232323;color:#fff;font-size:15.5px;font-weight:600;text-align:left;border:0}
#vkcSheet .d small{display:block;color:#9a9a9a;font-weight:500;font-size:12.5px;margin-top:2px}
#vkcSheet .d:focus,#vkcSheet .d:hover{background:#2e2e2e;outline:2px solid #e50914}
#vkcSheet .row{display:flex;gap:8px;justify-content:flex-end;margin-top:12px}
#vkcSheet .b,#vkcBar .b{border:0;border-radius:10px;padding:10px 14px;font-weight:700;font-size:14px;background:#2a2a2a;color:#fff}
#vkcSheet .b.red{background:#e50914}
#vkcSheet .sp,#vkcBar .sp{width:16px;height:16px;border-radius:50%;border:2px solid #444;border-top-color:#e50914;animation:vkcs .8s linear infinite;display:inline-block;flex:none}
@keyframes vkcs{to{transform:rotate(360deg)}}
#vkcBar{position:fixed;left:0;right:0;bottom:0;z-index:9997;background:linear-gradient(transparent,rgba(0,0,0,.92) 18%);padding:28px 14px 14px;color:#fff;font-family:inherit}
#vkcBar .in{max-width:900px;margin:0 auto;background:#161616;border:1px solid #2a2a2a;border-radius:16px;padding:12px 14px;box-shadow:0 10px 40px rgba(0,0,0,.6)}
#vkcBar .t{display:flex;align-items:center;gap:10px;font-size:14px}
#vkcBar .t b{display:block;font-size:15px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#vkcBar .t small{color:#a3a3a3;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#vkcBar .t .x{flex:1;min-width:0}
#vkcBar .err{color:#ff8a8a}
#vkcBar input[type=range]{width:100%;margin:12px 0 4px;accent-color:#e50914}
#vkcBar .tm{display:flex;justify-content:space-between;color:#a3a3a3;font-size:12px;font-variant-numeric:tabular-nums}
#vkcBar .c{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-top:8px}
#vkcBar .c .b{min-width:46px;font-size:16px;display:inline-flex;align-items:center;justify-content:center;gap:6px}
#vkcBar .c .b.stop{background:#e50914}
#vkcBar .c .b:focus{outline:2px solid #fff}
`;
  const ICO = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M3 18a3 3 0 0 1 3 3M3 14a7 7 0 0 1 7 7M3 10a11 11 0 0 1 11 11"/><path d="M3 7V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-5"/></svg>';
  const SV = d => `<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor">${d}</svg>`;
  const I_PLAY = SV('<path d="M7 4.8v14.4L19 12z"/>'), I_PAUSE = SV('<path d="M7 5h3.5v14H7zM13.5 5H17v14h-3.5z"/>'), I_STOP = SV('<rect x="6" y="6" width="12" height="12" rx="1.5"/>');
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const fmt = s => { s = Math.max(0, Math.round(s || 0)); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60; return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(x).padStart(2, '0'); };
  let styled = false; const style = () => { if (styled) return; styled = true; const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st); };
  const C = { dev: null, media: null, hooks: {}, poll: 0, last: null, subsOn: true, vol: 0.5, seeking: false, endedSent: false };
  const parse = s => { try { return JSON.parse(s); } catch { return null; } };

  /* ---------- choix de l'écran */
  function pick(getMedia, hooks) {
    style();
    if (!N()) return false;
    closeSheet();
    const box = document.createElement('div'); box.id = 'vkcSheet';
    box.innerHTML = `<div class="s"><h3>${ICO} Diffuser sur un écran</h3><p>Chromecast, Google TV, box Android ou TV connectée (Samsung, LG…). Le téléphone et l'écran doivent être sur le <b>même Wi-Fi</b>.</p><div id="vkcList"><p style="display:flex;gap:10px;align-items:center"><span class="sp"></span>Recherche des écrans…</p></div><div class="row"><button class="b" id="vkcAgain">Rechercher à nouveau</button><button class="b" id="vkcCancel">Annuler</button></div></div>`;
    document.body.appendChild(box);
    box.addEventListener('click', e => { if (e.target === box) closeSheet(); });
    box.querySelector('#vkcCancel').onclick = closeSheet;
    const draw = () => {
      const l = box.querySelector('#vkcList'); if (!l) return;
      const devs = parse(Android.castDevices()) || [], scanning = Android.castScanning();
      l.innerHTML = devs.map(d => `<button class="d" data-id="${esc(d.id)}">${ICO}<span>${esc(d.name)}<small>${d.kind === 'cast' ? 'Chromecast / Google TV' : 'TV connectée (DLNA)'}${d.model ? ' · ' + esc(d.model) : ''}</small></span></button>`).join('')
        + (scanning ? `<p style="display:flex;gap:10px;align-items:center"><span class="sp"></span>Recherche des écrans…</p>` : devs.length ? '' : `<p>Aucun écran trouvé. Vérifie que la TV est allumée et sur le même Wi-Fi que le téléphone, puis « Rechercher à nouveau ».</p>`);
      l.querySelectorAll('[data-id]').forEach(b => b.onclick = () => { const d = devs.find(x => x.id === b.dataset.id); closeSheet(); start(d, getMedia(), hooks); });
      const f = l.querySelector('.d'); if (f && !box.contains(document.activeElement)) f.focus();
      if (scanning) setTimeout(draw, 500);
    };
    const scan = () => { try { Android.castScan(); } catch { } setTimeout(draw, 300); };
    box.querySelector('#vkcAgain').onclick = scan;
    scan();
    return true;
  }
  function closeSheet() { const b = document.getElementById('vkcSheet'); if (b) b.remove(); }

  /* ---------- diffusion en cours */
  function start(dev, media, hooks) {
    C.dev = dev; C.media = media; C.hooks = hooks || {}; C.last = null; C.endedSent = false; C.subsOn = !!(media.subs || []).some(s => s.on);
    Android.castPlay(dev.id, JSON.stringify(media));
    bar(); clearInterval(C.poll); C.poll = setInterval(tick, 1000); tick();
    C.hooks.onStart && C.hooks.onStart(dev);
  }
  /** autre vidéo sur le même écran (chaîne suivante, épisode suivant) */
  function load(media, hooks) { if (!C.dev) return false; if (hooks) C.hooks = hooks; C.media = media; C.last = null; C.endedSent = false; C.subsOn = !!(media.subs || []).some(s => s.on); Android.castPlay(C.dev.id, JSON.stringify(media)); bar(); tick(); return true; }
  function stop(silent) {
    if (!C.dev) return;
    try { Android.castCmd('stop', 0); } catch { }
    clearInterval(C.poll);
    const t = C.last ? C.last.time : 0, d = C.last ? C.last.duration : 0, h = C.hooks;
    C.dev = null; C.media = null; C.hooks = {};
    const b = document.getElementById('vkcBar'); if (b) b.remove();
    if (!silent && h.onStop) h.onStop(t, d);
  }
  function cmd(c, v) { try { Android.castCmd(c, v || 0); } catch { } setTimeout(tick, 400); }

  function bar() {
    style();
    let b = document.getElementById('vkcBar');
    if (!b) { b = document.createElement('div'); b.id = 'vkcBar'; document.body.appendChild(b); }
    const live = !!(C.media && C.media.live), subs = !!(C.media && (C.media.subs || []).length);
    b.innerHTML = `<div class="in"><div class="t">${ICO}<div class="x"><b>${esc(C.media ? C.media.title : '')}</b><small id="vkcSt">Connexion à ${esc(C.dev.name)}…</small></div></div>
      ${live ? '' : `<input type="range" id="vkcPos" min="0" max="1" step="1" value="0"><div class="tm"><span id="vkcT">0:00</span><span id="vkcD">--:--</span></div>`}
      <div class="c">${live ? '' : '<button class="b" id="vkcBk" title="Reculer de 10 s">−10</button>'}<button class="b" id="vkcPP" title="Lecture / pause">${I_PAUSE}</button>${live ? '' : '<button class="b" id="vkcFw" title="Avancer de 30 s">+30</button>'}<button class="b" id="vkcVd" title="Moins fort">🔉</button><button class="b" id="vkcVu" title="Plus fort">🔊</button>${subs ? '<button class="b" id="vkcCC" title="Sous-titres">CC</button>' : ''}<button class="b stop" id="vkcStop" title="Arrêter la diffusion">${I_STOP} Arrêter</button></div></div>`;
    const q = s => b.querySelector(s);
    q('#vkcPP').onclick = () => cmd(C.last && C.last.state === 'playing' ? 'pause' : 'play');
    if (q('#vkcBk')) q('#vkcBk').onclick = () => cmd('seek', Math.max(0, (C.last ? C.last.time : 0) - 10));
    if (q('#vkcFw')) q('#vkcFw').onclick = () => cmd('seek', (C.last ? C.last.time : 0) + 30);
    q('#vkcVd').onclick = () => { C.vol = Math.max(0, (C.last && C.last.volume >= 0 ? C.last.volume : C.vol) - 0.1); cmd('volume', C.vol); };
    q('#vkcVu').onclick = () => { C.vol = Math.min(1, (C.last && C.last.volume >= 0 ? C.last.volume : C.vol) + 0.1); cmd('volume', C.vol); };
    if (q('#vkcCC')) q('#vkcCC').onclick = () => { C.subsOn = !C.subsOn; cmd('subs', C.subsOn ? 1 : 0); q('#vkcCC').style.opacity = C.subsOn ? 1 : .5; };
    q('#vkcStop').onclick = () => stop();
    const pos = q('#vkcPos');
    if (pos) { pos.oninput = () => { C.seeking = true; q('#vkcT').textContent = fmt(+pos.value); }; pos.onchange = () => { C.seeking = false; cmd('seek', +pos.value); }; }
  }
  function tick() {
    if (!C.dev) return;
    const s = parse(Android.castState()); if (!s) return;
    C.last = s;
    const b = document.getElementById('vkcBar'); if (!b) return;
    const st = b.querySelector('#vkcSt'), name = esc(C.dev.name);
    const txt = { connecting: `Connexion à ${name}…`, buffering: `Chargement sur ${name}…`, playing: `Diffusion sur ${name}`, paused: `En pause sur ${name}`, ended: `Terminé sur ${name}`, idle: `${name} : en attente` }[s.state] || `Diffusion sur ${name}`;
    st.innerHTML = s.state === 'error' ? `<span class="err">${esc(s.error || 'diffusion impossible')}</span>` : (s.state === 'connecting' || s.state === 'buffering' ? '<span class="sp" style="width:11px;height:11px;vertical-align:-1px;margin-right:6px"></span>' : '') + txt + (s.nosubs && C.media && (C.media.subs || []).length ? ' · sous-titres non pris en charge par cette TV' : '');
    const pp = b.querySelector('#vkcPP'), want = s.state === 'playing' || s.state === 'buffering' ? 'pause' : 'play'; if (pp.dataset.i !== want) { pp.dataset.i = want; pp.innerHTML = want === 'pause' ? I_PAUSE : I_PLAY; }
    const pos = b.querySelector('#vkcPos');
    if (pos && !C.seeking) { pos.max = Math.max(1, Math.round(s.duration || 0)); pos.value = Math.round(s.time || 0); b.querySelector('#vkcT').textContent = fmt(s.time); b.querySelector('#vkcD').textContent = s.duration ? fmt(s.duration) : '--:--'; }
    if (C.hooks.onTime && s.state === 'playing') C.hooks.onTime(s.time, s.duration);
    if (s.state === 'ended' && !C.endedSent) { C.endedSent = true; C.hooks.onEnded && C.hooks.onEnded(); }
    if (!s.active) { clearInterval(C.poll); const h = C.hooks; C.dev = null; b.remove(); h.onStop && h.onStop(0, 0); }
  }

  window.VkCast = { native: N, pick, load, stop, active: () => !!C.dev, device: () => C.dev, icon: ICO };
})();

'use strict';
/* =====================================================================
   Page Administration (propriétaire) : ce qu'on peut changer soi-même,
   sans toucher au code. Enregistré sur le serveur en ligne : visible
   tout de suite par tout le monde, sur le site et dans les applis.
   ===================================================================== */
const ADMIN_TABS = [['home', 'Accueil'], ['series', 'Catalogue'], ['playlists', 'Playlists'], ['auto', 'Travaux'], ['community', 'Communauté'], ['download', 'Télécharger VDIZI']];

async function renderAdmin() {
  if (viewer()) { location.hash = '#/'; return; }
  const connected = window.VK_REMOTE || (typeof CLOUD !== 'undefined' && CLOUD && CLOUD.connected);
  const eps = LIB.series.reduce((n, s) => n + s.eps.length, 0), online = LIB.series.reduce((n, s) => n + s.eps.filter(e => e.cloud).length, 0);
  view.innerHTML = `<div class="page" style="max-width:820px"><div class="ph"><h1>Administration</h1></div>
    ${connected ? '' : '<div class="jobcard"><b>Connecte d\'abord VDIZI à ton compte en ligne</b><small>Bouton « En ligne » en haut : les réglages sont enregistrés sur ton serveur.</small></div>'}
    <div class="adm-st"><div><b>${LIB.series.length}</b><small>séries</small></div><div><b>${eps}</b><small>épisodes</small></div><div><b>${online}</b><small>en ligne</small></div><div><b id="admUsers">…</b><small>comptes</small></div><div><b id="admGo">…</b><small>stockage utilisé</small></div></div>

    <h3>Noms des onglets</h3>
    <div class="adm-g">${ADMIN_TABS.map(([k, d]) => `<label>${esc(d)}<input data-lab="${k}" maxlength="24" value="${esc((SITE.labels || {})[k] || '')}" placeholder="${esc(d)}"></label>`).join('')}</div>

    <h3>Message pour tes spectateurs</h3>
    <p class="note">Affiché en haut de l'accueil, pour tout le monde. Laisse vide pour ne rien afficher.</p>
    <textarea id="admMsg" class="adm-t" maxlength="300" rows="2" placeholder="ex : Nouvel épisode de Deha ce soir !">${esc(SITE.announce || '')}</textarea>

    <h3>Calendrier des sorties</h3>
    <p class="note">Annonce les épisodes ou séries à venir : ils apparaissent dans « À venir » sur l'accueil et disparaissent tout seuls une fois la date passée.</p>
    <div id="admCal"></div>
    <button class="btn sm ghost" id="admCalAdd" style="margin-top:8px">${ic('plus')}Ajouter une sortie</button>

    <h3>Couleur principale</h3>
    <div class="adm-c"><input type="color" id="admCol" value="${esc(SITE.accent || '#E11D2E')}"><button class="btn sm ghost" id="admColR">Couleur d'origine</button></div>

    <div class="foot"><button class="btn" id="admSave">${ic('check')}Enregistrer</button></div>

    <h3 style="margin-top:30px">Clés IA (sous-titres)</h3>
    <div id="admKeys"><p class="note">Chargement…</p></div>

    <h3 style="margin-top:30px">Séries protégées par mot de passe</h3>
    <p class="note">Une série protégée reste visible dans le catalogue (nom et image, avec un cadenas), mais ses épisodes ne s'ouvrent qu'avec le mot de passe que tu choisis. Toi, tu as toujours accès à tout.</p>
    <div id="admLocks"></div>

    <h3 style="margin-top:30px">Mon mot de passe (propriétaire)</h3>
    <div id="admPw"></div>

    <h3 style="margin-top:30px">Comptes et inscriptions</h3>
    <div class="cl-guest" id="clGuest"><b>Accès invité</b><small>…</small></div>

    <h3 style="margin-top:30px">Séries et suggestions</h3>
    <p class="note">Sur la page d'une série, le bouton ⋯ permet de la renommer et de changer son image. Ouvre <a href="#/community">${esc(label('community'))}</a> pour traiter les suggestions.</p></div>`;
  const calRow = (x = {}) => {
    const d = document.createElement('div'); d.className = 'adm-cal';
    d.innerHTML = `<input type="date" data-c="date" value="${esc(x.date || '')}"><input data-c="title" maxlength="100" placeholder="Série ou épisode" value="${esc(x.title || '')}"><input data-c="note" maxlength="200" placeholder="Détail (facultatif)" value="${esc(x.note || '')}"><button class="ibtn" title="Retirer">${ic('x')}</button>`;
    $('button', d).onclick = () => d.remove();
    $('#admCal').appendChild(d); return d;
  };
  (SITE.calendar || []).forEach(calRow);
  $('#admCalAdd').onclick = () => $('[data-c=date]', calRow()).focus();
  $('#admColR').onclick = () => { $('#admCol').value = '#E11D2E'; };
  $('#admSave').onclick = async () => {
    const labels = {}; $$('[data-lab]').forEach(i => { const v = i.value.trim(); if (v) labels[i.dataset.lab] = v; });
    const accent = $('#admCol').value.toUpperCase();
    const rows = $$('.adm-cal'), calendar = rows.map(r => ({ date: $('[data-c=date]', r).value, title: $('[data-c=title]', r).value.trim(), note: $('[data-c=note]', r).value.trim() })).filter(x => x.date || x.title);
    if (calendar.some(x => !x.date || !x.title)) return toast('Calendrier : chaque sortie a besoin d\'une date et d\'un nom', true);
    try {
      const s = await api('/api/cloud/site', { method: 'POST', body: { labels, announce: $('#admMsg').value.trim(), accent: accent === '#E11D2E' ? '' : accent, calendar } });
      applySite(s); render(true); toast('Enregistré : visible tout de suite par tout le monde ✓');
    } catch (e) { toast(e.message, true); }
  };
  admKeysInit(); // les clés sont sur le PC : pas besoin du compte en ligne
  if (!connected) { $('#admLocks').innerHTML = $('#admPw').innerHTML = '<p class="note">Connecte d\'abord VDIZI à ton compte en ligne.</p>'; return; }
  admLocksInit(); admPwInit();
  if (typeof fillGuest === 'function') fillGuest();
  try { const g = await api('/api/cloud/guest'); const n = $('#admUsers'); if (n) n.textContent = (g.users || []).length; } catch { }
  try { const u = await api('/api/cloud/usage'); const n = $('#admGo'); if (n && u.bytes !== undefined) n.textContent = (u.bytes / 1e9).toFixed(1).replace('.', ',') + ' Go'; } catch { }
}

/* =====================================================================
   Clés IA (sous-titres) : liste, état en direct, ajout et retrait — propriétaire seulement
   ===================================================================== */
const KEY_LINKS = {
  groq: { name: 'Groq', role: 'écoute des dialogues', console: 'https://console.groq.com/keys', how: 'Ouvre console.groq.com/keys, connecte-toi avec une adresse Google, clique « Create API Key », puis copie la clé (gsk_…).' },
  gemini: { name: 'Gemini', role: 'traduction', console: 'https://aistudio.google.com/apikey', how: 'Ouvre aistudio.google.com/apikey avec une adresse Google, clique « Créer une clé API », puis copie la clé.' },
};
let KEYS_T = 0, KEYS_TEST = {}; // résultats des tests (par id de clé)
const BILL_LINKS = [
  ['Groq : ma facture', 'https://console.groq.com/settings/billing'], ['Groq : ma consommation', 'https://console.groq.com/dashboard/usage'], ['Groq : plafond de dépenses', 'https://console.groq.com/settings/billing/limits'],
  ['Google : mes clés et leur facturation', 'https://aistudio.google.com/apikey'], ['Google : comment marche la facturation', 'https://ai.google.dev/gemini-api/docs/billing'], ['Railway : mon compte', 'https://railway.com/dashboard'],
];
let BILLP_OPEN = false; // tableau des tarifs ouvert ou fermé (gardé entre deux rafraîchissements)
let STORE_USE = null, STORE_AT = 0; // place utilisée en ligne (rafraîchie chaque minute)
const usd = v => (v < 0.01 && v > 0 ? '< 0,01' : v.toFixed(2).replace('.', ',')) + ' $';
const big = n => n >= 1e6 ? (n / 1e6).toFixed(1).replace('.', ',') + ' M' : n >= 1e3 ? Math.round(n / 1e3) + ' k' : String(Math.round(n || 0));
function useLine(u) { if (!u || !u.req) return 'aucune demande'; return `${u.req} demande${u.req > 1 ? 's' : ''}${u.in || u.out ? ` · ${big(u.in)} tokens lus / ${big(u.out)} écrits` : ''}${u.sec ? ` · ${Math.round(u.sec / 60)} min d'audio` : ''} · <b>≈ ${usd(u.cost)}</b> si payant${u.unknown && u.unknown.length ? ' (+ tarif inconnu : ' + esc(u.unknown.join(', ')) + ')' : ''}`; }
function billingHTML(d) {
  const B = d.billing || {}, sum = kind => d.keys.filter(k => !kind || k.kind === kind).reduce((a, k) => a + ((k.usage && k.usage.month.cost) || 0), 0);
  const ai = sum(), off = !!(STORE_USE && STORE_USE.off), go = STORE_USE && STORE_USE.bytes !== undefined ? STORE_USE.bytes / 1e9 : null, isS3 = STORE_USE && STORE_USE.kind === 's3';
  const store = go !== null && isS3 ? go * (B.storagePrice || 0) : 0, total = ai + store, over = B.budget > 0 && total > B.budget;
  return `<div class="keyblk bill${over ? ' over' : ''}"><div class="keyhd"><b>💶 Facturation</b><small>— mise à jour en direct</small></div>
    <div class="keyrow ok"><div class="grow"><b>Coût réel : 0 €</b> tant qu'<b>aucune carte</b> n'est enregistrée chez Groq et chez Google.<div class="kday">Offre gratuite : arrivées au plafond, les clés se bloquent quelques heures, mais <b>rien ne peut être facturé</b>. Vérifie-le avec les liens ci-dessous.</div></div></div>
    <div class="billgrid">
      <div><small>Gemini (traduction), ce mois</small><b>${usd(sum('gemini'))}</b><small>si c'était payant</small></div>
      <div><small>Groq (écoute), ce mois</small><b>${usd(sum('groq'))}</b><small>si c'était payant</small></div>
      <div><small>Stockage des vidéos</small><b>${off ? '—' : go === null ? '…' : isS3 ? '≈ ' + usd(store) + ' / mois' : STORE_USE.kind === 'r2' ? 'gratuit ≤ 10 Go' : 'abonnement fixe'}</b><small>${off ? 'compte en ligne non connecté' : go === null ? '' : go.toFixed(1).replace('.', ',') + ' Go en ligne' + (isS3 ? ' · Railway : ' + String(B.storagePrice).replace('.', ',') + ' $ / Go / mois' : '')}</small></div>
      <div class="${over ? 'bad' : ''}"><small>Total estimé du mois</small><b>${usd(total)}</b><small>${B.budget ? (over ? '⚠️ au-dessus de ton plafond de ' + usd(B.budget) : 'plafond d\'alerte : ' + usd(B.budget)) : 'aucun plafond d\'alerte'}</small></div>
    </div>
    ${over ? `<div class="keyrow bad"><div class="grow"><b>⚠️ Plafond dépassé</b><div class="kday">L'estimation du mois (${usd(total)}) dépasse ton plafond (${usd(B.budget)}). Vérifie tes vraies factures avec les liens ci-dessous.</div></div></div>` : ''}
    <div class="kform" style="align-items:center;margin:8px 0"><label class="chk">Plafond d'alerte par mois ($) <input id="bBudget" type="number" min="0" step="0.5" value="${B.budget || ''}" placeholder="ex : 5" style="flex:0 0 90px"></label><button class="btn sm ghost" id="bSave">Enregistrer</button></div>
    <div class="billlinks">${BILL_LINKS.map(([t, u]) => `<a class="btn sm ghost" href="${u}" target="_blank" rel="noopener">${ic('ext')}${t}</a>`).join('')}</div>
    <details class="billp"${BILLP_OPEN ? ' open' : ''}><summary>Tarifs utilisés pour l'estimation (officiels, relevés le 11/11/2026 · modifiables)</summary>
      <table><tr><th>Modèle</th><th>$ / million de tokens lus</th><th>$ / million écrits</th><th>$ / heure d'audio</th></tr>
      ${Object.entries(B.prices || {}).map(([m, p]) => `<tr data-pm="${esc(m)}"><td>${esc(m)}${p.note ? '<br><small>' + esc(p.note) + '</small>' : ''}</td>${['in', 'out', 'hour'].map(f => `<td><input type="number" min="0" step="0.001" data-pf="${f}" value="${p[f] ?? ''}"></td>`).join('')}</tr>`).join('')}</table>
      <label class="chk" style="margin-top:6px">Stockage ($ par Go et par mois) <input id="bStore" type="number" min="0" step="0.001" value="${B.storagePrice}" style="flex:0 0 90px"></label>
      <button class="btn sm ghost" id="bPrices" style="margin-top:6px">Enregistrer les tarifs</button></details></div>`;
}
const hhmm = t => new Date(t).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
function keyState(k) {
  const L = k.live || {}, t = KEYS_TEST[k.id];
  if (t && t.state === 'refused') return ['bad', '❌ Refusée', t.message || 'clé invalide ou supprimée : retire-la'];
  if (t && t.state === 'testing') return ['run', '⏳ Test en cours…', ''];
  if (L.busyUntil) return ['warn', `⏸️ Saturée jusqu'à ${hhmm(L.busyUntil)}`, L.lastErrCode === 'quota' ? 'limite gratuite du jour atteinte' : 'trop de demandes : le relais passe aux autres clés'];
  if (t && t.state === 'quota') return ['warn', '⛔ Limite du jour atteinte', t.message || ''];
  if (t && t.state === 'busy') return ['warn', '⏸️ Saturée en ce moment', t.message || ''];
  if (t && (t.state === 'net' || t.state === 'error')) return ['warn', '⚠️ Ne répond pas', t.message || ''];
  if (L.inflight) return ['run', '🔄 En cours d\'utilisation', ''];
  if (t && t.state === 'ok') return ['ok', '✅ Fonctionne', t.ms ? `répond en ${(t.ms / 1000).toFixed(1).replace('.', ',')} s` : 'clé valide'];
  return ['ok', '✅ Prête', ''];
}
function keysHTML(d) {
  const by = kind => d.keys.filter(k => k.kind === kind);
  const block = kind => {
    const ks = by(kind), L = KEY_LINKS[kind], okN = ks.filter(k => keyState(k)[0] === 'ok' || keyState(k)[0] === 'run').length;
    const tip = kind === 'gemini' && ks.length < 3 ? `<p class="note">💡 Ajoute ${3 - ks.length} clé${3 - ks.length > 1 ? 's' : ''} Gemini de plus (chacune d'une <b>autre adresse Google</b>) : quand une clé sature, la suivante prend le relais toute seule, sans attente.</p>`
      : kind === 'groq' && ks.length < 2 ? `<p class="note">💡 Une 2ᵉ clé Groq (d'une <b>autre adresse Google</b>) évite d'attendre quand l'écoute sature.</p>` : '';
    return `<div class="keyblk"><div class="keyhd"><b>${L.name}</b> <small>— ${L.role} · ${ks.length} clé${ks.length > 1 ? 's' : ''} · ${okN}/${ks.length} disponible${okN > 1 ? 's' : ''}</small><a class="btn sm ghost" href="${L.console}" target="_blank" rel="noopener">${ic('ext')}Gérer mes clés ${L.name}</a></div>
      ${ks.length ? ks.map(k => { const [cls, st, sub] = keyState(k), Lv = k.live || {}; return `<div class="keyrow ${cls}" data-kid="${k.id}">
        <div class="grow"><b>${k.main ? 'Principale' : 'Relais ' + k.n}</b> <code>${esc(k.mask)}</code>
          <div class="kacc">Compte : ${k.label ? `<b>${esc(k.label)}</b>` : `<a href="#" data-kl="${k.id}">non renseigné — ajouter l'e-mail</a>`}</div>
          <div class="kst">${st}${sub ? ` <small>· ${esc(sub)}</small>` : ''}</div>
          <small class="kday">Ce mois : ${useLine(k.usage && k.usage.month)}</small>
          <small class="kday">Aujourd'hui : ${Lv.ok || 0} réussite${Lv.ok > 1 ? 's' : ''} · ${Lv.fail || 0} erreur${Lv.fail > 1 ? 's' : ''}${Lv.lastOk ? ' · dernier succès ' + hhmm(Lv.lastOk) : ''}${Lv.lastErr ? ` · dernière erreur ${hhmm(Lv.lastErrAt)} : ${esc(Lv.lastErr.slice(0, 90))}` : ''}</small></div>
        <div class="kbtn"><button class="btn sm ghost" data-kt="${k.id}" title="Une toute petite vraie demande (≈ 1 requête du quota gratuit)">Tester</button><button class="btn sm ghost" data-kl="${k.id}">Compte (e-mail)</button>${k.main ? '' : `<button class="btn sm ghost" data-km="${k.id}">Mettre en 1er</button>`}<button class="btn sm ghost" data-kr="${k.id}">Retirer</button></div></div>`; }).join('')
      : `<div class="keyrow bad"><div class="grow"><b>Aucune clé</b><div class="kst">${kind === 'groq' ? 'Obligatoire pour sous-titrer' : 'Recommandé pour une traduction de qualité'}</div></div></div>`}
      ${tip}<p class="note" style="margin-top:4px">Nouvelle clé : ${L.how}</p></div>`;
  };
  return `<p class="note">Tes clés restent sur ton PC. L'état, la consommation et les coûts se mettent à jour tout seuls toutes les 3 secondes pendant que cette page est ouverte.</p>
    ${addKeyHTML(d)}${billingHTML(d)}${block('groq')}${block('gemini')}`;
}
// « Ajouter une clé » : en haut, en 3 étapes. Groq et Google ne laissent pas une appli récupérer les clés toute seule :
// on ouvre leur site (avec le choix du compte Google pour Gemini), on copie la clé, on la colle ici.
const GOOGLE_PICK = 'https://accounts.google.com/AccountChooser?continue=' + encodeURIComponent('https://aistudio.google.com/apikey');
function addKeyHTML(d) {
  const used = [...new Set(d.keys.map(k => k.label).filter(Boolean))];
  return `<div class="keyadd big"><b>➕ Ajouter une clé de relais</b>
    <ol class="ksteps">
      <li><b>Crée la clé</b> avec une <b>autre adresse Google</b> que celles déjà utilisées :
        <div class="kbtn" style="margin:6px 0"><a class="btn sm" href="${GOOGLE_PICK}" target="_blank" rel="noopener">${ic('ext')}Gemini : choisir le compte Google</a><a class="btn sm ghost" href="https://console.groq.com/keys" target="_blank" rel="noopener">${ic('ext')}Groq : ouvrir</a></div>
        <small>Gemini : clique « Créer une clé API ». Groq : clique « Create API Key ».<br>Astuce : si le site s'ouvre directement sur ton compte habituel, ouvre le lien dans une <b>fenêtre de navigation privée</b> (Ctrl+Maj+N) pour pouvoir choisir une autre adresse.</small></li>
      <li><b>Copie la clé</b> affichée : Gemini commence par « AIza » ou « AQ. », Groq par « gsk_ ».</li>
      <li><b>Colle-la ici</b>, écris l'adresse e-mail que tu viens d'utiliser, puis clique Ajouter :
        <div class="kform" style="margin-top:6px"><input id="kNew" placeholder="Colle la clé ici (Ctrl+V)" autocomplete="off" spellcheck="false"><button class="btn sm ghost" id="kPaste" type="button">📋 Coller</button><input id="kNewLab" type="email" placeholder="Adresse e-mail du compte : ex. sara@gmail.com" maxlength="60"><button class="btn" id="kAdd">${ic('plus')}Ajouter</button></div>
        <span class="kres" id="kAddRes"></span></li>
    </ol>
    <small>VDIZI reconnaît si c'est Groq ou Gemini, la teste, et l'ajoute aux relais : elle prend le relais toute seule quand les autres saturent.${used.length ? ` Adresses déjà utilisées : <b>${used.map(esc).join(', ')}</b> — prends-en une autre (deux clés du même compte partagent la même limite).` : ' Chaque clé doit venir d\'une adresse différente : deux clés du même compte partagent la même limite.'}</small></div>`;
}
async function admKeysInit() {
  const box = $('#admKeys'); if (!box) return;
  clearTimeout(KEYS_T);
  let d; try { d = await api('/api/keys/list'); if (!d || !Array.isArray(d.keys)) throw new Error(d && d.error || 'PC éteint'); }
  catch (e) { box.innerHTML = `<div class="jobcard"><b>Clés IA indisponibles</b><small>${esc(/éteint|PC/i.test(e.message) ? 'Ton PC est éteint : les clés sont sur le PC. Ouvre VDIZI dessus pour les voir ici.' : e.message)}</small></div>`; return; }
  const draw = dd => {
    const focus = document.activeElement && document.activeElement.id, nv = ($('#kNew') || {}).value || '', nl = ($('#kNewLab') || {}).value || '';
    box.innerHTML = keysHTML(dd);
    if ($('#kNew')) { $('#kNew').value = nv; $('#kNewLab').value = nl; } if (focus && $('#' + focus)) $('#' + focus).focus();
    bind();
  };
  const act = async (url, body, msg) => { try { const r = await api(url, { method: 'POST', body }); d = r; draw(d); if (msg) toast(msg); } catch (e) { toast(e.message, true); } };
  const test = async (id, deep) => { KEYS_TEST[id] = { state: 'testing' }; draw(d); try { KEYS_TEST[id] = await api('/api/keys/test', { method: 'POST', body: { id, deep } }); } catch (e) { KEYS_TEST[id] = { state: 'net', message: e.message }; } draw(d); };
  function bind() {
    $$('[data-kt]', box).forEach(b => b.onclick = () => test(b.dataset.kt, true));
    $$('[data-kr]', box).forEach(b => b.onclick = () => { if (confirm('Retirer cette clé de VDIZI ? (elle reste valable chez Groq/Google : tu peux la supprimer là-bas avec le bouton « Créer / gérer »)')) act('/api/keys/remove', { id: b.dataset.kr }, 'Clé retirée'); });
    $$('[data-km]', box).forEach(b => b.onclick = () => act('/api/keys/main', { id: b.dataset.km }, 'Clé mise en premier'));
    $$('[data-kl]', box).forEach(b => b.onclick = e => { e.preventDefault(); const k = d.keys.find(x => x.id === b.dataset.kl); const v = prompt('Adresse e-mail du compte où cette clé a été créée (Groq et Google ne la donnent pas : c\'est toi qui la notes) :', k ? k.label : ''); if (v !== null) act('/api/keys/label', { id: b.dataset.kl, label: v }); });
    const dt = $('.billp', box); if (dt) dt.ontoggle = () => { BILLP_OPEN = dt.open; };
    const bs = $('#bSave'); if (bs) bs.onclick = () => act('/api/keys/billing', { budget: +$('#bBudget').value || 0 }, 'Plafond d\'alerte enregistré');
    const bp = $('#bPrices'); if (bp) bp.onclick = () => { const prices = {}; $$('[data-pm]', box).forEach(r => { prices[r.dataset.pm] = {}; $$('[data-pf]', r).forEach(i => { prices[r.dataset.pm][i.dataset.pf] = i.value; }); }); act('/api/keys/billing', { prices, storagePrice: +$('#bStore').value }, 'Tarifs enregistrés'); };
    // coller : bouton (presse-papiers) ou Ctrl+V ; une clé reconnue → on passe tout de suite à l'e-mail
    const kn = $('#kNew'), kTyped = () => { const v = kn.value.trim(); $('#kAddRes').className = 'kres'; $('#kAddRes').textContent = /^gsk_/.test(v) ? '✓ Clé Groq reconnue' : /^(AIza|AQ\.)/.test(v) ? '✓ Clé Gemini reconnue' : v ? '❓ Clé non reconnue : vérifie que tu as tout copié' : ''; if (/^(gsk_|AIza|AQ\.)/.test(v) && !$('#kNewLab').value) $('#kNewLab').focus(); };
    if (kn) { kn.oninput = kTyped; kn.onpaste = () => setTimeout(kTyped, 0); }
    const kp = $('#kPaste'); if (kp) kp.onclick = async () => { try { kn.value = (await navigator.clipboard.readText()).trim(); kTyped(); } catch { kn.focus(); toast('Clique dans le champ puis fais Ctrl+V pour coller la clé'); } };
    const add = $('#kAdd'); if (add) add.onclick = async () => {
      const key = $('#kNew').value.trim(); if (!key) return $('#kNew').focus();
      add.disabled = true; $('#kAddRes').textContent = 'Vérification de la clé…'; $('#kAddRes').className = 'kres';
      try { const r = await api('/api/keys/add', { method: 'POST', body: { key, label: $('#kNewLab').value.trim() } }); $('#kNew').value = ''; $('#kNewLab').value = ''; d = r; draw(d); toast(`Clé ${r.added === 'groq' ? 'Groq' : 'Gemini'} ajoutée ✅ : elle prend le relais automatiquement`); }
      catch (e) { $('#kAddRes').textContent = '❌ ' + e.message; $('#kAddRes').className = 'kres bad'; }
      add.disabled = false;
    };
  }
  const loadStore = async () => { if (Date.now() - STORE_AT < 60e3) return; STORE_AT = Date.now(); try { const u = await api('/api/cloud/usage'); STORE_USE = u && u.bytes !== undefined ? u : { off: true }; } catch { STORE_USE = { off: true }; } };
  draw(d); loadStore().then(() => draw(d));
  // vérification rapide de chaque clé à l'ouverture (gratuite : ne consomme pas de quota)
  d.keys.forEach(async k => { if (KEYS_TEST[k.id] && KEYS_TEST[k.id].state !== 'testing') return; try { const t = await api('/api/keys/test', { method: 'POST', body: { id: k.id } }); KEYS_TEST[k.id] = t; draw(d); } catch { } });
  // état en direct
  const tick = async () => { if (route.name !== 'admin' || !$('#admKeys')) return; try { const nd = await api('/api/keys/list'); await loadStore(); if (nd && nd.keys) { d = nd; const a = document.activeElement; if (!(a && (a.id === 'bBudget' || a.closest && a.closest('.billp')))) draw(d); } } catch { } KEYS_T = setTimeout(tick, 3000); };
  KEYS_T = setTimeout(tick, 3000);
}

/* =====================================================================
   Séries protégées par mot de passe — propriétaire seulement
   ===================================================================== */
let LOCKED = new Set();
async function loadLocks() { try { const r = await api('/api/cloud/locks'); LOCKED = new Set(r.locked || []); } catch { } return LOCKED; }
async function admLocksInit() {
  const box = $('#admLocks'); if (!box) return;
  await loadLocks();
  const draw = () => {
    box.innerHTML = LIB.series.map(s => { const on = LOCKED.has(s.id); return `<div class="keyrow ${on ? 'warn' : ''}"><div class="grow"><b>${on ? '🔒 ' : ''}${esc(s.name)}</b><div class="kst">${on ? 'Protégée : les spectateurs doivent entrer le mot de passe' : 'Ouverte à tous les comptes'}</div></div>
      <div class="kbtn"><button class="btn sm ${on ? 'ghost' : ''}" data-lk="${s.id}">${on ? 'Changer le mot de passe' : 'Protéger'}</button>${on ? `<button class="btn sm ghost" data-lo="${s.id}">Retirer la protection</button>` : ''}</div></div>`; }).join('') || '<p class="note">Aucune série.</p>';
    $$('[data-lk]', box).forEach(b => b.onclick = async () => {
      const s = seriesOf(b.dataset.lk), pw = prompt(`Mot de passe pour « ${s.name} » (4 caractères minimum).\nLes comptes qui ne sont pas toi devront l'entrer pour voir la série et ses épisodes.${LOCKED.has(s.id) ? '\nChanger le mot de passe retire l\'accès à ceux qui avaient l\'ancien.' : ''}`);
      if (pw === null) return; if (pw.length < 4) return toast('Mot de passe trop court (4 caractères minimum)', true);
      try { const r = await api('/api/cloud/locks', { method: 'POST', body: { sid: s.id, password: pw } }); LOCKED = new Set(r.locked || []); draw(); render(true); toast(`🔒 « ${s.name} » est protégée par mot de passe`); } catch (e) { toast(e.message, true); }
    });
    $$('[data-lo]', box).forEach(b => b.onclick = async () => {
      const s = seriesOf(b.dataset.lo); if (!confirm(`Retirer le mot de passe de « ${s.name} » ? Elle sera visible par tous les comptes.`)) return;
      try { const r = await api('/api/cloud/locks', { method: 'POST', body: { sid: s.id, off: true } }); LOCKED = new Set(r.locked || []); draw(); render(true); toast(`« ${s.name} » est de nouveau ouverte à tous`); } catch (e) { toast(e.message, true); }
    });
  };
  draw();
}

/* =====================================================================
   Mot de passe du propriétaire — propriétaire seulement
   ===================================================================== */
function admPwInit() {
  const box = $('#admPw'); if (!box) return;
  box.innerHTML = `<div class="kform col"><input type="password" id="pwOld" placeholder="Mot de passe actuel" autocomplete="current-password">
    <input type="password" id="pwNew" placeholder="Nouveau mot de passe (6 caractères minimum)" autocomplete="new-password">
    <input type="password" id="pwNew2" placeholder="Nouveau mot de passe, encore une fois" autocomplete="new-password">
    <label class="chk"><input type="checkbox" id="pwOut"> Déconnecter tous mes autres appareils (ils devront se reconnecter avec le nouveau mot de passe)</label>
    <button class="btn" id="pwGo">${ic('check')}Changer mon mot de passe</button><span class="kres" id="pwRes"></span></div>`;
  $('#pwGo').onclick = async () => {
    const o = $('#pwOld').value, n = $('#pwNew').value, n2 = $('#pwNew2').value, res = $('#pwRes');
    if (!o) return $('#pwOld').focus();
    if (n.length < 6) { res.textContent = '❌ Nouveau mot de passe trop court (6 caractères minimum)'; res.className = 'kres bad'; return; }
    if (n !== n2) { res.textContent = '❌ Les deux nouveaux mots de passe ne sont pas pareils'; res.className = 'kres bad'; return; }
    $('#pwGo').disabled = true;
    try { const r = await api('/api/cloud/password', { method: 'POST', body: { old: o, password: n, logoutAll: $('#pwOut').checked } }); $$('input[type=password]', box).forEach(i => { i.value = ''; }); res.textContent = '✅ Mot de passe changé' + (r.loggedOut ? ' : tes autres appareils devront se reconnecter' : ''); res.className = 'kres ok'; toast('Mot de passe changé ✓'); }
    catch (e) { res.textContent = '❌ ' + e.message; res.className = 'kres bad'; }
    $('#pwGo').disabled = false;
  };
}

/* plafond de facturation dépassé : prévenir le propriétaire où qu'il soit dans l'appli (une fois par lancement) */
let BUDGET_WARNED = false;
async function budgetWatch() {
  if (viewer() || BUDGET_WARNED) return;
  try {
    const d = await api('/api/keys/list'); if (!d || !d.billing || !(d.billing.budget > 0)) return;
    let st = 0; try { const u = await api('/api/cloud/usage'); if (u && u.kind === 's3') st = u.bytes / 1e9 * d.billing.storagePrice; } catch { }
    const total = d.keys.reduce((a, k) => a + ((k.usage && k.usage.month.cost) || 0), 0) + st;
    if (total > d.billing.budget) { BUDGET_WARNED = true; toast(`⚠️ Facturation : l'estimation du mois (${usd(total)}) dépasse ton plafond de ${usd(d.billing.budget)}`, true, { label: 'Voir', fn: () => { location.hash = '#/admin'; } }); }
  } catch { }
}
setTimeout(budgetWatch, 8000); setInterval(budgetWatch, 10 * 60e3);

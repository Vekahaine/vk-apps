'use strict';
/* =====================================================================
   VkSéries sur le téléphone (appli Android) et sur le site web : LA MÊME interface que sur PC.
   Il n'y a pas de serveur local ici : ce fichier répond à la place du PC.
   - PC allumé  → les demandes passent par ton serveur en ligne jusqu'à VkSéries sur le PC (« télécommande ») :
                  toute la bibliothèque, sous-titrage IA, vérification, mise en ligne, noms propres…
   - PC éteint  → la bibliothèque et la lecture viennent de ton compte en ligne ; les actions qui ont besoin
                  du PC affichent « PC éteint ».
   - Vidéos, images, sous-titres et musique viennent toujours du compte en ligne.
   Ne fait rien sur le PC (Electron).
   ===================================================================== */
(function () {
  const qs = new URLSearchParams(location.search);
  const WEB = !!window.VK_WEB;              // page servie par ton serveur en ligne (navigateur)
  if (!(window.Android || WEB || qs.has('remote'))) return;
  document.documentElement.classList.add('remote');
  const WHERE = WEB ? 'le site' : 'le téléphone';
  const realFetch = window.fetch.bind(window);
  const LS = { get: (k, d) => { try { const v = localStorage.getItem('vkr.' + k); return v == null ? d : JSON.parse(v); } catch { return d; } }, set: (k, v) => { try { v == null ? localStorage.removeItem('vkr.' + k) : localStorage.setItem('vkr.' + k, JSON.stringify(v)); } catch { } } };
  const DEF_ACCOUNT = 'co-volkan';
  const accUrl = a => { if (WEB) return location.origin; a = String(a || '').trim().replace(/\/+$/, ''); if (/^https?:\/\//i.test(a)) return a; if (/\.workers\.dev$/i.test(a)) return 'https://' + a; return `https://vkcloud.${a.toLowerCase().replace(/[^a-z0-9-]/g, '')}.workers.dev`; };
  const json = (o, code = 200) => new Response(JSON.stringify(o), { status: code, headers: { 'content-type': 'application/json' } });
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  let CFG = LS.get('cfg', null);           // { account, url, token, role }
  let PC = { online: false, at: 0, checked: 0 };
  let CL = null;                           // dernière bibliothèque connue (pour les images, la lecture…)
  let PENDING = null;                      // site ouvert depuis le PC sur un épisode précis (#t=…&p=…)
  if (WEB) {
    if (CFG && CFG.url !== location.origin) CFG = null;
    // jeton transmis par VkSéries sur le PC (#t=…), ou ancienne connexion du site : pas besoin de retaper le mot de passe
    let tok = null; const m = location.hash.match(/[#&]t=([\w.]+)/);
    if (m) { tok = m[1]; const e = location.hash.match(/[#&]p=(\w+)/); if (e) PENDING = e[1]; history.replaceState(null, '', location.pathname); }
    else if (!CFG || !CFG.token) { try { tok = localStorage.getItem('vkc_t'); } catch { } }
    try { localStorage.removeItem('vkc_t'); } catch { }
    if (tok) { CFG = { account: location.hostname.split('.')[1] || '', url: location.origin, token: tok, role: 'owner' }; LS.set('cfg', CFG); }
  }

  /* ---------- connexion au compte (une seule fois) */
  let readyRes; const READY = new Promise(r => { readyRes = r; });
  function loginScreen(msg) {
    const d = document.createElement('div'); d.id = 'vkrLogin';
    d.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#0a0a0a;display:grid;place-items:center;padding:20px;font-family:inherit';
    d.innerHTML = `<form style="width:min(380px,100%);background:#161616;border:1px solid #262626;border-radius:18px;padding:26px 22px;color:#f2f2f2;display:flex;flex-direction:column;gap:12px">
      <div style="font-size:24px;font-weight:800"><span style="color:#e50914">Vk</span>Séries</div>
      <div style="color:#a3a3a3;font-size:14px">Connecte-toi à ton compte (le même que sur ton PC). Mot de passe propriétaire = tout, comme sur le PC ; mot de passe invité = regarder seulement.</div>
      <label style="font-size:13px;color:#a3a3a3;${WEB ? 'display:none' : ''}">Compte<input id="vkrAcc" value="${(CFG && CFG.account) || DEF_ACCOUNT}" autocapitalize="off" spellcheck="false" style="display:block;width:100%;margin-top:6px;padding:12px;border-radius:10px;border:1px solid #333;background:#0a0a0a;color:#fff;font-size:16px"></label>
      <label style="font-size:13px;color:#a3a3a3">Mot de passe<input id="vkrPw" type="password" style="display:block;width:100%;margin-top:6px;padding:12px;border-radius:10px;border:1px solid #333;background:#0a0a0a;color:#fff;font-size:16px"></label>
      <div id="vkrErr" style="color:#ff6b6b;font-size:13px;min-height:16px">${msg || ''}</div>
      <button style="padding:13px;border-radius:10px;border:0;background:#e50914;color:#fff;font-weight:700;font-size:16px">Se connecter</button></form>`;
    document.body.appendChild(d);
    d.querySelector('form').onsubmit = async e => {
      e.preventDefault(); const acc = d.querySelector('#vkrAcc').value.trim(), pw = d.querySelector('#vkrPw').value, url = accUrl(acc);
      d.querySelector('#vkrErr').textContent = 'Connexion…';
      try {
        const r = await realFetch(url + '/api/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ password: pw }) });
        const j = await r.json().catch(() => ({}));
        if (!r.ok || !j.token) throw new Error(j.error || 'compte introuvable');
        CFG = { account: acc, url, token: j.token, role: j.role || 'owner' }; LS.set('cfg', CFG); d.remove(); readyRes(); checkPC(true);
      } catch (er) { d.querySelector('#vkrErr').textContent = String(er.message || er).replace(/^./, c => c.toUpperCase()); }
    };
    setTimeout(() => d.querySelector('#vkrPw').focus(), 50);
  }
  const start = async () => {
    if (!(CFG && CFG.token)) return loginScreen();
    if (WEB) { try { const j = await cloudJson('GET', '/api/me'); if (j && j.role) { CFG.role = j.role; LS.set('cfg', CFG); } } catch { } } // propriétaire ou invité
    readyRes();
  };
  if (document.body) start(); else document.addEventListener('DOMContentLoaded', start);
  function logout(msg) { CFG = CFG ? { account: CFG.account } : null; LS.set('cfg', CFG); location.reload(); }

  /* ---------- serveur en ligne */
  async function cloud(method, p, body) {
    const r = await realFetch(CFG.url + p, { method, headers: { authorization: 'Bearer ' + CFG.token, ...(body !== undefined ? { 'content-type': 'application/json' } : {}) }, body: body !== undefined ? JSON.stringify(body) : undefined, cache: 'no-store' });
    if (r.status === 401) { LS.set('cfg', { account: CFG.account }); setTimeout(() => location.reload(), 1500); throw new Error('Connexion expirée : reconnecte-toi'); }
    return r;
  }
  const cloudJson = async (m, p, b) => { const r = await cloud(m, p, b); const j = r.status === 204 ? null : await r.json().catch(() => ({})); if (!r.ok) { const e = new Error((j && j.error) || 'erreur ' + r.status); e.status = r.status; throw e; } return j; };
  const owner = () => CFG && CFG.role !== 'guest';
  async function checkPC(force) {
    if (!CFG || !CFG.token || !owner()) { PC.online = false; return PC; }
    if (!force && Date.now() - PC.checked < 15000) return PC;
    PC.checked = Date.now();
    try { const j = await cloudJson('GET', '/api/remote/status'); PC.online = !!j.online; PC.at = j.at; PC.busy = j.busy; } catch { PC.online = false; }
    paintPC();
    return PC;
  }
  setInterval(() => checkPC(), 15000);
  // une demande au PC (via le serveur) ; null si le PC ne répond pas
  async function relay(method, path, body) {
    const { id } = await cloudJson('POST', '/api/remote/req', { method, path, body });
    const t0 = Date.now();
    for (let i = 0; Date.now() - t0 < 30000; i++) {
      await sleep(i < 6 ? 500 : 900);
      const r = await cloudJson('GET', '/api/remote/res?id=' + encodeURIComponent(id));
      if (r) return r;
    }
    PC.online = false; paintPC();
    return null;
  }

  /* ---------- bibliothèque depuis le compte en ligne (PC éteint) */
  async function cloudLib() {
    const [lib, prog] = await Promise.all([cloudJson('GET', '/api/series'), cloudJson('GET', '/api/progress').catch(() => ({}))]);
    const local = LS.get('local', { playlists: [], settings: { subSize: 1, autoNext: true, subLang: 'auto' } });
    return {
      v: 1, settings: local.settings, playlists: local.playlists, progress: prog || {}, cloudQueue: [],
      series: (lib.series || []).map(s => ({ id: s.id, name: s.name, cover: !!s.cover, cloudCover: !!s.cover, music: s.music ? { at: s.music, vol: 0.35 } : null, cloudMusic: s.music || 0, glossary: [],
        eps: (s.eps || []).map(e => ({ id: e.id, s: e.s, e: e.e, title: e.title, file: '', dur: e.dur || 0, th: !!e.th, autoFr: (e.subs || []).some(t => t.key === 'auto-fr'), hasSrc: false, pending: false, missing: true, cloud: true, csubs: e.subs || [], ai: null, check: null, upq: false })) })),
    };
  }
  async function getLib() {
    await checkPC();
    let lib = null;
    if (PC.online) { const r = await relay('GET', '/api/lib'); if (r && r.status === 200) lib = r.body; }
    const cl = await cloudLib().catch(() => null);
    if (!lib) lib = cl || { series: [], playlists: [], progress: {}, settings: {} };
    else if (cl) { // épisodes en ligne : on garde les infos du compte en ligne (miniature, sous-titres en ligne)
      const on = new Map(); for (const s of cl.series) for (const e of s.eps) on.set(e.id, e);
      for (const s of lib.series) { const c = cl.series.find(x => x.id === s.id); if (c) s.cloudCover = c.cloudCover; for (const e of s.eps) { const o = on.get(e.id); if (o) { e.th = o.th; e.csubs = o.csubs; e.cloud = true; } } }
      // ce qui est en ligne mais pas sur ce PC (mis en ligne depuis un autre PC…) : on l'ajoute aussi
      const have = new Set(lib.series.flatMap(x => x.eps.map(e => e.id)));
      for (const c of cl.series) { const extra = c.eps.filter(e => !have.has(e.id)); if (!extra.length) continue; const s = lib.series.find(x => x.id === c.id); if (s) s.eps.push(...extra); else lib.series.push({ ...c, eps: extra }); }
      lib.progress = { ...lib.progress }; for (const [id, p] of Object.entries(cl.progress || {})) { const l = lib.progress[id]; if (!l || (p.at || 0) > (l.at || 0)) lib.progress[id] = p; }
    }
    CL = lib;
    if (PENDING) { const id = PENDING; PENDING = null; setTimeout(() => { if (typeof play === 'function' && findEp(id)) play(id); }, 400); }
    return lib;
  }
  const findEp = id => { if (!CL) return null; for (const s of CL.series) { const e = s.eps.find(x => x.id === id); if (e) return { s, e }; } return null; };

  /* ---------- adresses des fichiers (vidéo, images, sous-titres, musique) : toujours en ligne */
  const f = k => CFG ? `${CFG.url}/f/${k.split('/').map(encodeURIComponent).join('/')}?t=${encodeURIComponent(CFG.token)}` : '';
  const BLANK = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
  function url(p) {
    let m;
    if ((m = p.match(/^\/media\/(\w+)/))) return f(`v/${m[1]}.mp4`);
    if ((m = p.match(/^\/thumb\/(\w+)\.jpg/))) { const x = findEp(m[1]); return x && x.e.cloud && x.e.th !== false ? f(`t/${m[1]}.jpg`) : BLANK; }
    if ((m = p.match(/^\/cover\/(\w+)\.jpg/))) { const s = CL && CL.series.find(x => x.id === m[1]); if (s && s.cloudCover) return f(`c/${s.id}.jpg`); const e = s && (s.eps.find(x => x.cloud && x.th) || null); return e ? f(`t/${e.id}.jpg`) : BLANK; }
    if ((m = p.match(/^\/music\/(\w+)\.mp3/))) return f(`m/${m[1]}.mp3`);
    if ((m = p.match(/^\/sub\/(\w+)\/([\w.-]+)\.vtt/))) return f(`s/${m[1]}.${m[2]}.vtt`);
    return BLANK;
  }

  /* ---------- réponses à la place du PC */
  const OFF = `Ton PC est éteint (ou VkSéries n'y est pas ouvert) : allume-le pour faire ça depuis ${WHERE}.`;
  async function handle(method, path, body) {
    await READY;
    const p = path.split('?')[0];
    let m;
    if (p === '/api/lib') return json(await getLib());
    if ((m = p.match(/^\/api\/play\/(\w+)$/))) {
      const x = findEp(m[1]); if (!x) return json({ error: 'épisode introuvable' }, 404);
      if (!x.e.cloud) return json({ error: 'Cet épisode est seulement sur ton PC : mets-le en ligne (⋯ → Mettre en ligne) pour le regarder ici.' }, 409);
      return json({ direct: true, duration: x.e.dur || 0, defAudio: 0, audios: [], subs: (x.e.csubs || []).map(t => ({ key: t.key, label: t.label, lang: t.lang || '' })), vmode: 'copy' });
    }
    if (p === '/api/progress' && method === 'POST') { try { await cloudJson('POST', '/api/progress', { id: body.id, t: body.t, d: body.d, at: Date.now(), done: body.t > body.d - Math.min(120, body.d * 0.05) }); } catch { } return json({ ok: true }); }
    if (p.startsWith('/api/update')) return json({ status: 'off', current: window.Android && Android.webVersion ? Android.webVersion() : '' });
    if (p === '/api/cloud/logout') { logout(); return json({ connected: false }); }
    if (/^\/api\/cloud\/(setup|login)$/.test(p)) return json({ error: 'À faire sur le PC' }, 400);
    if (p === '/api/cloud' && !(PC.online && owner())) return json({ connected: true, account: CFG.account, url: CFG.url, storage: true, owner: false, role: CFG.role, guest: !owner(), web: CFG.url + '/#t=' + CFG.token, queue: [], done: [], cur: null, pc: false });
    if (p === '/api/cloud/guest' && owner()) { try { return json(method === 'POST' ? await cloudJson('POST', '/api/guest', body) : await cloudJson('GET', '/api/guest')); } catch (e) { return json({ error: e.message }, 400); } }
    if (p === '/api/cloud/usage' && !PC.online) { try { return json(await cloudJson('GET', '/api/usage')); } catch (e) { return json({ error: e.message }, 400); } }
    if (p === '/api/cloud/storage' && method === 'GET' && !PC.online) { try { return json(await cloudJson('GET', '/api/storage')); } catch (e) { return json({ error: e.message }, 400); } }
    // tout le reste : c'est le PC qui le fait
    if (owner()) {
      await checkPC();
      if (PC.online) {
        const r = await relay(method, path, body);
        if (r) {
          if (p === '/api/settings' && method === 'PUT') saveLocal({ settings: body });
          return json(r.body, r.status);
        }
      }
    }
    // PC éteint : réglages et playlists gardés sur cet appareil ; lectures « vides » pour le reste
    if (p === '/api/settings' && method === 'PUT') { saveLocal({ settings: body }); return json({ ok: true }); }
    if (p === '/api/playlists' && method === 'PUT') { saveLocal({ playlists: body.playlists || [] }); return json({ ok: true }); }
    if (method === 'GET') {
      if (p === '/api/jobs') return json({ keys: {}, queue: [], cur: null, done: [], pcOff: true });
      if (p === '/api/checks') return json({ queue: [], cur: null, done: [] });
      if (p === '/api/storage') return json({ thumbs: 0, subs: 0, lib: 0 });
      if (p === '/api/keys') return json({});
      if (/^\/api\/check\/\w+$/.test(p)) return json({ none: true, pcOff: true });
    }
    return json({ error: owner() ? OFF : 'Accès invité : tu peux seulement regarder les séries' }, 409);
  }
  function saveLocal(o) { const l = LS.get('local', { playlists: [], settings: {} }); if (o.settings) l.settings = Object.assign(l.settings || {}, o.settings); if (o.playlists) l.playlists = o.playlists; LS.set('local', l); }

  window.fetch = (input, init = {}) => {
    const s = typeof input === 'string' ? input : input.url;
    let path = null;
    try { const uu = new URL(s, location.href); if (uu.protocol === 'file:' || uu.origin === location.origin) path = uu.pathname.replace(/^.*?(\/api\/)/, '$1') + uu.search; } catch { }
    if (path && path.startsWith('/api/')) {
      let body; try { body = init.body ? JSON.parse(init.body) : undefined; } catch { body = init.body; }
      return handle(String(init.method || 'GET').toUpperCase(), path, body).catch(e => json({ error: e.message || 'erreur' }, 502));
    }
    return realFetch(input, init);
  };

  /* ---------- petit indicateur « PC allumé / éteint » + bouton retour du téléphone */
  let lastOnline = null;
  function paintPC() {
    // le PC vient de s'allumer ou de s'éteindre : on recharge la bibliothèque (complète ou en ligne seulement)
    if (lastOnline !== null && lastOnline !== PC.online && window.loadLib && window.render) loadLib().then(() => { const pl = document.getElementById('player'); if (!pl || pl.hidden) render(true); }).catch(() => { });
    lastOnline = PC.online;
    let b = document.getElementById('vkrPC');
    if (!owner() || !document.body) { if (b) b.remove(); return; }
    if (!b) { b = document.createElement('button'); b.id = 'vkrPC'; b.style.cssText = 'position:fixed;left:10px;bottom:10px;z-index:50;border:0;border-radius:20px;padding:7px 12px;font:600 12px system-ui;color:#fff;opacity:.9'; b.onclick = () => window.toast && toast(PC.online ? 'Ton PC est allumé : tu pilotes VkSéries du PC depuis ici (sous-titres, mise en ligne, vérification…)' : 'PC éteint : tu vois et regardes ce qui est en ligne. Allume VkSéries sur ton PC pour tout le reste.'); document.body.appendChild(b); }
    b.style.background = PC.online ? 'rgba(46,160,67,.9)' : 'rgba(60,60,60,.9)';
    b.textContent = PC.online ? '● PC connecté' : '○ PC éteint';
  }
  window.vkBack = () => {
    const modal = document.getElementById('modal'), ctx = document.getElementById('ctx'), player = document.getElementById('player');
    if (ctx && !ctx.hidden) { ctx.hidden = true; return true; }
    if (modal && !modal.hidden) { modal.hidden = true; return true; }
    if (player && !player.hidden && window.closePlayer) { closePlayer(); return true; }
    if (location.hash && location.hash !== '#/' && location.hash !== '#') { history.back(); return true; }
    Android.exit(); return true;
  };
  window.vkPause = () => { const v = document.getElementById('video'); if (v && !v.paused) v.pause(); };

  /* ---------- mises à jour : l'interface se met à jour toute seule (sans APK) ; APK seulement si l'appli change */
  const verCmp = (a, b) => { const x = String(a || '0').split('.').map(n => parseInt(n) || 0), y = String(b || '0').split('.').map(n => parseInt(n) || 0); for (let i = 0; i < Math.max(x.length, y.length); i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) < (y[i] || 0) ? -1 : 1; return 0; };
  async function updates() {
    if (!(window.Android && Android.appCode)) return;
    let j; try { j = await (await realFetch('https://raw.githubusercontent.com/Vekahaine/vk-apps/main/latest.json?t=' + Date.now(), { cache: 'no-store' })).json(); } catch { return; }
    const BASE = 'https://raw.githubusercontent.com/Vekahaine/vk-apps/main/', w = j.vkseries_www, a = j.vkseries_android;
    if (Android.webUpdate && w && (!w.minApk || +Android.appCode() >= w.minApk) && verCmp(w.version, Android.webVersion()) > 0) {
      Android.webUpdate(new URL(w.zip, BASE).href, w.sha256 || '', w.version);
      for (let i = 0; i < 600; i++) {
        await sleep(500); let s = {}; try { s = JSON.parse(Android.webUpdateState()); } catch { }
        if (s.state === 'done') { const v = document.getElementById('video'); if (v && !v.paused) { window.toast && toast(`VkSéries ${w.version} est prête : elle s'ouvrira au prochain lancement`); return; } Android.webReload(); return; }
        if (s.state === 'error') return;
      }
    }
    if (a && a.code > +Android.appCode() && LS.get('apkSkip', 0) !== a.code && window.toast) toast(`Nouvelle version de l'appli VkSéries (${a.version}) : appuie pour l'installer`, false, { label: 'Installer', fn: () => installApk(new URL(a.apk, BASE).href, a) });
  }
  // nouvelle appli : téléchargée ICI, sans passer par le navigateur (Android demande juste de confirmer l'installation)
  async function installApk(url, a) {
    if (!Android.apkInstall) { Android.openUrl(url); LS.set('apkSkip', a.code); return; }
    Android.apkInstall(url); toast('Téléchargement de la mise à jour…');
    for (let i = 0; i < 1200; i++) {
      await sleep(500); let s = {}; try { s = JSON.parse(Android.apkState()); } catch { }
      if (s.state === 'done') return;
      if (s.state === 'error') { Android.openUrl(url); return; } // secours : le navigateur
    }
  }
  setTimeout(updates, 6000);

  window.VK_REMOTE = { url, cfg: () => CFG, pc: () => PC, relay, owner, logout };
})();
